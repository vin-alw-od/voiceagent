# speech-to-speech Development Guidelines

Auto-generated from all feature plans. Last updated: 2025-09-20

## Active Technologies
-  +  (001-speech-to-speech-core)

## Project Structure
```
src/
tests/
```

## Commands
# Add commands for 

## Code Style
: Follow standard conventions

## Recent Changes
- 001-speech-to-speech-core: Added  + 

<!-- MANUAL ADDITIONS START -->
<!-- MANUAL ADDITIONS END -->