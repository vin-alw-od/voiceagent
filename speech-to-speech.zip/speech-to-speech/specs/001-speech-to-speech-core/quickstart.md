# Quickstart: Speech-to-Speech Voice Assistant

## Prerequisites
- Python 3.11+
- Azure OpenAI API access with Realtime API enabled
- Vector database (ChromaDB for development)
- PostgreSQL for transcript storage
- Audio input/output device

## Quick Setup

### 1. Environment Configuration
```bash
# Clone repository
git clone <repository-url>
cd speech-to-speech

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment variables
cp .env.example .env
# Edit .env with your Azure OpenAI credentials
```

### 2. Database Setup
```bash
# Start PostgreSQL (Docker)
docker run -d --name postgres-speech \
  -e POSTGRES_DB=speech_assistant \
  -e POSTGRES_USER=speechuser \
  -e POSTGRES_PASSWORD=speechpass \
  -p 5432:5432 postgres:15

# Run database migrations
python -m alembic upgrade head
```

### 3. Vector Database Setup
```bash
# ChromaDB will auto-initialize on first run
# Load sample knowledge base
python scripts/load_sample_data.py
```

### 4. Start the Service
```bash
# Development server
uvicorn src.api.main:app --reload --host 0.0.0.0 --port 8000

# Or using the CLI
python -m src.cli.server --dev
```

## Testing the Integration

### 1. Health Check
```bash
curl http://localhost:8000/health
```

Expected response:
```json
{
  "status": "healthy",
  "timestamp": "2025-09-20T12:00:00Z",
  "services": {
    "azure_openai": "up",
    "vector_database": "up",
    "transcript_database": "up"
  },
  "latency_ms": 45
}
```

### 2. Start Conversation
```bash
curl -X POST http://localhost:8000/conversation/start \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-token>" \
  -d '{"user_id": "test_manager"}'
```

Expected response:
```json
{
  "session_id": "123e4567-e89b-12d3-a456-426614174000",
  "user_id": "test_manager",
  "status": "active",
  "started_at": "2025-09-20T12:00:00Z",
  "last_activity_at": "2025-09-20T12:00:00Z",
  "context_data": {},
  "performance_metrics": {}
}
```

### 3. Voice Query Test
```bash
# Using a test audio file
curl -X POST http://localhost:8000/conversation/{session_id}/query \
  -H "Authorization: Bearer <your-token>" \
  -F "audio_data=@test_audio.wav" \
  -F "audio_format=wav"
```

Expected response (within 800ms):
```json
{
  "query_id": "456e7890-e89b-12d3-a456-426614174001",
  "transcription": "What is the status of Project Alpha?",
  "confidence_score": 0.95,
  "response_text": "Project Alpha is currently in the design phase...",
  "audio_url": "http://localhost:8000/audio/456e7890-e89b-12d3-a456-426614174001",
  "processing_time_ms": 650,
  "source_documents": [
    {
      "title": "Project Alpha Overview",
      "relevance_score": 0.89,
      "snippet": "Project Alpha involves..."
    }
  ]
}
```

## Integration Test Scenarios

### Scenario 1: Basic Voice Conversation
**Given**: A running speech-to-speech service
**When**: Account manager starts conversation and asks about project status
**Then**: System responds within 800ms with relevant information

```bash
# Test script
python tests/integration/test_basic_conversation.py
```

### Scenario 2: Azure API Failure Handling
**Given**: Azure OpenAI API is unavailable
**When**: User submits voice query
**Then**: System provides fallback response and continues operation

```bash
# Simulate API failure
python tests/integration/test_azure_failure.py
```

### Scenario 3: Concurrent Sessions
**Given**: Multiple account managers using the system
**When**: Concurrent voice queries are submitted
**Then**: All queries processed within latency limits without interference

```bash
# Load test
python tests/integration/test_concurrent_sessions.py
```

## Performance Validation

### Latency Requirements
- End-to-end response time: <800ms
- Audio transcription: <200ms
- Vector database query: <100ms
- Response generation: <300ms
- Audio synthesis: <200ms

### Monitoring Setup
```bash
# View real-time metrics
curl http://localhost:8000/metrics

# Expected metrics
{
  "current_sessions": 5,
  "total_queries_today": 1247,
  "average_latency_ms": 425,
  "p95_latency_ms": 650,
  "error_rate_percent": 0.02,
  "azure_api_health": "healthy"
}
```

## Troubleshooting

### Common Issues

**Service won't start**:
```bash
# Check environment variables
python -c "import os; print(os.environ.get('AZURE_OPENAI_API_KEY'))"

# Verify database connection
python scripts/check_database.py
```

**High latency**:
```bash
# Check Azure OpenAI status
curl http://localhost:8000/health

# Monitor component latency
python scripts/latency_breakdown.py
```

**Audio quality issues**:
```bash
# Test audio pipeline
python scripts/test_audio_quality.py

# Check codec configuration
python scripts/verify_audio_config.py
```

## Development Workflow

### 1. Feature Development
```bash
# Create feature branch
git checkout -b feature/new-capability

# Run tests first (TDD)
pytest tests/unit/test_new_capability.py
# Tests should fail initially

# Implement feature
# ...

# Verify tests pass
pytest tests/unit/test_new_capability.py
```

### 2. Integration Testing
```bash
# Run full test suite
pytest tests/

# Run performance tests
python tests/performance/test_latency_requirements.py
```

### 3. Quality Gates
```bash
# Constitutional compliance check
python scripts/constitution_check.py

# Audio quality validation
python scripts/audio_quality_check.py

# Security scan
python scripts/security_scan.py
```

## Production Deployment

### Environment Variables
```bash
# Required for production
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_OPENAI_ENDPOINT="your-endpoint"
export DATABASE_URL="postgresql://user:pass@host:5432/db"
export VECTOR_DB_URL="your-vector-db-url"
export JWT_SECRET_KEY="your-jwt-secret"
```

### Health Monitoring
```bash
# Set up monitoring alerts for:
# - Response latency > 800ms
# - Error rate > 1%
# - Azure API connectivity
# - Database connectivity
```

### Scaling Considerations
- Horizontal scaling: Multiple API instances behind load balancer
- Database: Connection pooling and read replicas
- Vector database: Clustering for high availability
- Audio processing: CPU-optimized instances

This quickstart guide enables rapid setup and validation of the speech-to-speech voice assistant while ensuring all constitutional requirements are met.