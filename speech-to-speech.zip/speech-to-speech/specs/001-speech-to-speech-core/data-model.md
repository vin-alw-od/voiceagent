# Data Model: Speech-to-Speech Voice Assistant

## Core Entities

### ConversationSession
**Purpose**: Represents an active voice interaction session between user and AI agent

**Fields**:
- `session_id`: UUID (Primary Key) - Unique identifier for the conversation
- `user_id`: String - Account manager identifier
- `status`: Enum [active, completed, failed, timeout] - Current session state
- `started_at`: DateTime - Session initiation timestamp
- `ended_at`: DateTime (Optional) - Session completion timestamp
- `last_activity_at`: DateTime - Last user interaction timestamp
- `context_data`: JSON - Conversation context and history
- `performance_metrics`: JSON - Latency and quality measurements

**Validation Rules**:
- `session_id` must be unique
- `started_at` cannot be in the future
- `ended_at` must be after `started_at` if present
- `status` transitions: active → [completed, failed, timeout]
- Sessions auto-timeout after 30 minutes of inactivity

**State Transitions**:
- Initial: active
- active → completed (normal conversation end)
- active → failed (error occurred)
- active → timeout (inactivity timeout)

### VoiceQuery
**Purpose**: Individual speech input from user within a conversation

**Fields**:
- `query_id`: UUID (Primary Key) - Unique query identifier
- `session_id`: UUID (Foreign Key) - Reference to conversation session
- `audio_data`: Blob - Raw audio input data
- `transcription`: Text - Speech-to-text result
- `intent_classification`: String - Detected user intent
- `confidence_score`: Float [0.0-1.0] - Transcription confidence
- `received_at`: DateTime - Query received timestamp
- `processed_at`: DateTime - Processing completion timestamp
- `audio_quality_metrics`: JSON - Quality assessment data

**Validation Rules**:
- `session_id` must reference valid ConversationSession
- `confidence_score` must be between 0.0 and 1.0
- `processed_at` must be after `received_at`
- `audio_data` size limited to 10MB per query
- `transcription` required if confidence_score > 0.5

**Relationships**:
- Belongs to one ConversationSession
- Has one KnowledgeResponse (if query processed)

### KnowledgeResponse
**Purpose**: Information retrieved from vector database for user query

**Fields**:
- `response_id`: UUID (Primary Key) - Unique response identifier
- `query_id`: UUID (Foreign Key) - Reference to originating query
- `source_documents`: JSON Array - Retrieved document references
- `relevance_scores`: JSON Array - Relevance scores for each document
- `synthesized_response`: Text - AI-generated response content
- `vector_query_time_ms`: Integer - Database query duration
- `total_processing_time_ms`: Integer - End-to-end processing time
- `created_at`: DateTime - Response generation timestamp

**Validation Rules**:
- `query_id` must reference valid VoiceQuery
- `vector_query_time_ms` must be positive
- `total_processing_time_ms` must be >= `vector_query_time_ms`
- `relevance_scores` array length must match `source_documents` length
- Response generation must complete within 800ms (constitutional requirement)

**Relationships**:
- Belongs to one VoiceQuery
- Has one AudioResponse

### AudioResponse
**Purpose**: Generated speech output delivered to user

**Fields**:
- `audio_id`: UUID (Primary Key) - Unique audio identifier
- `response_id`: UUID (Foreign Key) - Reference to knowledge response
- `audio_data`: Blob - Generated audio file
- `duration_seconds`: Float - Audio duration
- `format`: String - Audio format (mp3, wav, etc.)
- `quality_metrics`: JSON - Audio quality measurements
- `generation_time_ms`: Integer - Azure OpenAI generation time
- `delivery_status`: Enum [pending, delivered, failed] - Delivery status
- `created_at`: DateTime - Audio generation timestamp
- `delivered_at`: DateTime (Optional) - User delivery timestamp

**Validation Rules**:
- `response_id` must reference valid KnowledgeResponse
- `duration_seconds` must be positive
- `generation_time_ms` must be positive
- Total time from VoiceQuery to delivery must be <800ms (constitutional requirement)
- `delivered_at` must be after `created_at` if present

**Relationships**:
- Belongs to one KnowledgeResponse

### TranscriptRecord
**Purpose**: Compliance record of complete conversations

**Fields**:
- `transcript_id`: UUID (Primary Key) - Unique transcript identifier
- `session_id`: UUID (Foreign Key) - Reference to conversation session
- `user_id`: String - Account manager identifier (for privacy controls)
- `full_conversation`: JSON - Complete conversation history
- `created_at`: DateTime - Transcript creation timestamp
- `expires_at`: DateTime - Auto-deletion date (created_at + 30 days)
- `access_log`: JSON Array - Record of who accessed transcript
- `compliance_flags`: JSON - Privacy and compliance metadata

**Validation Rules**:
- `session_id` must reference valid ConversationSession
- `expires_at` must be exactly 30 days after `created_at` (constitutional requirement)
- Automatic deletion enforced at `expires_at`
- Access logging mandatory for compliance
- No sensitive data in logs (constitutional requirement)

**Relationships**:
- Belongs to one ConversationSession

## Entity Relationships

```
ConversationSession (1) ----< VoiceQuery (many)
VoiceQuery (1) ----< KnowledgeResponse (1)
KnowledgeResponse (1) ----< AudioResponse (1)
ConversationSession (1) ----< TranscriptRecord (1)
```

## Performance Considerations

### Indexing Strategy
- `ConversationSession.user_id` - Index for user query performance
- `ConversationSession.status, last_activity_at` - Composite index for cleanup jobs
- `VoiceQuery.session_id, received_at` - Composite index for conversation timeline
- `TranscriptRecord.expires_at` - Index for automated deletion job

### Data Retention
- Audio blobs purged after successful transcription (unless debugging enabled)
- TranscriptRecord automatically deleted after 30 days
- Performance metrics retained for 90 days for analysis
- Session data archived after 7 days of inactivity

### Compliance Features
- All timestamps in UTC for audit trails
- Soft deletion with audit logging
- Encryption at rest for sensitive fields
- Access controls integrated with authentication system

This data model supports all functional requirements while ensuring constitutional compliance for privacy, performance, and modularity.