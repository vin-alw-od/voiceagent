#!/bin/bash

echo "Setting up Speech-to-Speech Voice Assistant..."
echo

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed"
    echo "Please install Python 3.8+ from https://python.org"
    exit 1
fi

echo "Creating virtual environment..."
python3 -m venv venv

echo "Activating virtual environment..."
source venv/bin/activate

echo "Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

echo
echo "Setup completed successfully!"
echo
echo "To start the application:"
echo "  1. Run: source venv/bin/activate"
echo "  2. Copy .env.example to .env and configure your settings"
echo "  3. Run: python -m src.api.main"
echo
echo "Or simply run: ./start.sh"
echo