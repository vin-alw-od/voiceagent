"""Integration test for audio quality metrics collection and validation."""
import pytest
from httpx import AsyncClient
import io
import time
from unittest.mock import AsyncMock, patch


class TestAudioQualityIntegration:
    """Integration tests for audio quality metrics and validation."""

    @pytest.mark.asyncio
    async def test_audio_quality_metrics_collection(self, async_client: AsyncClient):
        """Test that audio quality metrics are properly collected."""
        # Scenario: Account manager submits voice query with varying audio quality
        # Given: System is configured to collect audio quality metrics
        # When: Voice queries with different quality levels are submitted
        # Then: System provides quality scores and handles degraded audio gracefully

        # Start conversation
        start_response = await async_client.post(
            "/conversation/start",
            json={"user_id": "quality_test_manager", "context": {"test_type": "audio_quality"}}
        )

        assert start_response.status_code == 201
        session_id = start_response.json()["session_id"]

        # Test cases with different simulated audio qualities
        audio_test_cases = [
            {
                "name": "high_quality_crystal_clear",
                "data": b"high_quality_audio_44khz_clear_speech_project_status",
                "expected_min_confidence": 0.9,
                "expected_quality_score": 0.8
            },
            {
                "name": "medium_quality_background_noise",
                "data": b"medium_quality_audio_with_background_noise_project_update",
                "expected_min_confidence": 0.7,
                "expected_quality_score": 0.6
            },
            {
                "name": "low_quality_compressed",
                "data": b"low_quality_compressed_audio_what_is_status_project_alpha",
                "expected_min_confidence": 0.5,
                "expected_quality_score": 0.4
            },
            {
                "name": "very_poor_quality_distorted",
                "data": b"very_poor_distorted_audio_barely_audible_speech",
                "expected_min_confidence": 0.3,
                "expected_quality_score": 0.2
            }
        ]

        quality_results = []

        for test_case in audio_test_cases:
            files = {
                "audio_data": (f"{test_case['name']}.wav", io.BytesIO(test_case["data"]), "audio/wav")
            }

            start_time = time.time()
            response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": "wav"}
            )
            end_time = time.time()

            processing_time_ms = (end_time - start_time) * 1000

            result = {
                "test_case": test_case["name"],
                "status_code": response.status_code,
                "processing_time_ms": processing_time_ms,
                "expected_confidence": test_case["expected_min_confidence"],
                "expected_quality": test_case["expected_quality_score"]
            }

            if response.status_code == 200:
                data = response.json()
                result.update({
                    "transcription": data.get("transcription", ""),
                    "confidence_score": data.get("confidence_score"),
                    "audio_quality_score": data.get("audio_quality_score"),
                    "processing_time_reported": data.get("processing_time_ms"),
                    "response_text": data.get("response_text", ""),
                    "audio_url": data.get("audio_url")
                })

                # Verify quality metrics are provided
                if "confidence_score" in data:
                    assert isinstance(data["confidence_score"], (int, float))
                    assert 0.0 <= data["confidence_score"] <= 1.0

                if "audio_quality_score" in data:
                    assert isinstance(data["audio_quality_score"], (int, float))
                    assert 0.0 <= data["audio_quality_score"] <= 1.0

                # Verify processing time meets constitutional requirement
                assert processing_time_ms <= 800

            quality_results.append(result)

        # Analyze results across quality levels
        successful_responses = [r for r in quality_results if r["status_code"] == 200]
        assert len(successful_responses) > 0  # Should handle at least some quality levels

        # Quality scores should generally correlate with expected quality
        for result in successful_responses:
            if result.get("confidence_score") is not None:
                # Higher quality audio should generally have higher confidence
                confidence = result["confidence_score"]
                expected = result["expected_confidence"]

                # Allow some variance in quality scoring
                assert confidence >= max(0.0, expected - 0.3)

    @pytest.mark.asyncio
    async def test_audio_quality_degradation_handling(self, async_client: AsyncClient):
        """Test system gracefully handles audio quality degradation."""
        # Start conversation
        start_response = await async_client.post(
            "/conversation/start",
            json={"user_id": "degradation_test_manager"}
        )

        session_id = start_response.json()["session_id"]

        # Test progressively degrading audio quality
        degradation_sequence = [
            {"quality": "excellent", "data": b"excellent_audio_clear_speech_project_alpha_status"},
            {"quality": "good", "data": b"good_audio_slight_noise_project_beta_update"},
            {"quality": "fair", "data": b"fair_audio_moderate_noise_project_gamma_timeline"},
            {"quality": "poor", "data": b"poor_audio_heavy_distortion_project_delta_budget"},
            {"quality": "very_poor", "data": b"very_poor_audio_barely_recognizable_speech"}
        ]

        previous_confidence = 1.0
        degradation_results = []

        for sequence_item in degradation_sequence:
            files = {
                "audio_data": (f"{sequence_item['quality']}.wav", io.BytesIO(sequence_item["data"]), "audio/wav")
            }

            response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": "wav"}
            )

            result = {
                "quality_level": sequence_item["quality"],
                "status_code": response.status_code,
                "graceful_handling": response.status_code in [200, 206, 422]  # Acceptable responses
            }

            if response.status_code == 200:
                data = response.json()
                current_confidence = data.get("confidence_score", 0.0)
                result.update({
                    "confidence_score": current_confidence,
                    "confidence_trend": "declining" if current_confidence < previous_confidence else "stable",
                    "has_response": len(data.get("response_text", "")) > 0,
                    "has_fallback_message": "quality" in data.get("response_text", "").lower()
                })
                previous_confidence = current_confidence

            degradation_results.append(result)

        # Verify graceful degradation
        graceful_responses = [r for r in degradation_results if r["graceful_handling"]]
        assert len(graceful_responses) >= len(degradation_sequence) // 2  # Should handle most gracefully

        # System should provide responses even for poor quality
        responses_with_content = [r for r in degradation_results if r.get("has_response")]
        assert len(responses_with_content) > 0

    @pytest.mark.asyncio
    async def test_audio_format_compatibility(self, async_client: AsyncClient):
        """Test audio quality metrics across different audio formats."""
        # Start conversation
        start_response = await async_client.post(
            "/conversation/start",
            json={"user_id": "format_test_manager"}
        )

        session_id = start_response.json()["session_id"]

        # Test different audio formats
        format_test_cases = [
            {
                "format": "wav",
                "mime_type": "audio/wav",
                "data": b"wav_format_audio_project_status_inquiry",
                "expected_support": True
            },
            {
                "format": "mp3",
                "mime_type": "audio/mpeg",
                "data": b"mp3_format_audio_project_budget_review",
                "expected_support": True  # Common format
            },
            {
                "format": "ogg",
                "mime_type": "audio/ogg",
                "data": b"ogg_format_audio_project_timeline_update",
                "expected_support": False  # Less common, might not be supported
            },
            {
                "format": "flac",
                "mime_type": "audio/flac",
                "data": b"flac_format_audio_high_quality_query",
                "expected_support": False  # High quality but less common
            }
        ]

        format_results = []

        for test_case in format_test_cases:
            files = {
                "audio_data": (f"test.{test_case['format']}", io.BytesIO(test_case["data"]), test_case["mime_type"])
            }

            response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": test_case["format"]}
            )

            result = {
                "format": test_case["format"],
                "status_code": response.status_code,
                "expected_support": test_case["expected_support"],
                "actually_supported": response.status_code == 200
            }

            if response.status_code == 200:
                data = response.json()
                result.update({
                    "quality_metrics_provided": any(
                        key in data for key in ["confidence_score", "audio_quality_score"]
                    ),
                    "processing_time_ms": data.get("processing_time_ms", 0)
                })

            format_results.append(result)

        # Verify format support aligns with expectations
        for result in format_results:
            if result["expected_support"]:
                # Expected formats should work
                assert result["actually_supported"] or result["status_code"] in [400, 422]

            if result["actually_supported"]:
                # Supported formats should provide quality metrics
                assert result.get("quality_metrics_provided", False)

    @pytest.mark.asyncio
    async def test_audio_quality_metrics_persistence(self, async_client: AsyncClient):
        """Test that audio quality metrics are properly tracked over time."""
        # Start conversation
        start_response = await async_client.post(
            "/conversation/start",
            json={"user_id": "persistence_test_manager"}
        )

        session_id = start_response.json()["session_id"]

        # Submit multiple queries with tracked quality
        quality_tracking_queries = [
            {"data": b"first_query_good_quality_audio", "expected_trend": "baseline"},
            {"data": b"second_query_excellent_quality", "expected_trend": "improving"},
            {"data": b"third_query_poor_quality_noise", "expected_trend": "degrading"},
            {"data": b"fourth_query_recovered_quality", "expected_trend": "recovering"}
        ]

        tracked_results = []

        for i, query in enumerate(quality_tracking_queries):
            files = {
                "audio_data": (f"tracked_{i}.wav", io.BytesIO(query["data"]), "audio/wav")
            }

            response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": "wav"}
            )

            if response.status_code == 200:
                data = response.json()
                tracked_results.append({
                    "query_index": i,
                    "confidence_score": data.get("confidence_score"),
                    "audio_quality_score": data.get("audio_quality_score"),
                    "query_id": data.get("query_id"),
                    "expected_trend": query["expected_trend"]
                })

        # Verify session maintains quality history
        session_response = await async_client.get(f"/conversation/{session_id}")
        if session_response.status_code == 200:
            session_data = session_response.json()

            # Check if quality metrics are tracked in session
            if "quality_metrics" in session_data:
                quality_metrics = session_data["quality_metrics"]

                # Should track average quality
                if "average_confidence" in quality_metrics:
                    avg_confidence = quality_metrics["average_confidence"]
                    assert isinstance(avg_confidence, (int, float))
                    assert 0.0 <= avg_confidence <= 1.0

                # Should track quality trend
                if "quality_trend" in quality_metrics:
                    assert quality_metrics["quality_trend"] in ["improving", "stable", "degrading"]

            # Check performance metrics include quality data
            if "performance_metrics" in session_data:
                perf_metrics = session_data["performance_metrics"]

                if "total_queries" in perf_metrics:
                    assert perf_metrics["total_queries"] == len(tracked_results)

    @pytest.mark.asyncio
    async def test_audio_quality_constitutional_compliance(self, async_client: AsyncClient):
        """Test audio quality handling meets constitutional requirements."""
        # Start conversation
        start_response = await async_client.post(
            "/conversation/start",
            json={"user_id": "constitutional_quality_test"}
        )

        session_id = start_response.json()["session_id"]

        # Test constitutional compliance with various audio qualities
        constitutional_test_cases = [
            {"name": "optimal_quality", "data": b"optimal_audio_clear_speech_fast_processing"},
            {"name": "acceptable_quality", "data": b"acceptable_audio_slight_noise_normal_processing"},
            {"name": "challenging_quality", "data": b"challenging_audio_noise_stress_test"}
        ]

        constitutional_results = []

        for test_case in constitutional_test_cases:
            files = {
                "audio_data": (f"{test_case['name']}.wav", io.BytesIO(test_case["data"]), "audio/wav")
            }

            start_time = time.time()
            response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": "wav"}
            )
            end_time = time.time()

            processing_time_ms = (end_time - start_time) * 1000

            result = {
                "test_case": test_case["name"],
                "processing_time_ms": processing_time_ms,
                "meets_latency_requirement": processing_time_ms <= 800,
                "status_code": response.status_code
            }

            if response.status_code == 200:
                data = response.json()
                result.update({
                    "reported_processing_time": data.get("processing_time_ms"),
                    "has_graceful_response": len(data.get("response_text", "")) > 0,
                    "confidence_score": data.get("confidence_score")
                })

                # Constitutional requirement: <800ms even with quality processing
                if "processing_time_ms" in data:
                    assert data["processing_time_ms"] <= 800

            constitutional_results.append(result)

        # Verify constitutional compliance
        compliant_results = [r for r in constitutional_results if r["meets_latency_requirement"]]

        # Should meet timing requirements regardless of audio quality
        compliance_rate = len(compliant_results) / len(constitutional_results)
        assert compliance_rate >= 0.8  # At least 80% should meet constitutional requirements

        # Verify graceful responses
        graceful_results = [r for r in constitutional_results if r.get("has_graceful_response")]
        assert len(graceful_results) > 0  # Should provide responses even for challenging quality

    @pytest.mark.asyncio
    async def test_audio_quality_cost_optimization(self, async_client: AsyncClient):
        """Test audio quality processing follows cost optimization principles."""
        # Start conversation
        start_response = await async_client.post(
            "/conversation/start",
            json={"user_id": "cost_optimization_quality_test"}
        )

        session_id = start_response.json()["session_id"]

        # Test cost-optimized quality processing
        cost_test_cases = [
            {
                "name": "standard_quality_normal_processing",
                "data": b"standard_quality_audio_normal_cost_processing",
                "processing_type": "standard"
            },
            {
                "name": "high_quality_intensive_processing",
                "data": b"high_quality_audio_might_require_intensive_processing",
                "processing_type": "intensive"
            },
            {
                "name": "low_quality_minimal_processing",
                "data": b"low_quality_audio_minimal_processing_needed",
                "processing_type": "minimal"
            }
        ]

        cost_results = []

        for test_case in cost_test_cases:
            files = {
                "audio_data": (f"{test_case['name']}.wav", io.BytesIO(test_case["data"]), "audio/wav")
            }

            start_time = time.time()
            response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": "wav"}
            )
            end_time = time.time()

            processing_time_ms = (end_time - start_time) * 1000

            result = {
                "test_case": test_case["name"],
                "processing_type": test_case["processing_type"],
                "processing_time_ms": processing_time_ms,
                "status_code": response.status_code
            }

            if response.status_code == 200:
                data = response.json()
                result.update({
                    "confidence_score": data.get("confidence_score"),
                    "cost_optimized": data.get("cost_optimized_processing", True),
                    "processing_efficiency": data.get("processing_efficiency")
                })

            cost_results.append(result)

        # Verify cost optimization
        successful_results = [r for r in cost_results if r["status_code"] == 200]

        # Should handle different quality levels efficiently
        assert len(successful_results) > 0

        # Processing times should be reasonable for cost optimization
        for result in successful_results:
            processing_time = result["processing_time_ms"]
            processing_type = result["processing_type"]

            # Cost optimization: don't over-process low quality audio
            if processing_type == "minimal":
                assert processing_time <= 500  # Should be faster for low quality

            # Should not exceed constitutional requirement regardless of quality
            assert processing_time <= 800

    @pytest.mark.asyncio
    async def test_audio_quality_real_time_monitoring(self, async_client: AsyncClient):
        """Test real-time monitoring of audio quality metrics."""
        # Get baseline metrics
        initial_metrics_response = await async_client.get("/metrics")
        initial_metrics = {}
        if initial_metrics_response.status_code == 200:
            initial_metrics = initial_metrics_response.json()

        # Start conversation and submit quality test queries
        start_response = await async_client.post(
            "/conversation/start",
            json={"user_id": "monitoring_quality_test"}
        )

        session_id = start_response.json()["session_id"]

        # Submit queries with different quality levels
        monitoring_queries = [
            b"high_quality_audio_monitoring_test_one",
            b"medium_quality_audio_monitoring_test_two",
            b"low_quality_audio_monitoring_test_three"
        ]

        for i, audio_data in enumerate(monitoring_queries):
            files = {
                "audio_data": (f"monitoring_{i}.wav", io.BytesIO(audio_data), "audio/wav")
            }

            await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": "wav"}
            )

        # Check updated metrics
        final_metrics_response = await async_client.get("/metrics")
        if final_metrics_response.status_code == 200:
            final_metrics = final_metrics_response.json()

            # Should track audio quality in metrics
            audio_quality_metrics = [
                "average_audio_quality",
                "total_audio_queries",
                "low_quality_query_count",
                "audio_processing_errors"
            ]

            for metric in audio_quality_metrics:
                if metric in final_metrics:
                    assert isinstance(final_metrics[metric], (int, float))
                    assert final_metrics[metric] >= 0

            # Quality metrics should reflect recent activity
            if "total_audio_queries" in final_metrics and "total_audio_queries" in initial_metrics:
                query_increase = final_metrics["total_audio_queries"] - initial_metrics["total_audio_queries"]
                assert query_increase >= 0  # Should show some increase

            # Average quality should be reasonable
            if "average_audio_quality" in final_metrics:
                avg_quality = final_metrics["average_audio_quality"]
                assert 0.0 <= avg_quality <= 1.0