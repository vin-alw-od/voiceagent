"""Integration test for concurrent sessions handling."""
import pytest
import asyncio
from httpx import AsyncClient
import io
import time
from unittest.mock import AsyncMock, patch


class TestConcurrentSessionsIntegration:
    """Integration tests for concurrent conversation sessions."""

    @pytest.mark.asyncio
    async def test_multiple_concurrent_sessions_basic(self, async_client: AsyncClient):
        """Test system handles multiple concurrent sessions without interference."""
        # Scenario: Multiple account managers using system simultaneously
        # Given: Multiple users start conversations at the same time
        # When: They submit queries concurrently
        # Then: Each session maintains independent state and meets performance requirements

        async def run_user_session(user_id: str, query_text: str):
            """Run a complete user session."""
            try:
                # Start conversation
                start_time = time.time()
                start_response = await async_client.post(
                    "/conversation/start",
                    json={
                        "user_id": user_id,
                        "context": {"department": "sales", "session_type": "concurrent_test"}
                    }
                )

                if start_response.status_code != 201:
                    return {"error": f"Failed to start session for {user_id}"}

                session_id = start_response.json()["session_id"]

                # Submit voice query
                audio_data = f"simulated_audio_{query_text}_{user_id}".encode()
                files = {
                    "audio_data": (f"{user_id}_query.wav", io.BytesIO(audio_data), "audio/wav")
                }

                query_response = await async_client.post(
                    f"/conversation/{session_id}/query",
                    files=files,
                    data={"audio_format": "wav"}
                )

                end_time = time.time()
                total_time_ms = (end_time - start_time) * 1000

                return {
                    "user_id": user_id,
                    "session_id": session_id,
                    "query_status": query_response.status_code,
                    "query_data": query_response.json() if query_response.status_code == 200 else None,
                    "total_time_ms": total_time_ms,
                    "success": query_response.status_code == 200
                }

            except Exception as e:
                return {"error": str(e), "user_id": user_id}

        # Create multiple concurrent sessions
        users_and_queries = [
            ("manager_alice", "project_status_alpha"),
            ("manager_bob", "budget_review_beta"),
            ("manager_charlie", "client_meeting_gamma"),
            ("manager_diana", "resource_allocation_delta"),
            ("manager_eve", "timeline_update_epsilon")
        ]

        # Run all sessions concurrently
        session_tasks = [
            run_user_session(user_id, query)
            for user_id, query in users_and_queries
        ]

        results = await asyncio.gather(*session_tasks, return_exceptions=True)

        # Verify results
        successful_sessions = []
        failed_sessions = []

        for result in results:
            if isinstance(result, dict):
                if result.get("success"):
                    successful_sessions.append(result)
                else:
                    failed_sessions.append(result)

        # Constitutional requirement: System should handle concurrent load
        assert len(successful_sessions) >= len(users_and_queries) // 2

        # Verify performance requirements for successful sessions
        for session in successful_sessions:
            # Each session should meet latency requirement
            assert session["total_time_ms"] <= 800

            # Verify response quality
            if session.get("query_data"):
                query_data = session["query_data"]
                assert "response_text" in query_data
                assert len(query_data["response_text"]) > 0
                assert query_data["processing_time_ms"] <= 800

        # Verify session isolation - each session should have unique ID
        session_ids = [s["session_id"] for s in successful_sessions]
        assert len(session_ids) == len(set(session_ids))  # All unique

    @pytest.mark.asyncio
    async def test_concurrent_sessions_resource_contention(self, async_client: AsyncClient):
        """Test system handles resource contention gracefully."""
        # Test high-concurrency scenario
        num_concurrent_sessions = 10

        async def create_heavy_session(session_index: int):
            """Create session with heavy processing load."""
            user_id = f"heavy_user_{session_index}"

            start_response = await async_client.post(
                "/conversation/start",
                json={"user_id": user_id}
            )

            if start_response.status_code != 201:
                return {"error": "Failed to start session", "index": session_index}

            session_id = start_response.json()["session_id"]

            # Submit multiple queries rapidly
            query_results = []
            for query_num in range(3):  # 3 queries per session
                audio_data = f"heavy_query_{session_index}_{query_num}".encode()
                files = {
                    "audio_data": (f"heavy_{session_index}_{query_num}.wav", io.BytesIO(audio_data), "audio/wav")
                }

                start_query_time = time.time()
                response = await async_client.post(
                    f"/conversation/{session_id}/query",
                    files=files,
                    data={"audio_format": "wav"}
                )
                end_query_time = time.time()

                query_results.append({
                    "status": response.status_code,
                    "time_ms": (end_query_time - start_query_time) * 1000,
                    "success": response.status_code == 200
                })

            return {
                "session_index": session_index,
                "session_id": session_id,
                "query_results": query_results,
                "total_queries": len(query_results),
                "successful_queries": sum(1 for q in query_results if q["success"])
            }

        # Run heavy concurrent load
        heavy_tasks = [
            create_heavy_session(i)
            for i in range(num_concurrent_sessions)
        ]

        heavy_results = await asyncio.gather(*heavy_tasks, return_exceptions=True)

        # Analyze results
        successful_sessions = [r for r in heavy_results if isinstance(r, dict) and not r.get("error")]
        total_queries = sum(r["total_queries"] for r in successful_sessions)
        successful_queries = sum(r["successful_queries"] for r in successful_sessions)

        # Should handle significant portion of load
        success_rate = successful_queries / total_queries if total_queries > 0 else 0
        assert success_rate >= 0.5  # At least 50% success under heavy load

        # Check for graceful degradation
        for session_result in successful_sessions:
            for query in session_result["query_results"]:
                if query["success"]:
                    # Successful queries should still meet performance requirements
                    assert query["time_ms"] <= 1200  # Allow some degradation under load

    @pytest.mark.asyncio
    async def test_concurrent_sessions_state_isolation(self, async_client: AsyncClient):
        """Test that concurrent sessions maintain state isolation."""
        # Create sessions with different contexts
        session_configs = [
            {
                "user_id": "manager_isolation_a",
                "context": {"client": "Acme Corp", "project": "Alpha"}
            },
            {
                "user_id": "manager_isolation_b",
                "context": {"client": "Beta LLC", "project": "Beta"}
            },
            {
                "user_id": "manager_isolation_c",
                "context": {"client": "Gamma Inc", "project": "Gamma"}
            }
        ]

        # Start all sessions
        sessions = []
        for config in session_configs:
            response = await async_client.post("/conversation/start", json=config)
            if response.status_code == 201:
                session_data = response.json()
                sessions.append({
                    "session_id": session_data["session_id"],
                    "user_id": config["user_id"],
                    "context": config["context"]
                })

        assert len(sessions) >= 2  # Need at least 2 sessions for isolation test

        # Submit queries to each session concurrently
        async def query_session(session):
            audio_data = f"context_query_{session['user_id']}".encode()
            files = {
                "audio_data": (f"{session['user_id']}.wav", io.BytesIO(audio_data), "audio/wav")
            }

            query_response = await async_client.post(
                f"/conversation/{session['session_id']}/query",
                files=files,
                data={"audio_format": "wav"}
            )

            # Get updated session state
            state_response = await async_client.get(f"/conversation/{session['session_id']}")

            return {
                "session_id": session["session_id"],
                "user_id": session["user_id"],
                "original_context": session["context"],
                "query_status": query_response.status_code,
                "state_status": state_response.status_code,
                "state_data": state_response.json() if state_response.status_code == 200 else None
            }

        # Query all sessions concurrently
        query_tasks = [query_session(session) for session in sessions]
        query_results = await asyncio.gather(*query_tasks)

        # Verify state isolation
        for result in query_results:
            if result["state_data"]:
                state_data = result["state_data"]

                # Should maintain original context
                if "context_data" in state_data:
                    context = state_data["context_data"]
                    original_context = result["original_context"]

                    # Key context should be preserved
                    for key, value in original_context.items():
                        if key in context:
                            assert context[key] == value

                # Session should be uniquely identified
                assert state_data.get("session_id") == result["session_id"]

    @pytest.mark.asyncio
    async def test_concurrent_sessions_metrics_tracking(self, async_client: AsyncClient):
        """Test metrics accurately track concurrent session activity."""
        # Get baseline metrics
        initial_metrics_response = await async_client.get("/metrics")
        initial_metrics = {}
        if initial_metrics_response.status_code == 200:
            initial_metrics = initial_metrics_response.json()

        # Create multiple concurrent sessions
        num_sessions = 5
        session_tasks = []

        async def tracked_session(index: int):
            # Start session
            start_response = await async_client.post(
                "/conversation/start",
                json={"user_id": f"metrics_user_{index}"}
            )

            if start_response.status_code == 201:
                session_id = start_response.json()["session_id"]

                # Submit query
                audio_data = f"metrics_query_{index}".encode()
                files = {
                    "audio_data": (f"metrics_{index}.wav", io.BytesIO(audio_data), "audio/wav")
                }

                await async_client.post(
                    f"/conversation/{session_id}/query",
                    files=files,
                    data={"audio_format": "wav"}
                )

                return {"success": True, "session_id": session_id}

            return {"success": False}

        # Run concurrent sessions
        session_results = await asyncio.gather(*[
            tracked_session(i) for i in range(num_sessions)
        ])

        successful_sessions = [r for r in session_results if r.get("success")]

        # Check updated metrics
        final_metrics_response = await async_client.get("/metrics")
        if final_metrics_response.status_code == 200:
            final_metrics = final_metrics_response.json()

            # Metrics should reflect increased activity
            if "current_sessions" in final_metrics:
                current_sessions = final_metrics["current_sessions"]
                assert isinstance(current_sessions, int)
                assert current_sessions >= 0

            if "total_queries_today" in final_metrics and "total_queries_today" in initial_metrics:
                query_increase = final_metrics["total_queries_today"] - initial_metrics["total_queries_today"]
                # Should show some increase (allowing for test execution timing)
                assert query_increase >= 0

    @pytest.mark.asyncio
    async def test_concurrent_sessions_failure_isolation(self, async_client: AsyncClient):
        """Test that failures in one session don't affect others."""
        # Create a mix of sessions - some will fail, others should succeed
        session_configs = [
            {"user_id": "stable_user_1", "should_fail": False},
            {"user_id": "failing_user", "should_fail": True},
            {"user_id": "stable_user_2", "should_fail": False}
        ]

        async def run_session_with_failure_simulation(config):
            """Run session with potential failure simulation."""
            user_id = config["user_id"]
            should_fail = config["should_fail"]

            # Start session
            start_response = await async_client.post(
                "/conversation/start",
                json={"user_id": user_id}
            )

            if start_response.status_code != 201:
                return {"error": "Failed to start", "user_id": user_id}

            session_id = start_response.json()["session_id"]

            # Submit query
            if should_fail:
                # Submit corrupted data to simulate failure
                audio_data = b"corrupted_data_to_cause_failure"
            else:
                # Submit normal data
                audio_data = f"normal_query_{user_id}".encode()

            files = {
                "audio_data": (f"{user_id}.wav", io.BytesIO(audio_data), "audio/wav")
            }

            query_response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": "wav"}
            )

            return {
                "user_id": user_id,
                "session_id": session_id,
                "should_fail": should_fail,
                "query_status": query_response.status_code,
                "actual_success": query_response.status_code == 200
            }

        # Run sessions concurrently
        session_tasks = [
            run_session_with_failure_simulation(config)
            for config in session_configs
        ]

        results = await asyncio.gather(*session_tasks, return_exceptions=True)

        # Analyze results
        stable_sessions = [r for r in results if isinstance(r, dict) and not r.get("should_fail")]
        failing_sessions = [r for r in results if isinstance(r, dict) and r.get("should_fail")]

        # Stable sessions should succeed despite failures elsewhere
        stable_success_count = sum(1 for s in stable_sessions if s.get("actual_success"))

        # At least some stable sessions should succeed
        assert stable_success_count > 0

        # System should handle failures gracefully (not crash)
        for session in failing_sessions:
            # Failing sessions should return appropriate error codes
            assert session["query_status"] in [400, 422, 500]

    @pytest.mark.asyncio
    async def test_concurrent_sessions_constitutional_compliance(self, async_client: AsyncClient):
        """Test concurrent sessions meet constitutional requirements."""
        # Test multiple sessions meeting <800ms requirement simultaneously
        num_sessions = 3

        async def compliant_session(index: int):
            """Run session and measure constitutional compliance."""
            start_time = time.time()

            # Start session
            start_response = await async_client.post(
                "/conversation/start",
                json={"user_id": f"compliant_user_{index}"}
            )

            if start_response.status_code != 201:
                return {"error": "Failed to start", "index": index}

            session_id = start_response.json()["session_id"]

            # Submit query with timing measurement
            audio_data = f"constitutional_test_query_{index}".encode()
            files = {
                "audio_data": (f"constitutional_{index}.wav", io.BytesIO(audio_data), "audio/wav")
            }

            query_start = time.time()
            query_response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data={"audio_format": "wav"}
            )
            query_end = time.time()

            total_time = (query_end - start_time) * 1000
            query_time = (query_end - query_start) * 1000

            return {
                "index": index,
                "session_id": session_id,
                "total_time_ms": total_time,
                "query_time_ms": query_time,
                "status": query_response.status_code,
                "meets_requirement": query_time <= 800,
                "query_data": query_response.json() if query_response.status_code == 200 else None
            }

        # Run compliant sessions concurrently
        compliance_results = await asyncio.gather(*[
            compliant_session(i) for i in range(num_sessions)
        ])

        # Verify constitutional compliance
        successful_sessions = [r for r in compliance_results if isinstance(r, dict) and not r.get("error")]

        # At least majority should succeed
        assert len(successful_sessions) >= num_sessions // 2

        # Check latency requirements
        compliant_sessions = [s for s in successful_sessions if s.get("meets_requirement")]

        # Constitutional requirement: <800ms response time should be met even under concurrent load
        compliance_rate = len(compliant_sessions) / len(successful_sessions) if successful_sessions else 0
        assert compliance_rate >= 0.7  # At least 70% should meet timing requirement

        # Verify reported processing times
        for session in compliant_sessions:
            if session.get("query_data") and "processing_time_ms" in session["query_data"]:
                reported_time = session["query_data"]["processing_time_ms"]
                assert reported_time <= 800  # Reported time should also be compliant