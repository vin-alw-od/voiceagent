"""Contract tests for GET /health endpoint."""
import pytest
from httpx import AsyncClient
from unittest.mock import AsyncMock, patch


class TestHealthContract:
    """Contract tests for health check endpoint."""

    @pytest.mark.asyncio
    async def test_health_check_success(self, async_client: AsyncClient):
        """Test successful health check."""
        # Act
        response = await async_client.get("/health")

        # Assert
        assert response.status_code == 200
        data = response.json()

        # Verify response structure matches HealthStatus schema
        assert "status" in data
        assert "timestamp" in data
        assert "services" in data

        # Verify status enum values
        assert data["status"] in ["healthy", "degraded", "unhealthy"]

        # Verify timestamp format
        import datetime
        try:
            datetime.datetime.fromisoformat(data["timestamp"].replace('Z', '+00:00'))
        except ValueError:
            pytest.fail("Invalid timestamp format")

        # Verify services structure
        services = data["services"]
        assert isinstance(services, dict)

        # Expected services to monitor
        expected_services = [
            "azure_openai",
            "vector_database",
            "transcript_database"
        ]

        for service in expected_services:
            if service in services:
                assert services[service] in ["up", "down", "degraded"]

        # Optional fields
        if "latency_ms" in data:
            assert isinstance(data["latency_ms"], (int, float))
            assert data["latency_ms"] >= 0

    @pytest.mark.asyncio
    async def test_health_check_unhealthy_services(self, async_client: AsyncClient):
        """Test health check when services are down."""
        # Mock unhealthy services
        with patch("src.integrations.azure_openai_client.health_check") as mock_azure_health:
            mock_azure_health.return_value = False

            # Act
            response = await async_client.get("/health")

            # Assert
            # Service should still respond but indicate degraded/unhealthy status
            assert response.status_code in [200, 503]

            if response.status_code == 200:
                data = response.json()
                assert data["status"] in ["degraded", "unhealthy"]

                if "services" in data and "azure_openai" in data["services"]:
                    assert data["services"]["azure_openai"] in ["down", "degraded"]

    @pytest.mark.asyncio
    async def test_health_check_performance(self, async_client: AsyncClient):
        """Test health check response time."""
        import time

        # Act
        start_time = time.time()
        response = await async_client.get("/health")
        end_time = time.time()

        # Assert
        response_time_ms = (end_time - start_time) * 1000

        # Health check should be very fast
        assert response_time_ms < 50  # 50ms for health check

        if response.status_code == 200:
            data = response.json()
            # Verify reported latency matches actual
            if "latency_ms" in data:
                reported_latency = data["latency_ms"]
                # Should be roughly similar (within reason)
                assert abs(reported_latency - response_time_ms) < 100

    @pytest.mark.asyncio
    async def test_health_check_database_connectivity(self, async_client: AsyncClient):
        """Test health check includes database connectivity."""
        # Act
        response = await async_client.get("/health")

        # Assert
        if response.status_code == 200:
            data = response.json()
            services = data.get("services", {})

            # Should check transcript database connectivity
            if "transcript_database" in services:
                db_status = services["transcript_database"]
                assert db_status in ["up", "down", "degraded"]

                # If database is up, overall status should not be unhealthy
                if db_status == "up":
                    assert data["status"] != "unhealthy"

    @pytest.mark.asyncio
    async def test_health_check_vector_database_connectivity(self, async_client: AsyncClient):
        """Test health check includes vector database connectivity."""
        # Act
        response = await async_client.get("/health")

        # Assert
        if response.status_code == 200:
            data = response.json()
            services = data.get("services", {})

            # Should check vector database connectivity
            if "vector_database" in services:
                vector_status = services["vector_database"]
                assert vector_status in ["up", "down", "degraded"]

    @pytest.mark.asyncio
    async def test_health_check_azure_openai_connectivity(self, async_client: AsyncClient):
        """Test health check includes Azure OpenAI connectivity."""
        # Act
        response = await async_client.get("/health")

        # Assert
        if response.status_code == 200:
            data = response.json()
            services = data.get("services", {})

            # Should check Azure OpenAI connectivity
            if "azure_openai" in services:
                azure_status = services["azure_openai"]
                assert azure_status in ["up", "down", "degraded"]

                # Azure OpenAI is critical for core functionality
                if azure_status == "down":
                    assert data["status"] in ["degraded", "unhealthy"]

    @pytest.mark.asyncio
    async def test_health_check_no_authentication_required(self, async_client: AsyncClient):
        """Test that health check doesn't require authentication."""
        # Act - Make request without authentication headers
        response = await async_client.get("/health")

        # Assert - Should succeed without authentication
        assert response.status_code in [200, 503]  # Not 401/403

    @pytest.mark.asyncio
    async def test_health_check_consistent_format(self, async_client: AsyncClient):
        """Test health check response format consistency."""
        # Make multiple requests
        responses = []
        for _ in range(3):
            response = await async_client.get("/health")
            responses.append(response)

        # All should have same structure
        for response in responses:
            if response.status_code == 200:
                data = response.json()

                # Required fields should always be present
                required_fields = ["status", "timestamp", "services"]
                for field in required_fields:
                    assert field in data

                # Status should be valid enum value
                assert data["status"] in ["healthy", "degraded", "unhealthy"]

    @pytest.mark.asyncio
    async def test_health_check_detailed_service_info(self, async_client: AsyncClient):
        """Test health check provides useful service information."""
        # Act
        response = await async_client.get("/health")

        # Assert
        if response.status_code == 200:
            data = response.json()

            # Should provide actionable information
            expected_service_details = {
                "azure_openai": "Azure OpenAI API connectivity",
                "vector_database": "Vector database (ChromaDB) connectivity",
                "transcript_database": "PostgreSQL database connectivity"
            }

            # At minimum should report service status
            services = data.get("services", {})
            assert len(services) > 0  # Should check at least one service

            # Each service should have meaningful status
            for service_name, status in services.items():
                assert status in ["up", "down", "degraded"]
                assert service_name in expected_service_details