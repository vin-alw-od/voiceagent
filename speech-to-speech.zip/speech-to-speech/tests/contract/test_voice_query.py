"""Contract tests for POST /conversation/{id}/query endpoint."""
import pytest
from httpx import AsyncClient
import io
from unittest.mock import AsyncMock, patch


class TestVoiceQueryContract:
    """Contract tests for voice query processing endpoint."""

    @pytest.mark.asyncio
    async def test_process_voice_query_success(self, async_client: AsyncClient):
        """Test successful voice query processing."""
        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"

        # Create mock audio data
        audio_data = b"fake_audio_data"
        files = {
            "audio_data": ("test_audio.wav", io.BytesIO(audio_data), "audio/wav")
        }
        data = {
            "audio_format": "wav"
        }

        # Act
        response = await async_client.post(
            f"/conversation/{session_id}/query",
            files=files,
            data=data
        )

        # Assert
        assert response.status_code == 200
        response_data = response.json()

        # Verify response structure matches VoiceQueryResponse schema
        assert "query_id" in response_data
        assert "transcription" in response_data
        assert "response_text" in response_data
        assert "audio_url" in response_data
        assert "processing_time_ms" in response_data
        assert "source_documents" in response_data

        # Verify response constraints
        assert isinstance(response_data["processing_time_ms"], int)
        assert response_data["processing_time_ms"] <= 800  # Constitutional requirement
        assert isinstance(response_data["source_documents"], list)

        # Optional fields
        if "confidence_score" in response_data:
            assert 0.0 <= response_data["confidence_score"] <= 1.0

    @pytest.mark.asyncio
    async def test_process_voice_query_missing_audio(self, async_client: AsyncClient):
        """Test voice query processing with missing audio data."""
        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"
        data = {"audio_format": "wav"}

        # Act
        response = await async_client.post(
            f"/conversation/{session_id}/query",
            data=data
        )

        # Assert
        assert response.status_code == 400
        error_data = response.json()
        assert "error" in error_data
        assert "message" in error_data
        assert "audio" in error_data["message"].lower()

    @pytest.mark.asyncio
    async def test_process_voice_query_invalid_session_id(self, async_client: AsyncClient):
        """Test voice query processing with invalid session ID."""
        # Arrange
        session_id = "invalid-session-id"
        audio_data = b"fake_audio_data"
        files = {
            "audio_data": ("test_audio.wav", io.BytesIO(audio_data), "audio/wav")
        }
        data = {"audio_format": "wav"}

        # Act
        response = await async_client.post(
            f"/conversation/{session_id}/query",
            files=files,
            data=data
        )

        # Assert
        assert response.status_code == 404
        error_data = response.json()
        assert "error" in error_data
        assert "message" in error_data

    @pytest.mark.asyncio
    async def test_process_voice_query_large_file(self, async_client: AsyncClient):
        """Test voice query processing with file size limit."""
        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"

        # Create audio data larger than 10MB limit
        large_audio_data = b"x" * (11 * 1024 * 1024)  # 11MB
        files = {
            "audio_data": ("large_audio.wav", io.BytesIO(large_audio_data), "audio/wav")
        }
        data = {"audio_format": "wav"}

        # Act
        response = await async_client.post(
            f"/conversation/{session_id}/query",
            files=files,
            data=data
        )

        # Assert
        assert response.status_code == 400
        error_data = response.json()
        assert "error" in error_data
        assert any(keyword in error_data["message"].lower() for keyword in ["size", "large", "limit"])

    @pytest.mark.asyncio
    async def test_process_voice_query_unsupported_format(self, async_client: AsyncClient):
        """Test voice query processing with unsupported audio format."""
        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"
        audio_data = b"fake_audio_data"
        files = {
            "audio_data": ("test_audio.xyz", io.BytesIO(audio_data), "audio/xyz")
        }
        data = {"audio_format": "xyz"}

        # Act
        response = await async_client.post(
            f"/conversation/{session_id}/query",
            files=files,
            data=data
        )

        # Assert
        assert response.status_code == 400
        error_data = response.json()
        assert "error" in error_data
        assert "format" in error_data["message"].lower()

    @pytest.mark.asyncio
    async def test_process_voice_query_timeout(self, async_client: AsyncClient):
        """Test voice query processing timeout behavior."""
        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"
        audio_data = b"fake_audio_data"
        files = {
            "audio_data": ("test_audio.wav", io.BytesIO(audio_data), "audio/wav")
        }
        data = {"audio_format": "wav"}

        # Simulate processing timeout
        with patch("src.services.audio_processing_service.process_audio") as mock_process:
            mock_process.side_effect = TimeoutError("Processing timeout")

            # Act
            response = await async_client.post(
                f"/conversation/{session_id}/query",
                files=files,
                data=data
            )

            # Assert - This will fail until timeout handling is implemented
            assert response.status_code in [200, 408]  # Should be 408 when timeout handling works

    @pytest.mark.asyncio
    async def test_process_voice_query_performance_requirement(self, async_client: AsyncClient):
        """Test voice query processing meets performance requirements."""
        import time

        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"
        audio_data = b"fake_audio_data"
        files = {
            "audio_data": ("test_audio.wav", io.BytesIO(audio_data), "audio/wav")
        }
        data = {"audio_format": "wav"}

        # Act
        start_time = time.time()
        response = await async_client.post(
            f"/conversation/{session_id}/query",
            files=files,
            data=data
        )
        end_time = time.time()

        # Assert
        response_time_ms = (end_time - start_time) * 1000

        if response.status_code == 200:
            # Constitutional requirement: <800ms end-to-end
            assert response_time_ms <= 800

            # Also check reported processing time
            response_data = response.json()
            assert response_data["processing_time_ms"] <= 800