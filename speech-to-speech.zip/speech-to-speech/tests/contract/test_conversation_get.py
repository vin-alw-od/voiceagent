"""Contract tests for GET /conversation/{id} endpoint."""
import pytest
from httpx import AsyncClient
from unittest.mock import AsyncMock, patch


class TestConversationGetContract:
    """Contract tests for conversation retrieval endpoint."""

    @pytest.mark.asyncio
    async def test_get_conversation_success(self, async_client: AsyncClient):
        """Test successful conversation retrieval."""
        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"

        # Act
        response = await async_client.get(f"/conversation/{session_id}")

        # Assert
        assert response.status_code == 200
        data = response.json()

        # Verify response structure matches ConversationSession schema
        assert "session_id" in data
        assert "user_id" in data
        assert "status" in data
        assert "started_at" in data
        assert "last_activity_at" in data
        assert "context_data" in data
        assert "performance_metrics" in data

        # Verify data types
        assert isinstance(data["session_id"], str)
        assert isinstance(data["user_id"], str)
        assert data["status"] in ["active", "completed", "failed", "timeout"]
        assert isinstance(data["context_data"], dict)
        assert isinstance(data["performance_metrics"], dict)

        # Verify performance metrics structure
        if data["performance_metrics"]:
            metrics = data["performance_metrics"]
            if "average_response_time_ms" in metrics:
                assert isinstance(metrics["average_response_time_ms"], (int, float))
            if "total_queries" in metrics:
                assert isinstance(metrics["total_queries"], int)

    @pytest.mark.asyncio
    async def test_get_conversation_not_found(self, async_client: AsyncClient):
        """Test conversation retrieval with non-existent session ID."""
        # Arrange
        session_id = "nonexistent-session-id"

        # Act
        response = await async_client.get(f"/conversation/{session_id}")

        # Assert
        assert response.status_code == 404
        error_data = response.json()

        # Verify error response structure
        assert "error" in error_data
        assert "message" in error_data
        assert "session" in error_data["message"].lower()

    @pytest.mark.asyncio
    async def test_get_conversation_invalid_uuid_format(self, async_client: AsyncClient):
        """Test conversation retrieval with invalid UUID format."""
        # Arrange
        session_id = "invalid-uuid-format"

        # Act
        response = await async_client.get(f"/conversation/{session_id}")

        # Assert
        assert response.status_code in [400, 404]
        error_data = response.json()

        # Verify error response structure
        assert "error" in error_data
        assert "message" in error_data

    @pytest.mark.asyncio
    async def test_get_conversation_expired_session(self, async_client: AsyncClient):
        """Test conversation retrieval for expired session."""
        # Arrange
        session_id = "expired-session-id"

        # Mock expired session behavior
        with patch("src.services.conversation_service.get_conversation") as mock_get:
            mock_get.return_value = None  # Simulates expired/deleted session

            # Act
            response = await async_client.get(f"/conversation/{session_id}")

            # Assert
            assert response.status_code == 404
            error_data = response.json()
            assert "error" in error_data

    @pytest.mark.asyncio
    async def test_get_conversation_different_statuses(self, async_client: AsyncClient):
        """Test conversation retrieval for different session statuses."""
        # Test active session
        active_session_id = "active-session-id"
        response = await async_client.get(f"/conversation/{active_session_id}")

        if response.status_code == 200:
            data = response.json()
            assert data["status"] in ["active", "completed", "failed", "timeout"]

        # Additional status-specific assertions would go here
        # For now, we document the expected behaviors

        expected_status_behaviors = {
            "active": {
                "description": "Session is currently processing queries",
                "editable": True,
                "query_processing": "allowed"
            },
            "completed": {
                "description": "Session ended normally",
                "editable": False,
                "query_processing": "not_allowed"
            },
            "failed": {
                "description": "Session ended due to error",
                "editable": False,
                "query_processing": "not_allowed"
            },
            "timeout": {
                "description": "Session ended due to inactivity",
                "editable": False,
                "query_processing": "not_allowed"
            }
        }

        assert expected_status_behaviors is not None

    @pytest.mark.asyncio
    async def test_get_conversation_performance_metrics(self, async_client: AsyncClient):
        """Test conversation retrieval includes correct performance metrics."""
        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"

        # Act
        response = await async_client.get(f"/conversation/{session_id}")

        # Assert
        if response.status_code == 200:
            data = response.json()
            metrics = data.get("performance_metrics", {})

            # Expected metrics structure
            expected_metrics = [
                "average_response_time_ms",
                "total_queries",
                "successful_queries",
                "failed_queries",
                "total_duration_seconds"
            ]

            # Verify metrics are present and valid
            for metric in expected_metrics:
                if metric in metrics:
                    if "time_ms" in metric or "duration" in metric:
                        assert isinstance(metrics[metric], (int, float))
                        assert metrics[metric] >= 0
                    elif "queries" in metric:
                        assert isinstance(metrics[metric], int)
                        assert metrics[metric] >= 0

    @pytest.mark.asyncio
    async def test_get_conversation_context_data_privacy(self, async_client: AsyncClient):
        """Test that sensitive data is not exposed in conversation retrieval."""
        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"

        # Act
        response = await async_client.get(f"/conversation/{session_id}")

        # Assert
        if response.status_code == 200:
            data = response.json()
            context_data = data.get("context_data", {})

            # Ensure no sensitive data is exposed
            sensitive_fields = [
                "api_key",
                "password",
                "token",
                "secret",
                "private_key",
                "azure_key"
            ]

            def check_no_sensitive_data(obj, path=""):
                if isinstance(obj, dict):
                    for key, value in obj.items():
                        full_path = f"{path}.{key}" if path else key
                        assert not any(sensitive in key.lower() for sensitive in sensitive_fields), \
                            f"Sensitive field found: {full_path}"
                        if isinstance(value, (dict, list)):
                            check_no_sensitive_data(value, full_path)
                elif isinstance(obj, list):
                    for i, item in enumerate(obj):
                        if isinstance(item, (dict, list)):
                            check_no_sensitive_data(item, f"{path}[{i}]")

            check_no_sensitive_data(data)

    @pytest.mark.asyncio
    async def test_get_conversation_response_time(self, async_client: AsyncClient):
        """Test conversation retrieval response time."""
        import time

        # Arrange
        session_id = "123e4567-e89b-12d3-a456-426614174000"

        # Act
        start_time = time.time()
        response = await async_client.get(f"/conversation/{session_id}")
        end_time = time.time()

        # Assert
        response_time_ms = (end_time - start_time) * 1000

        # Should be fast retrieval (much faster than processing)
        assert response_time_ms < 100  # 100ms for database lookup

        if response.status_code == 200:
            # Verify response is complete
            data = response.json()
            assert "session_id" in data