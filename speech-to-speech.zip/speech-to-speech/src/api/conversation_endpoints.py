"""FastAPI conversation endpoints with constitutional compliance."""
import asyncio
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from uuid import UUID
import logging

from fastapi import APIRouter, HTTPException, Depends, File, UploadFile, Form, status
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from ..services.conversation_service import ConversationService, get_conversation_service
from ..services.audio_processing_service import AudioProcessingService, get_audio_processing_service
from ..services.vector_search_service import VectorSearchService, get_vector_search_service
from ..services.transcript_service import TranscriptService, get_transcript_service
from ..models.conversation_session import ConversationSession, SessionStatus
from ..models.voice_query import VoiceQuery, AudioFormat
from ..models.transcript_record import TranscriptRecord, RecordType

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/conversation", tags=["conversations"])


# Pydantic models for request/response
class ConversationStartRequest(BaseModel):
    """Request model for starting a conversation."""
    user_id: str = Field(..., min_length=1, max_length=255, description="User identifier")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Initial conversation context")
    session_config: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Session configuration")


class ConversationStartResponse(BaseModel):
    """Response model for conversation start."""
    session_id: str
    user_id: str
    status: str
    created_at: str
    expires_at: Optional[str]
    context_data: Dict[str, Any]
    constitutional_compliance: Dict[str, Any]


class VoiceQueryRequest(BaseModel):
    """Request model for voice query (form data)."""
    audio_format: str = Field(..., description="Audio format (wav, mp3, etc.)")


class VoiceQueryResponse(BaseModel):
    """Response model for voice query."""
    query_id: str
    session_id: str
    transcription: str
    response_text: str
    audio_url: Optional[str]
    processing_time_ms: float
    confidence_score: float
    audio_quality_score: float
    status: str
    constitutional_compliant: bool
    cost_summary: Dict[str, Any]
    quality_assessment: Dict[str, Any]


class ConversationUpdateRequest(BaseModel):
    """Request model for conversation updates."""
    status: Optional[str] = None
    context_data: Optional[Dict[str, Any]] = None
    session_config: Optional[Dict[str, Any]] = None
    completion_reason: Optional[str] = None


# Dependency injection
async def get_conversation_service() -> ConversationService:
    """Get conversation service instance."""
    return ConversationService()


async def get_audio_service() -> AudioProcessingService:
    """Get audio processing service instance."""
    return AudioProcessingService()


async def get_vector_service() -> VectorSearchService:
    """Get vector search service instance."""
    return VectorSearchService()


async def get_transcript_service() -> TranscriptService:
    """Get transcript service instance."""
    return TranscriptService()


@router.post("/start", response_model=ConversationStartResponse, status_code=status.HTTP_201_CREATED)
async def start_conversation(
    request: ConversationStartRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
    transcript_service: TranscriptService = Depends(get_transcript_service)
):
    """
    Start a new conversation session.

    Creates a new conversation session with constitutional compliance tracking.
    Initializes performance monitoring and cost optimization settings.
    """
    start_time = time.time()

    try:
        # Create conversation session
        session = await conversation_service.create_session(
            user_id=request.user_id,
            context=request.context,
            session_config=request.session_config
        )

        # Log conversation start in transcript
        await transcript_service.create_transcript_record(
            session_id=session.session_id,
            user_id=session.user_id,
            content=f"Conversation started by user {request.user_id}",
            record_type=RecordType.CONVERSATION_START,
            context=request.context
        )

        # Check constitutional compliance for response time
        response_time_ms = (time.time() - start_time) * 1000
        if response_time_ms > 800.0:
            logger.warning(f"Conversation start exceeded 800ms: {response_time_ms}ms")

        # Prepare response
        response = ConversationStartResponse(
            session_id=str(session.session_id),
            user_id=session.user_id,
            status=session.status.value,
            created_at=session.created_at.isoformat(),
            expires_at=session.expires_at.isoformat() if session.expires_at else None,
            context_data=session.context_data,
            constitutional_compliance={
                "latency_requirement_met": response_time_ms <= 800.0,
                "actual_latency_ms": response_time_ms,
                "cost_optimization_enabled": session.optimization_flags.get("caching_enabled", True),
                "privacy_compliance_active": True
            }
        )

        logger.info(f"Started conversation session {session.session_id} for user {request.user_id}")
        return response

    except Exception as e:
        logger.error(f"Failed to start conversation: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to start conversation: {str(e)}"
        )


@router.post("/{session_id}/query", response_model=VoiceQueryResponse)
async def process_voice_query(
    session_id: UUID,
    audio_data: UploadFile = File(..., description="Audio file for voice query"),
    audio_format: str = Form(..., description="Audio format (wav, mp3, etc.)"),
    conversation_service: ConversationService = Depends(get_conversation_service),
    audio_service: AudioProcessingService = Depends(get_audio_service),
    vector_service: VectorSearchService = Depends(get_vector_service),
    transcript_service: TranscriptService = Depends(get_transcript_service)
):
    """
    Process a voice query with constitutional compliance.

    Handles the complete voice-to-voice pipeline:
    1. Audio transcription
    2. Knowledge retrieval
    3. Response generation
    4. Audio synthesis
    5. Transcript logging
    """
    start_time = time.time()

    try:
        # Get session
        session = await conversation_service.get_session(session_id)

        # Read audio data
        audio_bytes = await audio_data.read()
        if len(audio_bytes) == 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Empty audio file"
            )

        # Create voice query
        query = VoiceQuery(
            session_id=session_id,
            user_id=session.user_id,
            audio_format=AudioFormat(audio_format)
        )

        # Process audio input
        query = await audio_service.process_voice_input(
            audio_bytes, AudioFormat(audio_format), query
        )

        # Log transcription
        await transcript_service.create_transcript_record(
            session_id=session_id,
            user_id=session.user_id,
            content=query.transcription,
            record_type=RecordType.USER_QUERY,
            query_id=query.query_id,
            context={"confidence": query.transcription_metrics.confidence_score}
        )

        # Perform knowledge search
        knowledge_response = await vector_service.search_knowledge(
            query_text=query.transcription,
            user_context=session.context_data,
            session_id=session_id,
            user_id=session.user_id
        )
        knowledge_response.query_id = query.query_id

        # Generate audio response
        audio_response = await audio_service.generate_audio_response(
            text=knowledge_response.response_text,
            query_id=query.query_id,
            knowledge_response_id=knowledge_response.response_id,
            session_id=session_id,
            user_id=session.user_id
        )

        # Update query with response
        query.set_response(
            knowledge_response.response_text,
            audio_response.audio_url,
            knowledge_response.quality_metrics.relevance_score,
            knowledge_response.total_cost_usd + audio_response.total_cost_usd
        )

        # Complete query processing
        query.complete_processing(success=True)

        # Log system response
        await transcript_service.create_transcript_record(
            session_id=session_id,
            user_id=session.user_id,
            content=knowledge_response.response_text,
            record_type=RecordType.SYSTEM_RESPONSE,
            query_id=query.query_id,
            context={
                "sources_used": len(knowledge_response.knowledge_sources),
                "audio_generated": audio_response.audio_url is not None
            }
        )

        # Update session metrics
        await conversation_service.record_query_metrics(session_id, query)

        # Check constitutional compliance
        total_time_ms = (time.time() - start_time) * 1000
        constitutional_compliant = total_time_ms <= 800.0

        if not constitutional_compliant:
            logger.warning(f"Voice query exceeded 800ms: {total_time_ms}ms")

        # Prepare response
        response = VoiceQueryResponse(
            query_id=str(query.query_id),
            session_id=str(session_id),
            transcription=query.transcription,
            response_text=knowledge_response.response_text,
            audio_url=audio_response.audio_url,
            processing_time_ms=total_time_ms,
            confidence_score=query.transcription_metrics.confidence_score,
            audio_quality_score=query.audio_metrics.audio_quality_score,
            status=query.status.value,
            constitutional_compliant=constitutional_compliant,
            cost_summary={
                "total_cost_usd": query.total_cost_usd,
                "cost_breakdown": query.cost_breakdown
            },
            quality_assessment=query.get_quality_assessment()
        )

        logger.info(f"Processed voice query {query.query_id} in {total_time_ms:.1f}ms")
        return response

    except Exception as e:
        # Log error
        error_msg = f"Voice query processing failed: {str(e)}"
        logger.error(error_msg)

        # Create error transcript record
        try:
            await transcript_service.create_transcript_record(
                session_id=session_id,
                user_id=session.user_id if 'session' in locals() else "unknown",
                content=error_msg,
                record_type=RecordType.ERROR_EVENT,
                context={"error_type": type(e).__name__}
            )
        except:
            pass  # Don't fail on transcript logging error

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=error_msg
        )


@router.get("/{session_id}/stream")
async def stream_conversation_updates(
    session_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service)
):
    """
    Stream real-time conversation updates via Server-Sent Events.

    Provides real-time updates on conversation status, processing progress,
    and constitutional compliance metrics.
    """
    try:
        # Verify session exists
        session = await conversation_service.get_session(session_id)

        async def generate_stream():
            """Generate SSE stream for conversation updates."""
            try:
                while True:
                    # Get current session state
                    current_session = await conversation_service.get_session(session_id)

                    # Prepare update data
                    update_data = {
                        "session_id": str(session_id),
                        "status": current_session.status.value,
                        "query_count": current_session.query_count,
                        "performance_metrics": current_session.performance_metrics.dict(),
                        "constitutional_compliance": {
                            "latency_compliant": current_session.compliance_flags.get("latency_requirement", True),
                            "average_latency_ms": current_session.performance_metrics.average_latency_ms
                        },
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    }

                    # Send update as SSE
                    yield f"data: {json.dumps(update_data)}\n\n"

                    # Check if session is completed
                    if current_session.status in [SessionStatus.COMPLETED, SessionStatus.EXPIRED]:
                        break

                    # Wait before next update
                    await asyncio.sleep(1.0)

            except Exception as e:
                logger.error(f"Stream error: {str(e)}")
                yield f"data: {json.dumps({'error': str(e)})}\n\n"

        return StreamingResponse(
            generate_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "Access-Control-Allow-Origin": "*"
            }
        )

    except Exception as e:
        logger.error(f"Failed to start conversation stream: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Stream initialization failed: {str(e)}"
        )


@router.get("/{session_id}")
async def get_conversation(
    session_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service)
):
    """
    Get conversation session details.

    Returns comprehensive session information including performance metrics,
    constitutional compliance status, and cost analysis.
    """
    try:
        # Get session
        session = await conversation_service.get_session(session_id)

        # Get analytics
        analytics = await conversation_service.get_session_analytics(session_id)

        # Combine session data with analytics
        response_data = session.to_api_response()
        response_data["analytics"] = analytics

        return response_data

    except Exception as e:
        logger.error(f"Failed to get conversation {session_id}: {str(e)}")
        if "not found" in str(e).lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Conversation {session_id} not found"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to retrieve conversation: {str(e)}"
            )


@router.patch("/{session_id}")
async def update_conversation(
    session_id: UUID,
    request: ConversationUpdateRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
    transcript_service: TranscriptService = Depends(get_transcript_service)
):
    """
    Update conversation session.

    Allows updating session status, context, and configuration while
    maintaining constitutional compliance and audit trail.
    """
    try:
        # Prepare updates
        updates = {}
        if request.status is not None:
            updates["status"] = request.status
        if request.context_data is not None:
            updates["context_data"] = request.context_data
        if request.session_config is not None:
            updates["session_config"] = request.session_config
        if request.completion_reason is not None:
            updates["completion_reason"] = request.completion_reason

        # Update session
        session = await conversation_service.update_session(session_id, updates)

        # Log session update
        await transcript_service.create_transcript_record(
            session_id=session_id,
            user_id=session.user_id,
            content=f"Session updated: {', '.join(updates.keys())}",
            record_type=RecordType.SYSTEM_EVENT,
            context={"updates": list(updates.keys())}
        )

        # Log conversation end if completed
        if request.status == SessionStatus.COMPLETED.value:
            await transcript_service.create_transcript_record(
                session_id=session_id,
                user_id=session.user_id,
                content=f"Conversation ended: {request.completion_reason or 'manual'}",
                record_type=RecordType.CONVERSATION_END,
                context={"reason": request.completion_reason or "manual"}
            )

        return session.to_api_response()

    except Exception as e:
        logger.error(f"Failed to update conversation {session_id}: {str(e)}")
        if "not found" in str(e).lower():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Conversation {session_id} not found"
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to update conversation: {str(e)}"
            )