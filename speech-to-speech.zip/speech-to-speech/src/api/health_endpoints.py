"""Health monitoring endpoints with constitutional compliance."""
import asyncio
import time
from datetime import datetime, timezone
from typing import Dict, Any, List
import logging

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel

from ..services.conversation_service import ConversationService
from ..integrations.azure_openai_client import get_azure_client
from ..integrations.vector_database_client import get_vector_db_client
from ..integrations.database_client import get_database_client

logger = logging.getLogger(__name__)

router = APIRouter(tags=["health"])


class HealthResponse(BaseModel):
    """Health check response model."""
    status: str
    timestamp: str
    services: Dict[str, Any]
    constitutional_compliance: Dict[str, Any]
    overall_healthy: bool


class ServiceHealth(BaseModel):
    """Individual service health model."""
    name: str
    status: str
    response_time_ms: float
    details: Dict[str, Any]


@router.get("/health", response_model=HealthResponse)
async def health_check():
    """
    Comprehensive health check for all system components.

    Checks the health of all services and validates constitutional compliance:
    - Azure OpenAI API connectivity and performance
    - Vector database (ChromaDB) status
    - PostgreSQL database connectivity
    - Overall system performance metrics
    """
    start_time = time.time()

    try:
        # Initialize services
        conversation_service = ConversationService()

        # Perform health checks in parallel for speed
        health_tasks = [
            _check_azure_openai_health(),
            _check_vector_database_health(),
            _check_postgresql_health(),
            _check_conversation_service_health(conversation_service)
        ]

        health_results = await asyncio.gather(*health_tasks, return_exceptions=True)

        # Process results
        services = {}
        overall_healthy = True

        service_names = ["azure_openai", "vector_database", "postgresql", "conversation_service"]

        for i, result in enumerate(health_results):
            service_name = service_names[i]

            if isinstance(result, Exception):
                services[service_name] = {
                    "status": "unhealthy",
                    "error": str(result),
                    "response_time_ms": 0
                }
                overall_healthy = False
            else:
                services[service_name] = result
                if result["status"] != "healthy":
                    overall_healthy = False

        # Check constitutional compliance
        total_time_ms = (time.time() - start_time) * 1000
        latency_compliant = total_time_ms <= 800.0

        if not latency_compliant:
            logger.warning(f"Health check exceeded 800ms: {total_time_ms}ms")

        # Calculate system metrics
        system_metrics = await _get_system_metrics(conversation_service)

        constitutional_compliance = {
            "health_check_latency_ms": total_time_ms,
            "latency_requirement_met": latency_compliant,
            "services_healthy_count": sum(1 for s in services.values() if s["status"] == "healthy"),
            "total_services": len(services),
            "system_performance": system_metrics
        }

        # Determine overall status
        if overall_healthy and latency_compliant:
            overall_status = "healthy"
        elif not latency_compliant:
            overall_status = "degraded"
        else:
            overall_status = "unhealthy"

        response = HealthResponse(
            status=overall_status,
            timestamp=datetime.now(timezone.utc).isoformat(),
            services=services,
            constitutional_compliance=constitutional_compliance,
            overall_healthy=overall_healthy and latency_compliant
        )

        logger.info(f"Health check completed in {total_time_ms:.1f}ms - Status: {overall_status}")
        return response

    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")

        # Return error response
        error_response = HealthResponse(
            status="error",
            timestamp=datetime.now(timezone.utc).isoformat(),
            services={"error": {"status": "failed", "error": str(e)}},
            constitutional_compliance={"health_check_failed": True},
            overall_healthy=False
        )

        return error_response


async def _check_azure_openai_health() -> Dict[str, Any]:
    """Check Azure OpenAI service health."""
    try:
        azure_client = await get_azure_client()
        health_result = await azure_client.check_health()

        return {
            "status": health_result["status"],
            "response_time_ms": health_result["response_time_ms"],
            "circuit_breaker_open": health_result["circuit_breaker_open"],
            "failure_count": health_result["failure_count"],
            "details": {
                "service": "Azure OpenAI",
                "capabilities": ["speech-to-text", "text-to-speech"],
                "last_check": health_result["last_check"]
            }
        }

    except Exception as e:
        logger.error(f"Azure OpenAI health check failed: {str(e)}")
        return {
            "status": "unhealthy",
            "response_time_ms": 0,
            "error": str(e),
            "details": {"service": "Azure OpenAI"}
        }


async def _check_vector_database_health() -> Dict[str, Any]:
    """Check vector database (ChromaDB) health."""
    try:
        vector_client = await get_vector_db_client()
        health_result = await vector_client.health_check()

        return {
            "status": health_result["status"],
            "response_time_ms": health_result["response_time_ms"],
            "collections_available": health_result["collections_available"],
            "details": {
                "service": "ChromaDB Vector Database",
                "capabilities": ["semantic_search", "document_storage"],
                "default_collection_docs": health_result["default_collection_docs"]
            }
        }

    except Exception as e:
        logger.error(f"Vector database health check failed: {str(e)}")
        return {
            "status": "unhealthy",
            "response_time_ms": 0,
            "error": str(e),
            "details": {"service": "ChromaDB Vector Database"}
        }


async def _check_postgresql_health() -> Dict[str, Any]:
    """Check PostgreSQL database health."""
    try:
        db_client = await get_database_client()
        health_result = await db_client.health_check()

        return {
            "status": health_result["status"],
            "response_time_ms": 10.0,  # Estimated from connection test
            "connection_pool": health_result.get("pool_stats", {}),
            "details": {
                "service": "PostgreSQL Database",
                "capabilities": ["persistent_storage", "session_management", "transcript_storage"],
                "connection_test": health_result.get("connection_test", False)
            }
        }

    except Exception as e:
        logger.error(f"PostgreSQL health check failed: {str(e)}")
        return {
            "status": "unhealthy",
            "response_time_ms": 0,
            "error": str(e),
            "details": {"service": "PostgreSQL Database"}
        }


async def _check_conversation_service_health(conversation_service: ConversationService) -> Dict[str, Any]:
    """Check conversation service health."""
    try:
        start_time = time.time()

        # Get system metrics as health indicator
        metrics = await conversation_service.get_system_metrics()

        response_time_ms = (time.time() - start_time) * 1000

        # Determine health based on metrics
        status = "healthy"
        if metrics["current_sessions"] > 80:  # Near capacity
            status = "degraded"
        elif metrics["average_latency_ms"] > 800:
            status = "degraded"

        return {
            "status": status,
            "response_time_ms": response_time_ms,
            "current_sessions": metrics["current_sessions"],
            "average_latency_ms": metrics["average_latency_ms"],
            "details": {
                "service": "Conversation Service",
                "capabilities": ["session_management", "performance_tracking"],
                "system_health": metrics["system_health"]
            }
        }

    except Exception as e:
        logger.error(f"Conversation service health check failed: {str(e)}")
        return {
            "status": "unhealthy",
            "response_time_ms": 0,
            "error": str(e),
            "details": {"service": "Conversation Service"}
        }


async def _get_system_metrics(conversation_service: ConversationService) -> Dict[str, Any]:
    """Get overall system performance metrics."""
    try:
        metrics = await conversation_service.get_system_metrics()

        return {
            "current_load": {
                "active_sessions": metrics["current_sessions"],
                "capacity_utilization": metrics["current_sessions"] / 100.0  # Assuming 100 max sessions
            },
            "performance": {
                "average_latency_ms": metrics["average_latency_ms"],
                "constitutional_compliant": metrics["constitutional_compliance"]["latency_requirement_met"]
            },
            "cost_tracking": {
                "total_cost_usd": metrics["total_cost_usd"]
            }
        }

    except Exception as e:
        logger.error(f"Failed to get system metrics: {str(e)}")
        return {
            "error": str(e),
            "metrics_available": False
        }