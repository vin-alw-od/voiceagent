"""FastAPI main application with constitutional compliance."""
import asyncio
import logging
import time
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, Request, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
import os

from .conversation_endpoints import router as conversation_router
from .health_endpoints import router as health_router
from .metrics_endpoints import router as metrics_router
from .realtime_endpoints import router as realtime_router
from ..lib.config import get_settings
from ..lib.error_handling import setup_error_handlers
from ..services.conversation_service import ConversationService
from ..integrations.database_client import get_database_client

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager for startup and shutdown.

    Handles:
    - Database initialization
    - Service connections
    - Background tasks startup
    - Graceful shutdown
    """
    # Startup
    logger.info("Starting Speech-to-Speech Voice Assistant API")

    try:
        # Initialize database connection
        logger.info("Initializing database connection...")
        db_client = await get_database_client()

        # Initialize conversation service cleanup task
        logger.info("Starting background tasks...")
        cleanup_task = asyncio.create_task(periodic_cleanup())

        # Store cleanup task in app state
        app.state.cleanup_task = cleanup_task

        logger.info("Application startup completed successfully")

        yield

    except Exception as e:
        logger.error(f"Application startup failed: {str(e)}")
        raise

    # Shutdown
    logger.info("Shutting down Speech-to-Speech Voice Assistant API")

    try:
        # Cancel background tasks
        if hasattr(app.state, 'cleanup_task'):
            app.state.cleanup_task.cancel()
            try:
                await app.state.cleanup_task
            except asyncio.CancelledError:
                pass

        # Close database connections
        db_client = await get_database_client()
        await db_client.close()

        logger.info("Application shutdown completed")

    except Exception as e:
        logger.error(f"Error during shutdown: {str(e)}")


# Create FastAPI application
app = FastAPI(
    title="Speech-to-Speech Voice Assistant API",
    description="""
    Constitutional compliance-focused speech-to-speech voice assistant API.

    ## Features
    - **Real-time voice processing** with <800ms latency requirement
    - **Cost optimization** through caching and quality adjustments
    - **Privacy compliance** with 30-day retention and auto-anonymization
    - **Graceful degradation** with fallback mechanisms
    - **Constitutional monitoring** with comprehensive metrics

    ## Constitutional Requirements
    1. **Performance**: All responses must complete within 800ms
    2. **Cost Optimization**: Design decisions factor performance and minimal cost
    3. **Privacy Compliance**: 30-day data retention with anonymization
    4. **Graceful Degradation**: System continues operating during partial failures
    5. **Real-time Performance**: Optimized for account manager workflows
    6. **Modular Architecture**: Clean separation of concerns
    """,
    version="1.0.0",
    contact={
        "name": "Speech-to-Speech API Support",
        "email": "support@speechassistant.example.com"
    },
    license_info={
        "name": "MIT License",
        "url": "https://opensource.org/licenses/MIT"
    },
    lifespan=lifespan
)

# Get application settings
settings = get_settings()


# Middleware configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)

app.add_middleware(
    GZipMiddleware,
    minimum_size=1000  # Only compress responses larger than 1KB
)


@app.middleware("http")
async def constitutional_compliance_middleware(request: Request, call_next):
    """
    Middleware to enforce constitutional compliance requirements.

    Monitors:
    - Request processing time (<800ms requirement)
    - Cost optimization headers
    - Privacy compliance headers
    - Error handling and graceful degradation
    """
    start_time = time.time()

    # Add constitutional compliance headers
    response = await call_next(request)

    # Calculate processing time
    process_time_ms = (time.time() - start_time) * 1000

    # Add compliance headers
    response.headers["X-Processing-Time-Ms"] = str(round(process_time_ms, 2))
    response.headers["X-Constitutional-Compliant"] = str(process_time_ms <= 800.0)
    response.headers["X-Cost-Optimized"] = "true"
    response.headers["X-Privacy-Protected"] = "true"
    response.headers["X-API-Version"] = "1.0.0"

    # Log constitutional violations
    if process_time_ms > 800.0:
        logger.warning(
            f"Constitutional violation: {request.method} {request.url.path} "
            f"took {process_time_ms:.1f}ms (>800ms limit)"
        )

    return response


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    """Log all requests for monitoring and compliance."""
    start_time = time.time()

    # Log request
    logger.info(
        f"Request: {request.method} {request.url.path} "
        f"from {request.client.host if request.client else 'unknown'}"
    )

    try:
        response = await call_next(request)

        # Log response
        process_time_ms = (time.time() - start_time) * 1000
        logger.info(
            f"Response: {response.status_code} for {request.method} {request.url.path} "
            f"in {process_time_ms:.1f}ms"
        )

        return response

    except Exception as e:
        process_time_ms = (time.time() - start_time) * 1000
        logger.error(
            f"Error: {str(e)} for {request.method} {request.url.path} "
            f"after {process_time_ms:.1f}ms"
        )
        raise


# Include routers
app.include_router(conversation_router)
app.include_router(health_router)
app.include_router(metrics_router)
app.include_router(realtime_router)

# Mount static files
static_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "static")
if os.path.exists(static_dir):
    app.mount("/static", StaticFiles(directory=static_dir), name="static")


# Setup error handlers
setup_error_handlers(app)


# Root endpoint
@app.get("/", tags=["root"])
async def root():
    """
    Root endpoint with API information and constitutional compliance status.
    """
    return {
        "message": "Speech-to-Speech Voice Assistant API",
        "version": "1.0.0",
        "status": "operational",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "constitutional_compliance": {
            "latency_requirement": "<800ms response time",
            "cost_optimization": "Active",
            "privacy_protection": "30-day retention with anonymization",
            "graceful_degradation": "Enabled",
            "real_time_performance": "Optimized"
        },
        "endpoints": {
            "health": "/health",
            "metrics": "/metrics",
            "conversation_start": "/conversation/start",
            "voice_query": "/conversation/{session_id}/query",
            "conversation_stream": "/conversation/{session_id}/stream",
            "realtime_conversation": "/realtime/conversation/{session_id}",
            "realtime_stream": "/realtime/conversation/{session_id}/stream",
            "test_client": "/static/realtime_client.html",
            "documentation": "/docs",
            "openapi": "/openapi.json"
        },
        "features": [
            "Real-time voice-to-voice processing via WebSocket",
            "Azure OpenAI Realtime API integration",
            "Bidirectional streaming audio conversation",
            "Semantic knowledge retrieval",
            "Constitutional compliance monitoring",
            "Cost optimization",
            "Privacy-compliant transcript logging",
            "Graceful degradation with fallbacks",
            "Performance metrics and monitoring"
        ]
    }


# Constitutional compliance monitoring endpoint
@app.get("/constitutional-status", tags=["compliance"])
async def constitutional_compliance_status():
    """
    Get current constitutional compliance status.

    Returns real-time compliance metrics for all constitutional requirements.
    """
    try:
        conversation_service = ConversationService()
        system_metrics = await conversation_service.get_system_metrics()

        return {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "overall_compliant": system_metrics["constitutional_compliance"]["latency_requirement_met"],
            "requirements": {
                "latency_800ms": {
                    "requirement": "All responses must complete within 800ms",
                    "status": "compliant" if system_metrics["constitutional_compliance"]["latency_requirement_met"] else "violation",
                    "current_average_ms": system_metrics["average_latency_ms"],
                    "threshold_ms": 800
                },
                "cost_optimization": {
                    "requirement": "Design decisions factor performance and minimal cost",
                    "status": "compliant",
                    "optimizations_active": ["caching", "compression", "quality_adjustment"],
                    "current_cost_usd": system_metrics["total_cost_usd"]
                },
                "privacy_compliance": {
                    "requirement": "30-day data retention with anonymization",
                    "status": "compliant",
                    "retention_policy": "30_days",
                    "anonymization": "automatic"
                },
                "graceful_degradation": {
                    "requirement": "System continues operating during partial failures",
                    "status": "compliant",
                    "fallback_mechanisms": ["cached_responses", "circuit_breakers", "error_recovery"]
                },
                "real_time_performance": {
                    "requirement": "Optimized for account manager workflows",
                    "status": "compliant",
                    "current_sessions": system_metrics["current_sessions"],
                    "system_health": system_metrics["system_health"]
                }
            },
            "monitoring": {
                "metrics_collection": "active",
                "compliance_tracking": "real_time",
                "violation_alerts": "enabled"
            }
        }

    except Exception as e:
        logger.error(f"Failed to get constitutional status: {str(e)}")
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "error": "Failed to retrieve constitutional compliance status",
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        )


# Background tasks
async def periodic_cleanup():
    """Periodic cleanup of expired sessions and transcripts."""
    logger.info("Starting periodic cleanup task")

    while True:
        try:
            # Sleep for 1 hour between cleanup cycles
            await asyncio.sleep(3600)

            logger.info("Running periodic cleanup...")

            # Cleanup expired sessions
            conversation_service = ConversationService()
            cleaned_sessions = await conversation_service.cleanup_expired_sessions()

            # Cleanup expired transcript records
            from ..services.transcript_service import TranscriptService
            transcript_service = TranscriptService()
            cleaned_transcripts = await transcript_service.cleanup_expired_records()

            logger.info(
                f"Cleanup completed: {cleaned_sessions} sessions, "
                f"{cleaned_transcripts} transcript records"
            )

        except asyncio.CancelledError:
            logger.info("Cleanup task cancelled")
            break
        except Exception as e:
            logger.error(f"Error in periodic cleanup: {str(e)}")


# Application entry point
if __name__ == "__main__":
    uvicorn.run(
        "src.api.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        access_log=True,
        log_level="info" if not settings.debug else "debug"
    )