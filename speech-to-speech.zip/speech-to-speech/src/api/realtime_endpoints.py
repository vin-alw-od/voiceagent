"""Real-time WebSocket endpoints for live voice conversation."""
import asyncio
import json
import time
import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional
from uuid import UUID

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, status
from fastapi.websockets import WebSocketState

from ..services.conversation_service import ConversationService
from ..services.realtime_conversation_service import RealtimeConversationService
from ..integrations.azure_realtime_client import get_azure_realtime_client
from ..lib.error_handling import log_constitutional_violation, log_graceful_degradation
from ..lib.config import get_settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/realtime", tags=["realtime"])


class ConnectionManager:
    """Manage WebSocket connections for real-time conversations."""

    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.session_connections: Dict[str, str] = {}  # session_id -> connection_id

    async def connect(self, websocket: WebSocket, connection_id: str, session_id: str):
        """Accept new WebSocket connection."""
        await websocket.accept()
        self.active_connections[connection_id] = websocket
        self.session_connections[session_id] = connection_id
        logger.info(f"WebSocket connected: {connection_id} for session {session_id}")

    def disconnect(self, connection_id: str, session_id: str):
        """Remove WebSocket connection."""
        if connection_id in self.active_connections:
            del self.active_connections[connection_id]
        if session_id in self.session_connections:
            del self.session_connections[session_id]
        logger.info(f"WebSocket disconnected: {connection_id}")

    async def send_message(self, connection_id: str, message: Dict[str, Any]):
        """Send message to specific connection."""
        if connection_id in self.active_connections:
            websocket = self.active_connections[connection_id]
            if websocket.application_state == WebSocketState.CONNECTED:
                await websocket.send_text(json.dumps(message))

    async def send_to_session(self, session_id: str, message: Dict[str, Any]):
        """Send message to session's connection."""
        if session_id in self.session_connections:
            connection_id = self.session_connections[session_id]
            await self.send_message(connection_id, message)


# Global connection manager
connection_manager = ConnectionManager()

# Constitutional compliance settings
settings = get_settings()
CONSTITUTIONAL_LATENCY_MS = 800.0
CONSTITUTIONAL_CONNECTION_TIMEOUT_MS = 5000.0


async def get_realtime_service() -> RealtimeConversationService:
    """Get real-time conversation service instance."""
    from ..services.realtime_conversation_service import get_realtime_conversation_service
    return await get_realtime_conversation_service()


@router.websocket("/conversation/{session_id}")
async def realtime_voice_conversation(
    websocket: WebSocket,
    session_id: str,
    conversation_service: ConversationService = Depends(lambda: ConversationService()),
    realtime_service: RealtimeConversationService = Depends(get_realtime_service)
):
    """
    Real-time bidirectional voice conversation with constitutional compliance.

    Protocol:
    - Client sends: {"type": "audio_chunk", "data": base64_audio, "is_final": false}
    - Client sends: {"type": "audio_end", "is_final": true}
    - Server sends: {"type": "transcription", "text": "...", "is_partial": true}
    - Server sends: {"type": "response", "text": "...", "audio_url": "..."}
    - Server sends: {"type": "metrics", "latency_ms": 250, "compliant": true}
    """
    connection_id = f"conn_{int(time.time() * 1000)}"

    try:
        # Validate session exists
        try:
            session = await conversation_service.get_session(UUID(session_id))
        except Exception as e:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION, reason="Invalid session")
            return

        # Connect WebSocket
        await connection_manager.connect(websocket, connection_id, session_id)

        # Monitor connection setup time for constitutional compliance
        connection_start_time = time.time()

        # Send connection confirmation
        await connection_manager.send_message(connection_id, {
            "type": "connected",
            "session_id": session_id,
            "connection_time_ms": connection_time_ms,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "constitutional_requirements": {
                "latency_target_ms": CONSTITUTIONAL_LATENCY_MS,
                "connection_timeout_ms": CONSTITUTIONAL_CONNECTION_TIMEOUT_MS,
                "real_time_transcription": True,
                "cost_optimization": True,
                "privacy_compliance": True
            },
            "compliance_status": {
                "connection_compliant": connection_time_ms <= CONSTITUTIONAL_CONNECTION_TIMEOUT_MS,
                "ready_for_realtime": True
            }
        })

        # Start real-time conversation processing
        await realtime_service.start_conversation(session_id, connection_id, connection_manager)

        # Calculate final connection setup time
        connection_time_ms = (time.time() - connection_start_time) * 1000

        # Check constitutional compliance for connection setup
        if connection_time_ms > CONSTITUTIONAL_CONNECTION_TIMEOUT_MS:
            log_constitutional_violation(
                violation_type="realtime_connection_setup_latency",
                expected_value=CONSTITUTIONAL_CONNECTION_TIMEOUT_MS,
                actual_value=connection_time_ms,
                context={
                    "session_id": session_id,
                    "connection_id": connection_id,
                    "websocket_path": "/realtime/conversation"
                }
            )

        # Main message handling loop
        while True:
            try:
                # Receive message from client
                data = await websocket.receive_text()
                message = json.loads(data)

                # Process message based on type
                await handle_realtime_message(
                    message, session_id, connection_id, realtime_service, connection_manager
                )

            except WebSocketDisconnect:
                logger.info(f"WebSocket disconnected: {connection_id}")
                break
            except json.JSONDecodeError as e:
                logger.error(f"Invalid JSON from client: {str(e)}")
                await connection_manager.send_message(connection_id, {
                    "type": "error",
                    "error": "Invalid JSON format",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
            except Exception as e:
                logger.error(f"Error in WebSocket loop: {str(e)}")
                await connection_manager.send_message(connection_id, {
                    "type": "error",
                    "error": str(e),
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })

    except Exception as e:
        logger.error(f"WebSocket connection error: {str(e)}")
    finally:
        # Cleanup
        await realtime_service.end_conversation(session_id)
        connection_manager.disconnect(connection_id, session_id)


async def handle_realtime_message(
    message: Dict[str, Any],
    session_id: str,
    connection_id: str,
    realtime_service: RealtimeConversationService,
    connection_manager: ConnectionManager
):
    """Handle different types of real-time messages with constitutional compliance monitoring."""
    message_type = message.get("type")
    timestamp = time.time()
    start_time = timestamp

    try:
        if message_type == "audio_chunk":
            # Process audio chunk
            await realtime_service.process_audio_chunk(
                session_id=session_id,
                audio_data=message.get("data"),
                is_final=message.get("is_final", False),
                chunk_id=message.get("chunk_id"),
                timestamp=timestamp
            )

        elif message_type == "audio_end":
            # End of audio input - finalize processing
            await realtime_service.finalize_audio_input(session_id, timestamp)

        elif message_type == "interrupt":
            # User interrupted - stop current processing
            await realtime_service.handle_interrupt(session_id, timestamp)

        elif message_type == "get_metrics":
            # Send current constitutional compliance metrics
            metrics = await realtime_service.get_realtime_metrics(session_id)
            await connection_manager.send_message(connection_id, {
                "type": "metrics",
                "metrics": metrics,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

        elif message_type == "ping":
            # Heartbeat
            await connection_manager.send_message(connection_id, {
                "type": "pong",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

        else:
            logger.warning(f"Unknown message type: {message_type}")
            await connection_manager.send_message(connection_id, {
                "type": "error",
                "error": f"Unknown message type: {message_type}",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

    except Exception as e:
        logger.error(f"Error handling message type {message_type}: {str(e)}")
        await connection_manager.send_message(connection_id, {
            "type": "error",
            "error": f"Processing error: {str(e)}",
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
    finally:
        # Monitor message processing time for constitutional compliance
        processing_time_ms = (time.time() - start_time) * 1000

        # Log constitutional violations for message processing latency
        if processing_time_ms > CONSTITUTIONAL_LATENCY_MS:
            log_constitutional_violation(
                violation_type="realtime_message_processing_latency",
                expected_value=CONSTITUTIONAL_LATENCY_MS,
                actual_value=processing_time_ms,
                context={
                    "session_id": session_id,
                    "connection_id": connection_id,
                    "message_type": message_type,
                    "websocket_path": "/realtime/conversation"
                }
            )

        # Send compliance metrics to client for audio_chunk messages
        if message_type == "audio_chunk":
            await connection_manager.send_message(connection_id, {
                "type": "compliance_metrics",
                "processing_time_ms": processing_time_ms,
                "constitutional_compliant": processing_time_ms <= CONSTITUTIONAL_LATENCY_MS,
                "message_type": message_type,
                "timestamp": datetime.now(timezone.utc).isoformat()
            })


@router.websocket("/conversation/{session_id}/stream")
async def realtime_session_stream(
    websocket: WebSocket,
    session_id: str
):
    """
    Stream session updates and metrics in real-time.

    Provides continuous updates on:
    - Constitutional compliance status
    - Performance metrics
    - Cost tracking
    - Session events
    """
    connection_id = f"stream_{int(time.time() * 1000)}"

    try:
        await connection_manager.connect(websocket, connection_id, f"{session_id}_stream")

        # Send initial status
        await connection_manager.send_message(connection_id, {
            "type": "stream_connected",
            "session_id": session_id,
            "stream_type": "session_metrics",
            "timestamp": datetime.now(timezone.utc).isoformat()
        })

        # Stream metrics every second
        while True:
            try:
                # Get current session metrics
                conversation_service = ConversationService()
                realtime_service = await get_realtime_service()

                try:
                    session = await conversation_service.get_session(UUID(session_id))
                    analytics = await conversation_service.get_session_analytics(UUID(session_id))

                    # Calculate constitutional compliance status
                    realtime_metrics = await realtime_service.get_realtime_metrics(session_id)
                    is_latency_compliant = session.performance_metrics.average_latency_ms <= CONSTITUTIONAL_LATENCY_MS

                    # Send metrics update with enhanced constitutional compliance
                    await connection_manager.send_message(connection_id, {
                        "type": "session_update",
                        "session_id": session_id,
                        "status": session.status.value,
                        "query_count": session.query_count,
                        "performance_metrics": session.performance_metrics.dict(),
                        "constitutional_compliance": {
                            "latency_compliant": is_latency_compliant,
                            "latency_target_ms": CONSTITUTIONAL_LATENCY_MS,
                            "average_latency_ms": session.performance_metrics.average_latency_ms,
                            "cost_optimized": session.optimization_flags.get("caching_enabled", True),
                            "realtime_performance": realtime_metrics.get("constitutional_compliance", {}),
                            "violations_count": realtime_metrics.get("constitutional_compliance", {}).get("violations_count", 0)
                        },
                        "realtime_metrics": realtime_metrics,
                        "analytics": analytics,
                        "timestamp": datetime.now(timezone.utc).isoformat()
                    })

                    # Log constitutional violations if detected
                    if not is_latency_compliant:
                        log_constitutional_violation(
                            violation_type="session_average_latency",
                            expected_value=CONSTITUTIONAL_LATENCY_MS,
                            actual_value=session.performance_metrics.average_latency_ms,
                            context={
                                "session_id": session_id,
                                "stream_type": "session_metrics",
                                "query_count": session.query_count
                            }
                        )

                except Exception as e:
                    logger.error(f"Error getting session data: {str(e)}")

                # Wait 1 second before next update
                await asyncio.sleep(1.0)

            except WebSocketDisconnect:
                logger.info(f"Metrics stream disconnected: {connection_id}")
                break
            except Exception as e:
                logger.error(f"Error in metrics stream: {str(e)}")
                break

    except Exception as e:
        logger.error(f"Metrics stream connection error: {str(e)}")
    finally:
        connection_manager.disconnect(connection_id, f"{session_id}_stream")


@router.get("/connections")
async def get_active_connections():
    """Get information about active WebSocket connections."""
    return {
        "active_connections": len(connection_manager.active_connections),
        "session_connections": len(connection_manager.session_connections),
        "connections": list(connection_manager.active_connections.keys()),
        "sessions": list(connection_manager.session_connections.keys()),
        "timestamp": datetime.now(timezone.utc).isoformat()
    }


@router.post("/broadcast/{session_id}")
async def broadcast_to_session(session_id: str, message: Dict[str, Any]):
    """Broadcast a message to a specific session's WebSocket connection."""
    try:
        await connection_manager.send_to_session(session_id, {
            "type": "broadcast",
            "message": message,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        return {"status": "sent", "session_id": session_id}
    except Exception as e:
        logger.error(f"Error broadcasting to session {session_id}: {str(e)}")
        return {"status": "error", "error": str(e)}


# Constitutional compliance monitoring for WebSocket connections
@router.middleware("websocket")
async def websocket_constitutional_compliance_middleware(websocket: WebSocket, call_next):
    """Monitor WebSocket connections for constitutional compliance."""
    start_time = time.time()

    try:
        response = await call_next(websocket)
        return response
    except Exception as e:
        connection_time_ms = (time.time() - start_time) * 1000

        # Log if connection setup took too long
        if connection_time_ms > 800.0:
            log_constitutional_violation(
                violation_type="websocket_connection_latency",
                expected_value=800.0,
                actual_value=connection_time_ms,
                context={"websocket_path": str(websocket.url.path)}
            )

        logger.error(f"WebSocket middleware error: {str(e)}")
        raise