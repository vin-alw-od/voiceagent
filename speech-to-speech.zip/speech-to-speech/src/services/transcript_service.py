"""TranscriptService for privacy-compliant conversation logging."""
import asyncio
import hashlib
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, List
from uuid import UUID
import logging

from ..models.transcript_record import TranscriptRecord, RecordType, RetentionCategory, PrivacyLevel, ComplianceStatus
from ..models.conversation_session import ConversationSession
from ..models.voice_query import VoiceQuery
from ..lib.config import get_settings

logger = logging.getLogger(__name__)


class TranscriptServiceError(Exception):
    """Base exception for transcript service errors."""
    pass


class PrivacyViolationError(TranscriptServiceError):
    """Raised when an operation would violate privacy requirements."""
    pass


class TranscriptService:
    """
    Service for managing conversation transcripts with constitutional compliance.

    Responsibilities:
    - Log conversation transcripts with privacy protection
    - Implement 30-day retention policy with automatic expiration
    - Support anonymization for privacy compliance
    - Track access for audit trails
    - Enable compliance holds and selective deletion
    """

    def __init__(self, database_client=None, compliance_client=None):
        """
        Initialize transcript service.

        Args:
            database_client: Database client for transcript storage
            compliance_client: Compliance monitoring client
        """
        self.settings = get_settings()
        self.database = database_client
        self.compliance = compliance_client

        # Constitutional compliance settings
        self.default_retention_days = 30
        self.auto_anonymize_threshold = 0.8  # High sensitivity score
        self.compliance_review_threshold = 0.6

        # Privacy protection settings
        self.privacy_settings = {
            'enable_auto_anonymization': True,
            'enable_sensitivity_scanning': True,
            'require_compliance_review': True,
            'enable_access_logging': True
        }

    async def create_transcript_record(self,
                                     session_id: UUID,
                                     user_id: str,
                                     content: str,
                                     record_type: RecordType,
                                     query_id: Optional[UUID] = None,
                                     context: Optional[Dict[str, Any]] = None) -> TranscriptRecord:
        """
        Create a new transcript record with privacy compliance.

        Args:
            session_id: Session identifier
            user_id: User identifier
            content: Transcript content
            record_type: Type of record
            query_id: Associated query ID if applicable
            context: Additional context

        Returns:
            Created transcript record
        """
        try:
            # Determine retention category based on record type
            retention_category = self._determine_retention_category(record_type)

            # Create transcript record
            record = TranscriptRecord(
                session_id=session_id,
                user_id=user_id,
                content=content,
                record_type=record_type,
                query_id=query_id,
                context_data=context or {},
                retention_metrics={
                    'retention_category': retention_category,
                    'retention_period_days': self.default_retention_days,
                    'created_at': datetime.now(timezone.utc),
                    'expires_at': datetime.now(timezone.utc) + timedelta(days=self.default_retention_days)
                }
            )

            # Analyze sensitivity for compliance
            if self.privacy_settings['enable_sensitivity_scanning']:
                sensitivity_analysis = record.analyze_sensitivity()

                # Auto-anonymize if high sensitivity
                if (self.privacy_settings['enable_auto_anonymization'] and
                    sensitivity_analysis.sensitivity_score >= self.auto_anonymize_threshold):
                    await self._auto_anonymize_record(record)

                # Flag for compliance review if needed
                if sensitivity_analysis.sensitivity_score >= self.compliance_review_threshold:
                    record.compliance_status = ComplianceStatus.FLAGGED

            # Store record
            if self.database:
                await self._persist_transcript_record(record)

            # Log creation for audit
            if self.privacy_settings['enable_access_logging']:
                record.log_access("system", "record_creation")

            logger.info(f"Created transcript record {record.record_id} for session {session_id}")

            return record

        except Exception as e:
            logger.error(f"Failed to create transcript record: {str(e)}")
            raise TranscriptServiceError(f"Record creation failed: {str(e)}")

    async def get_session_transcript(self,
                                   session_id: UUID,
                                   accessor_id: str,
                                   include_sensitive: bool = False) -> List[TranscriptRecord]:
        """
        Get all transcript records for a session.

        Args:
            session_id: Session identifier
            accessor_id: ID of entity accessing records
            include_sensitive: Whether to include sensitive records

        Returns:
            List of transcript records
        """
        try:
            # Retrieve records from database
            records = await self._get_session_records(session_id)

            # Filter based on access permissions
            accessible_records = []
            for record in records:
                # Check expiration
                if record.is_expired():
                    continue

                # Check privacy level access
                if not include_sensitive and record.privacy_level in [
                    PrivacyLevel.CONFIDENTIAL,
                    PrivacyLevel.RESTRICTED
                ]:
                    continue

                # Log access
                if self.privacy_settings['enable_access_logging']:
                    record.log_access(accessor_id, "session_transcript_retrieval")

                accessible_records.append(record)

            # Sort by sequence number
            accessible_records.sort(key=lambda r: r.sequence_number)

            return accessible_records

        except Exception as e:
            logger.error(f"Failed to get session transcript: {str(e)}")
            raise TranscriptServiceError(f"Transcript retrieval failed: {str(e)}")

    async def anonymize_record(self,
                             record_id: UUID,
                             method: str = "redaction",
                             authorized_by: str = "system") -> bool:
        """
        Manually anonymize a transcript record.

        Args:
            record_id: Record identifier
            method: Anonymization method
            authorized_by: Entity authorizing anonymization

        Returns:
            True if successful
        """
        try:
            record = await self._get_record_by_id(record_id)
            if not record:
                raise TranscriptServiceError(f"Record {record_id} not found")

            # Apply anonymization
            success = record.apply_anonymization(method)

            if success:
                # Update record
                record.processing_metadata['manual_anonymization'] = {
                    'authorized_by': authorized_by,
                    'timestamp': datetime.now(timezone.utc).isoformat(),
                    'method': method
                }

                # Persist changes
                if self.database:
                    await self._update_transcript_record(record)

                logger.info(f"Anonymized record {record_id}")

            return success

        except Exception as e:
            logger.error(f"Failed to anonymize record: {str(e)}")
            return False

    async def cleanup_expired_records(self) -> int:
        """
        Clean up expired transcript records according to retention policy.

        Returns:
            Number of records cleaned up
        """
        try:
            # Find expired records that can be deleted
            expired_records = await self._find_expired_deletable_records()

            cleaned_count = 0
            for record in expired_records:
                if record.can_be_deleted():
                    await self._delete_transcript_record(record)
                    cleaned_count += 1

            logger.info(f"Cleaned up {cleaned_count} expired transcript records")
            return cleaned_count

        except Exception as e:
            logger.error(f"Failed to cleanup expired records: {str(e)}")
            return 0

    async def extend_retention(self,
                             record_id: UUID,
                             additional_days: int,
                             reason: str,
                             authorized_by: str) -> bool:
        """
        Extend retention period for a record.

        Args:
            record_id: Record identifier
            additional_days: Days to extend retention
            reason: Reason for extension
            authorized_by: Entity authorizing extension

        Returns:
            True if successful
        """
        try:
            record = await self._get_record_by_id(record_id)
            if not record:
                return False

            # Extend retention
            record.extend_retention(additional_days, reason)

            # Log authorization
            record.processing_metadata['retention_extension_auth'] = {
                'authorized_by': authorized_by,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }

            # Persist changes
            if self.database:
                await self._update_transcript_record(record)

            logger.info(f"Extended retention for record {record_id} by {additional_days} days")
            return True

        except Exception as e:
            logger.error(f"Failed to extend retention: {str(e)}")
            return False

    async def add_compliance_hold(self,
                                record_id: UUID,
                                hold_reason: str,
                                requestor: str) -> bool:
        """
        Add compliance hold to prevent deletion.

        Args:
            record_id: Record identifier
            hold_reason: Reason for hold
            requestor: Entity requesting hold

        Returns:
            True if successful
        """
        try:
            record = await self._get_record_by_id(record_id)
            if not record:
                return False

            # Add compliance hold
            record.add_compliance_hold(hold_reason, requestor)

            # Persist changes
            if self.database:
                await self._update_transcript_record(record)

            logger.info(f"Added compliance hold to record {record_id}")
            return True

        except Exception as e:
            logger.error(f"Failed to add compliance hold: {str(e)}")
            return False

    async def get_compliance_report(self,
                                  session_id: Optional[UUID] = None,
                                  user_id: Optional[str] = None,
                                  start_date: Optional[datetime] = None,
                                  end_date: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Generate compliance report for transcript records.

        Args:
            session_id: Filter by session
            user_id: Filter by user
            start_date: Start date filter
            end_date: End date filter

        Returns:
            Compliance report
        """
        try:
            # Get filtered records
            records = await self._get_filtered_records(session_id, user_id, start_date, end_date)

            # Analyze compliance metrics
            total_records = len(records)
            anonymized_count = sum(1 for r in records if r.anonymization_metrics.anonymization_applied)
            expired_count = sum(1 for r in records if r.is_expired())
            with_holds_count = sum(1 for r in records if r.retention_metrics.compliance_holds)

            # Calculate compliance scores
            privacy_compliance_rate = anonymized_count / max(1, total_records)
            retention_compliance_rate = (total_records - expired_count) / max(1, total_records)

            return {
                'report_generated_at': datetime.now(timezone.utc).isoformat(),
                'filters': {
                    'session_id': str(session_id) if session_id else None,
                    'user_id': user_id,
                    'start_date': start_date.isoformat() if start_date else None,
                    'end_date': end_date.isoformat() if end_date else None
                },
                'summary': {
                    'total_records': total_records,
                    'anonymized_records': anonymized_count,
                    'expired_records': expired_count,
                    'records_with_holds': with_holds_count,
                    'privacy_compliance_rate': privacy_compliance_rate,
                    'retention_compliance_rate': retention_compliance_rate
                },
                'constitutional_compliance': {
                    'retention_policy_met': retention_compliance_rate >= 0.95,
                    'privacy_protection_active': privacy_compliance_rate >= 0.8,
                    'overall_compliant': (retention_compliance_rate >= 0.95 and
                                        privacy_compliance_rate >= 0.8)
                },
                'recommendations': self._generate_compliance_recommendations(
                    privacy_compliance_rate, retention_compliance_rate
                )
            }

        except Exception as e:
            logger.error(f"Failed to generate compliance report: {str(e)}")
            return {'error': str(e)}

    # Private helper methods

    def _determine_retention_category(self, record_type: RecordType) -> RetentionCategory:
        """Determine retention category based on record type."""
        retention_mapping = {
            RecordType.USER_QUERY: RetentionCategory.ESSENTIAL,
            RecordType.SYSTEM_RESPONSE: RetentionCategory.ESSENTIAL,
            RecordType.CONVERSATION_START: RetentionCategory.OPERATIONAL,
            RecordType.CONVERSATION_END: RetentionCategory.OPERATIONAL,
            RecordType.ERROR_EVENT: RetentionCategory.AUDIT,
            RecordType.SYSTEM_EVENT: RetentionCategory.ANALYTICS
        }

        return retention_mapping.get(record_type, RetentionCategory.OPERATIONAL)

    async def _auto_anonymize_record(self, record: TranscriptRecord):
        """Automatically anonymize record based on sensitivity."""
        success = record.apply_anonymization("auto_redaction")

        if success:
            record.processing_metadata['auto_anonymization'] = {
                'trigger': 'high_sensitivity_score',
                'timestamp': datetime.now(timezone.utc).isoformat()
            }

    def _generate_compliance_recommendations(self,
                                           privacy_rate: float,
                                           retention_rate: float) -> List[str]:
        """Generate compliance improvement recommendations."""
        recommendations = []

        if privacy_rate < 0.8:
            recommendations.append("Increase automatic anonymization for sensitive content")

        if retention_rate < 0.95:
            recommendations.append("Improve expired record cleanup processes")

        if privacy_rate >= 0.9 and retention_rate >= 0.95:
            recommendations.append("Compliance standards are being met effectively")

        return recommendations

    # Database interaction methods (placeholders for actual implementation)

    async def _persist_transcript_record(self, record: TranscriptRecord):
        """Persist transcript record to database."""
        if self.database:
            # Actual database persistence would go here
            pass

    async def _get_record_by_id(self, record_id: UUID) -> Optional[TranscriptRecord]:
        """Get record by ID from database."""
        if self.database:
            # Actual database query would go here
            pass
        return None

    async def _get_session_records(self, session_id: UUID) -> List[TranscriptRecord]:
        """Get all records for a session."""
        if self.database:
            # Actual database query would go here
            pass
        return []

    async def _update_transcript_record(self, record: TranscriptRecord):
        """Update transcript record in database."""
        if self.database:
            # Actual database update would go here
            pass

    async def _delete_transcript_record(self, record: TranscriptRecord):
        """Delete transcript record from database."""
        if self.database:
            # Actual database deletion would go here
            pass

    async def _find_expired_deletable_records(self) -> List[TranscriptRecord]:
        """Find expired records that can be deleted."""
        if self.database:
            # Actual database query would go here
            pass
        return []

    async def _get_filtered_records(self,
                                  session_id: Optional[UUID],
                                  user_id: Optional[str],
                                  start_date: Optional[datetime],
                                  end_date: Optional[datetime]) -> List[TranscriptRecord]:
        """Get filtered records for reporting."""
        if self.database:
            # Actual database query with filters would go here
            pass
        return []