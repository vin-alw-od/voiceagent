"""AudioProcessingService for handling audio input/output with constitutional compliance."""
import asyncio
import hashlib
import os
import tempfile
import time
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List, Tuple, BinaryIO
from uuid import UUID
import logging

from ..models.voice_query import VoiceQuery, AudioFormat, AudioMetrics, TranscriptionMetrics
from ..models.audio_response import AudioResponse, AudioQuality, GenerationStatus, TTSProviderMetrics
from ..lib.config import get_settings

logger = logging.getLogger(__name__)


class AudioProcessingError(Exception):
    """Base exception for audio processing errors."""
    pass


class AudioFormatNotSupportedError(AudioProcessingError):
    """Raised when audio format is not supported."""
    pass


class AudioQualityTooLowError(AudioProcessingError):
    """Raised when audio quality is too low for processing."""
    pass


class ConstitutionalLatencyViolationError(AudioProcessingError):
    """Raised when processing would violate 800ms latency requirement."""
    pass


class AudioProcessingService:
    """
    Service for processing audio input and generating audio output with constitutional compliance.

    Responsibilities:
    - Process incoming audio files with quality assessment
    - Generate audio responses with TTS
    - Ensure <800ms latency constitutional requirement
    - Optimize costs through caching and quality adjustments
    - Support graceful degradation for poor quality audio
    - Maintain privacy compliance for audio data
    """

    def __init__(self,
                 azure_client=None,
                 cache_client=None,
                 storage_client=None):
        """
        Initialize audio processing service.

        Args:
            azure_client: Azure OpenAI client for speech processing
            cache_client: Cache client for audio caching
            storage_client: Storage client for audio file persistence
        """
        self.settings = get_settings()
        self.azure_client = azure_client
        self.cache = cache_client
        self.storage = storage_client

        # Constitutional compliance settings
        self.max_processing_time_ms = 800.0
        self.quality_thresholds = {
            'minimum_confidence': 0.3,
            'acceptable_confidence': 0.7,
            'good_confidence': 0.9
        }

        # Cost optimization settings
        self.cost_optimization = {
            'cache_enabled': True,
            'quality_auto_adjust': True,
            'compression_enabled': True,
            'fallback_enabled': True
        }

        # Supported audio formats
        self.supported_formats = {
            AudioFormat.WAV: {'priority': 1, 'cost_multiplier': 1.0},
            AudioFormat.MP3: {'priority': 2, 'cost_multiplier': 0.8},
            AudioFormat.FLAC: {'priority': 3, 'cost_multiplier': 1.2}
        }

    async def process_voice_input(self,
                                audio_data: bytes,
                                audio_format: AudioFormat,
                                query: VoiceQuery) -> VoiceQuery:
        """
        Process voice input audio and extract transcription.

        Args:
            audio_data: Raw audio data
            audio_format: Audio format
            query: Voice query to update with results

        Returns:
            Updated voice query with transcription results

        Raises:
            AudioProcessingError: If processing fails
            ConstitutionalLatencyViolationError: If processing would exceed 800ms
        """
        start_time = time.time()

        try:
            # Start processing stage
            stage = query.start_processing_stage("audio_input_processing")

            # Validate audio format
            if audio_format not in self.supported_formats:
                raise AudioFormatNotSupportedError(f"Format {audio_format} not supported")

            # Analyze audio quality
            audio_metrics = await self._analyze_audio_quality(audio_data, audio_format)
            query.audio_metrics = audio_metrics

            # Check if quality is sufficient for processing
            if audio_metrics.audio_quality_score < 0.1:
                raise AudioQualityTooLowError("Audio quality too low for processing")

            # Check cache first for cost optimization
            cache_key = None
            if self.cost_optimization['cache_enabled']:
                cache_key = self._generate_audio_cache_key(audio_data, audio_format)
                cached_result = await self._get_cached_transcription(cache_key)
                if cached_result:
                    query.set_transcription(
                        cached_result['text'],
                        cached_result['confidence'],
                        cached_result['processing_time_ms'],
                        0.0  # No cost for cached results
                    )
                    stage.complete_stage(True, None, 0.0)
                    return query

            # Adjust processing quality based on audio quality and time constraints
            processing_settings = await self._optimize_processing_settings(
                audio_metrics, start_time
            )

            # Process with Azure OpenAI
            transcription_result = await self._transcribe_audio(
                audio_data, audio_format, processing_settings
            )

            # Update query with results
            query.set_transcription(
                transcription_result['text'],
                transcription_result['confidence'],
                transcription_result['processing_time_ms'],
                transcription_result['cost_usd']
            )

            # Cache result for future use
            if self.cost_optimization['cache_enabled'] and cache_key:
                await self._cache_transcription(cache_key, transcription_result)

            # Complete processing stage
            stage.complete_stage(True, None, transcription_result['cost_usd'])

            # Check constitutional compliance
            elapsed_ms = (time.time() - start_time) * 1000
            if elapsed_ms > self.max_processing_time_ms:
                logger.warning(f"Audio processing exceeded {self.max_processing_time_ms}ms: {elapsed_ms}ms")

            return query

        except Exception as e:
            # Handle graceful degradation
            if isinstance(e, (AudioQualityTooLowError, AudioFormatNotSupportedError)):
                return await self._apply_audio_fallback(query, str(e))

            stage.complete_stage(False, str(e), 0.0)
            raise AudioProcessingError(f"Audio processing failed: {str(e)}")

    async def generate_audio_response(self,
                                    text: str,
                                    query_id: UUID,
                                    knowledge_response_id: UUID,
                                    session_id: UUID,
                                    user_id: str,
                                    quality_preference: AudioQuality = AudioQuality.MEDIUM) -> AudioResponse:
        """
        Generate audio response from text using TTS.

        Args:
            text: Text to convert to speech
            query_id: Associated query ID
            knowledge_response_id: Associated knowledge response ID
            session_id: Session ID
            user_id: User ID
            quality_preference: Desired audio quality

        Returns:
            Audio response with generated audio

        Raises:
            AudioProcessingError: If generation fails
        """
        start_time = time.time()

        try:
            # Create audio response record
            audio_response = AudioResponse(
                query_id=query_id,
                knowledge_response_id=knowledge_response_id,
                session_id=session_id,
                user_id=user_id,
                text_content=text
            )

            # Set optimization settings based on constitutional requirements
            audio_response.optimization_settings.quality_preset = quality_preference
            audio_response.optimization_settings.priority_speed_over_quality = True  # For <800ms requirement

            # Check cache first
            if self.cost_optimization['cache_enabled']:
                cache_key = self._generate_tts_cache_key(text, quality_preference)
                cached_audio = await self._get_cached_audio(cache_key)
                if cached_audio:
                    audio_response.mark_cache_hit(cache_key, cached_audio['retrieval_time_ms'])
                    audio_response.audio_url = cached_audio['audio_url']
                    audio_response.audio_file_path = cached_audio['file_path']
                    return audio_response

            # Start generation
            audio_response.start_generation("azure_openai", "en-US-AriaNeural")

            # Optimize TTS settings for constitutional compliance
            tts_settings = await self._optimize_tts_settings(quality_preference, start_time)

            # Generate audio with Azure OpenAI
            generation_result = await self._generate_tts_audio(text, tts_settings)

            # Store audio file
            audio_file_path = await self._store_audio_file(
                generation_result['audio_data'],
                audio_response.response_id,
                AudioFormat.MP3
            )

            # Generate accessible URL
            audio_url = await self._generate_audio_url(audio_file_path)

            # Complete generation
            audio_response.complete_generation(
                audio_file_path,
                audio_url,
                generation_result['file_size_bytes'],
                generation_result['duration_seconds'],
                generation_result['cost_usd']
            )

            # Update TTS metrics
            audio_response.tts_metrics.processing_latency_ms = generation_result['processing_time_ms']
            audio_response.tts_metrics.naturalness_score = generation_result['naturalness_score']
            audio_response.tts_metrics.api_cost_usd = generation_result['cost_usd']

            # Cache for future use
            if self.cost_optimization['cache_enabled']:
                await self._cache_audio_response(cache_key, audio_response)

            # Check constitutional compliance
            if audio_response.processing_metrics.generation_time_ms > self.max_processing_time_ms:
                logger.warning(f"TTS generation exceeded {self.max_processing_time_ms}ms")

            return audio_response

        except Exception as e:
            # Apply fallback for graceful degradation
            return await self._apply_tts_fallback(audio_response, str(e))

    async def validate_audio_quality(self,
                                   audio_data: bytes,
                                   audio_format: AudioFormat) -> Dict[str, Any]:
        """
        Validate audio quality for processing.

        Args:
            audio_data: Raw audio data
            audio_format: Audio format

        Returns:
            Quality validation results
        """
        try:
            # Analyze audio metrics
            metrics = await self._analyze_audio_quality(audio_data, audio_format)

            # Determine quality assessment
            quality_assessment = {
                'overall_score': metrics.audio_quality_score,
                'is_acceptable': metrics.audio_quality_score >= 0.3,
                'is_good': metrics.audio_quality_score >= 0.7,
                'noise_level': metrics.noise_level,
                'clarity_score': metrics.clarity_score,
                'file_size_bytes': metrics.file_size_bytes,
                'duration_seconds': metrics.duration_seconds,
                'recommendations': []
            }

            # Generate recommendations
            if metrics.audio_quality_score < 0.3:
                quality_assessment['recommendations'].append("Audio quality too low - consider re-recording")
            elif metrics.audio_quality_score < 0.7:
                quality_assessment['recommendations'].append("Audio quality could be improved")

            if metrics.noise_level > 0.7:
                quality_assessment['recommendations'].append("Reduce background noise")

            if metrics.clarity_score < 0.5:
                quality_assessment['recommendations'].append("Improve microphone quality or distance")

            return quality_assessment

        except Exception as e:
            logger.error(f"Audio quality validation failed: {str(e)}")
            return {
                'overall_score': 0.0,
                'is_acceptable': False,
                'is_good': False,
                'error': str(e)
            }

    async def optimize_for_cost(self,
                              processing_params: Dict[str, Any]) -> Dict[str, Any]:
        """
        Optimize processing parameters for cost efficiency.

        Args:
            processing_params: Current processing parameters

        Returns:
            Optimized processing parameters
        """
        optimized = processing_params.copy()

        # Adjust quality for cost optimization
        if self.cost_optimization['quality_auto_adjust']:
            current_quality = optimized.get('quality', AudioQuality.MEDIUM)

            # Lower quality for cost savings while maintaining acceptability
            if current_quality == AudioQuality.PREMIUM:
                optimized['quality'] = AudioQuality.HIGH
            elif current_quality == AudioQuality.HIGH:
                optimized['quality'] = AudioQuality.MEDIUM

        # Enable compression
        if self.cost_optimization['compression_enabled']:
            optimized['compression_enabled'] = True
            optimized['compression_level'] = 'medium'

        # Optimize batch processing if applicable
        optimized['use_batch_processing'] = False  # Disabled for real-time requirement

        return optimized

    # Private helper methods

    async def _analyze_audio_quality(self, audio_data: bytes, audio_format: AudioFormat) -> AudioMetrics:
        """Analyze audio quality metrics."""
        # Simulate audio analysis - in real implementation this would use actual audio processing
        file_size = len(audio_data)

        # Basic quality assessment based on file size and format
        base_quality = 0.5
        if audio_format == AudioFormat.FLAC:
            base_quality = 0.8
        elif audio_format == AudioFormat.WAV:
            base_quality = 0.7
        elif audio_format == AudioFormat.MP3:
            base_quality = 0.6

        # Adjust based on file size (larger generally means better quality)
        size_factor = min(1.0, file_size / (1024 * 100))  # 100KB baseline
        quality_score = min(1.0, base_quality * (0.5 + size_factor * 0.5))

        return AudioMetrics(
            file_size_bytes=file_size,
            duration_seconds=max(1.0, file_size / 16000),  # Estimate duration
            audio_quality_score=quality_score,
            noise_level=0.3,  # Simulated
            clarity_score=quality_score * 0.9
        )

    async def _optimize_processing_settings(self,
                                          audio_metrics: AudioMetrics,
                                          start_time: float) -> Dict[str, Any]:
        """Optimize processing settings based on audio quality and time constraints."""
        elapsed_ms = (time.time() - start_time) * 1000
        remaining_ms = self.max_processing_time_ms - elapsed_ms

        settings = {
            'quality_mode': 'fast' if remaining_ms < 400 else 'balanced',
            'enable_noise_reduction': audio_metrics.noise_level > 0.5,
            'confidence_threshold': 0.3 if audio_metrics.audio_quality_score < 0.5 else 0.7
        }

        return settings

    async def _transcribe_audio(self,
                              audio_data: bytes,
                              audio_format: AudioFormat,
                              settings: Dict[str, Any]) -> Dict[str, Any]:
        """Transcribe audio using Azure OpenAI."""
        start_time = time.time()

        try:
            # Simulate Azure OpenAI transcription
            # In real implementation, this would call Azure OpenAI Whisper API

            # Simulate processing time based on settings
            if settings['quality_mode'] == 'fast':
                processing_time = 0.2  # 200ms
            else:
                processing_time = 0.4  # 400ms

            await asyncio.sleep(processing_time)

            # Simulate transcription result
            text = "This is a simulated transcription result from Azure OpenAI."
            confidence = 0.85 if settings['quality_mode'] == 'balanced' else 0.75

            actual_time_ms = (time.time() - start_time) * 1000
            cost_usd = 0.006 * (len(audio_data) / 1024 / 1024)  # $0.006 per MB

            return {
                'text': text,
                'confidence': confidence,
                'processing_time_ms': actual_time_ms,
                'cost_usd': cost_usd,
                'language': 'en',
                'alternatives': []
            }

        except Exception as e:
            raise AudioProcessingError(f"Transcription failed: {str(e)}")

    async def _optimize_tts_settings(self,
                                   quality_preference: AudioQuality,
                                   start_time: float) -> Dict[str, Any]:
        """Optimize TTS settings for constitutional compliance."""
        elapsed_ms = (time.time() - start_time) * 1000
        remaining_ms = self.max_processing_time_ms - elapsed_ms

        # Adjust quality based on time constraints
        if remaining_ms < 300:  # Less than 300ms remaining
            effective_quality = AudioQuality.LOW
        elif remaining_ms < 500:  # Less than 500ms remaining
            effective_quality = AudioQuality.MEDIUM
        else:
            effective_quality = quality_preference

        settings = {
            'quality': effective_quality,
            'voice_speed': 1.1 if remaining_ms < 400 else 1.0,
            'streaming': True if remaining_ms < 300 else False,
            'format': AudioFormat.MP3  # Good balance of quality and size
        }

        return settings

    async def _generate_tts_audio(self, text: str, settings: Dict[str, Any]) -> Dict[str, Any]:
        """Generate TTS audio using Azure OpenAI."""
        start_time = time.time()

        try:
            # Simulate Azure OpenAI TTS generation
            # In real implementation, this would call Azure OpenAI TTS API

            # Simulate processing time based on settings
            base_time = len(text) * 0.02  # 20ms per character
            if settings['quality'] == AudioQuality.LOW:
                processing_time = base_time * 0.5
            elif settings['quality'] == AudioQuality.MEDIUM:
                processing_time = base_time * 0.8
            else:
                processing_time = base_time

            await asyncio.sleep(min(processing_time, 0.5))  # Cap at 500ms

            # Simulate generated audio data
            estimated_audio_size = len(text) * 1000  # ~1KB per character
            audio_data = b'simulated_audio_data' * (estimated_audio_size // 20)

            actual_time_ms = (time.time() - start_time) * 1000
            duration_seconds = len(text) * 0.06  # ~60ms per character for speech

            # Calculate cost based on character count
            cost_usd = len(text) * 0.000015  # $0.015 per 1K characters

            return {
                'audio_data': audio_data,
                'file_size_bytes': len(audio_data),
                'duration_seconds': duration_seconds,
                'processing_time_ms': actual_time_ms,
                'cost_usd': cost_usd,
                'naturalness_score': 0.8 if settings['quality'] != AudioQuality.LOW else 0.6
            }

        except Exception as e:
            raise AudioProcessingError(f"TTS generation failed: {str(e)}")

    async def _store_audio_file(self,
                              audio_data: bytes,
                              response_id: UUID,
                              audio_format: AudioFormat) -> str:
        """Store audio file and return file path."""
        # Create temporary file
        temp_dir = tempfile.gettempdir()
        file_name = f"audio_response_{response_id}.{audio_format.value}"
        file_path = os.path.join(temp_dir, file_name)

        try:
            with open(file_path, 'wb') as f:
                f.write(audio_data)

            return file_path

        except Exception as e:
            raise AudioProcessingError(f"Failed to store audio file: {str(e)}")

    async def _generate_audio_url(self, file_path: str) -> str:
        """Generate URL for accessing audio file."""
        # In real implementation, this would upload to CDN/storage and return public URL
        file_name = os.path.basename(file_path)
        return f"https://api.example.com/audio/{file_name}"

    async def _apply_audio_fallback(self, query: VoiceQuery, reason: str) -> VoiceQuery:
        """Apply fallback for audio processing failures."""
        query.use_fallback(reason, "Unable to process audio - please try again")
        query.set_transcription(
            "Audio processing failed - fallback response",
            0.0,  # No confidence in fallback
            50.0,  # Fast fallback processing
            0.0   # No cost
        )
        return query

    async def _apply_tts_fallback(self, audio_response: AudioResponse, reason: str) -> AudioResponse:
        """Apply fallback for TTS generation failures."""
        # Use pre-recorded fallback audio
        fallback_url = "https://api.example.com/audio/fallback_response.mp3"
        audio_response.set_fallback_audio(reason, fallback_url)
        return audio_response

    def _generate_audio_cache_key(self, audio_data: bytes, audio_format: AudioFormat) -> str:
        """Generate cache key for audio data."""
        audio_hash = hashlib.md5(audio_data).hexdigest()
        return f"audio_transcription:{audio_format.value}:{audio_hash}"

    def _generate_tts_cache_key(self, text: str, quality: AudioQuality) -> str:
        """Generate cache key for TTS."""
        text_hash = hashlib.md5(text.encode('utf-8')).hexdigest()
        return f"tts_audio:{quality.value}:{text_hash}"

    async def _get_cached_transcription(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Get cached transcription result."""
        if self.cache:
            return await self.cache.get(cache_key)
        return None

    async def _cache_transcription(self, cache_key: str, result: Dict[str, Any]):
        """Cache transcription result."""
        if self.cache:
            await self.cache.set(cache_key, result, expire=3600)  # 1 hour

    async def _get_cached_audio(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Get cached audio response."""
        if self.cache:
            return await self.cache.get(cache_key)
        return None

    async def _cache_audio_response(self, cache_key: str, audio_response: AudioResponse):
        """Cache audio response."""
        if self.cache:
            cache_data = {
                'audio_url': audio_response.audio_url,
                'file_path': audio_response.audio_file_path,
                'retrieval_time_ms': 10.0  # Fast cache retrieval
            }
            await self.cache.set(cache_key, cache_data, expire=1800)  # 30 minutes