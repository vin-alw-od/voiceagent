"""ConversationService for managing conversation sessions with constitutional compliance."""
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, List
from uuid import UUID, uuid4
import logging

from ..models.conversation_session import ConversationSession, SessionStatus, PerformanceMetrics
from ..models.voice_query import VoiceQuery
from ..lib.config import get_settings

logger = logging.getLogger(__name__)


class ConversationServiceError(Exception):
    """Base exception for conversation service errors."""
    pass


class SessionNotFoundError(ConversationServiceError):
    """Raised when a conversation session is not found."""
    pass


class SessionExpiredError(ConversationServiceError):
    """Raised when trying to use an expired session."""
    pass


class ConstitutionalViolationError(ConversationServiceError):
    """Raised when an operation would violate constitutional requirements."""
    pass


class ConversationService:
    """
    Service for managing conversation sessions with constitutional compliance.

    Responsibilities:
    - Create and manage conversation sessions
    - Track performance metrics for <800ms latency requirement
    - Implement cost optimization strategies
    - Ensure privacy compliance with data retention
    - Support graceful degradation
    """

    def __init__(self, database_client=None, cache_client=None):
        """
        Initialize conversation service.

        Args:
            database_client: Database client for persistence
            cache_client: Cache client for performance optimization
        """
        self.settings = get_settings()
        self.database = database_client
        self.cache = cache_client
        self._active_sessions: Dict[str, ConversationSession] = {}
        self._session_limits = {
            'max_concurrent_sessions': 100,
            'max_session_duration_hours': 24,
            'max_queries_per_session': 1000
        }

    async def create_session(self,
                           user_id: str,
                           context: Optional[Dict[str, Any]] = None,
                           session_config: Optional[Dict[str, Any]] = None) -> ConversationSession:
        """
        Create a new conversation session.

        Args:
            user_id: User identifier
            context: Initial conversation context
            session_config: Session-specific configuration

        Returns:
            Created conversation session

        Raises:
            ConversationServiceError: If session creation fails
        """
        try:
            # Check concurrent session limits
            await self._enforce_session_limits(user_id)

            # Create session with constitutional compliance settings
            session = ConversationSession(
                user_id=user_id,
                context_data=context or {},
                session_config=session_config or {},
                expires_at=datetime.now(timezone.utc) + timedelta(
                    hours=self._session_limits['max_session_duration_hours']
                )
            )

            # Set constitutional compliance defaults
            session.compliance_flags.update({
                'latency_requirement': True,
                'cost_optimization': True,
                'privacy_compliant': True,
                'graceful_degradation': True
            })

            # Set cost optimization defaults
            session.optimization_flags.update({
                'caching_enabled': True,
                'compression_enabled': True,
                'quality_auto_adjust': True,
                'batch_processing': False  # Real-time requirement
            })

            # Store in cache for fast access
            if self.cache:
                await self._cache_session(session)

            # Persist to database
            if self.database:
                await self._persist_session(session)

            # Track in memory for active session management
            self._active_sessions[str(session.session_id)] = session

            logger.info(f"Created conversation session {session.session_id} for user {user_id}")

            return session

        except Exception as e:
            logger.error(f"Failed to create session for user {user_id}: {str(e)}")
            raise ConversationServiceError(f"Session creation failed: {str(e)}")

    async def get_session(self, session_id: UUID) -> ConversationSession:
        """
        Retrieve a conversation session.

        Args:
            session_id: Session identifier

        Returns:
            Conversation session

        Raises:
            SessionNotFoundError: If session doesn't exist
            SessionExpiredError: If session has expired
        """
        session_str = str(session_id)

        # Check active sessions first
        if session_str in self._active_sessions:
            session = self._active_sessions[session_str]

            # Check expiration
            if session.is_expired():
                await self._expire_session(session)
                raise SessionExpiredError(f"Session {session_id} has expired")

            return session

        # Try cache
        if self.cache:
            session = await self._get_cached_session(session_id)
            if session:
                # Check expiration
                if session.is_expired():
                    await self._expire_session(session)
                    raise SessionExpiredError(f"Session {session_id} has expired")

                # Restore to active sessions
                self._active_sessions[session_str] = session
                return session

        # Try database
        if self.database:
            session = await self._get_persisted_session(session_id)
            if session:
                # Check expiration
                if session.is_expired():
                    await self._expire_session(session)
                    raise SessionExpiredError(f"Session {session_id} has expired")

                # Restore to active sessions and cache
                self._active_sessions[session_str] = session
                if self.cache:
                    await self._cache_session(session)
                return session

        raise SessionNotFoundError(f"Session {session_id} not found")

    async def update_session(self,
                           session_id: UUID,
                           updates: Dict[str, Any]) -> ConversationSession:
        """
        Update a conversation session.

        Args:
            session_id: Session identifier
            updates: Updates to apply

        Returns:
            Updated conversation session
        """
        session = await self.get_session(session_id)

        # Apply updates while maintaining constitutional compliance
        for key, value in updates.items():
            if key == 'status':
                session.status = SessionStatus(value)
                if value == SessionStatus.COMPLETED:
                    session.complete_session(updates.get('completion_reason', 'user_ended'))
            elif key == 'context_data':
                session.context_data.update(value)
            elif key == 'session_config':
                session.session_config.update(value)
            elif hasattr(session, key):
                setattr(session, key, value)

        # Update timestamps
        session.updated_at = datetime.now(timezone.utc)

        # Persist changes
        await self._update_session_storage(session)

        logger.info(f"Updated session {session_id}")
        return session

    async def record_query_metrics(self,
                                 session_id: UUID,
                                 query: VoiceQuery) -> ConversationSession:
        """
        Record query metrics for constitutional compliance tracking.

        Args:
            session_id: Session identifier
            query: Voice query to record metrics for

        Returns:
            Updated conversation session
        """
        session = await self.get_session(session_id)

        # Update performance metrics
        latency_ms = query.total_processing_time_ms
        success = query.status.value in ['completed', 'fallback']
        cost = query.total_cost_usd

        session.update_performance_metrics(latency_ms, success, cost)

        # Update quality metrics
        if query.transcription_metrics and query.audio_metrics:
            confidence = query.transcription_metrics.confidence_score
            audio_quality = query.audio_metrics.audio_quality_score
            had_error = query.status.value == 'failed'

            session.update_quality_metrics(confidence, audio_quality, had_error)

        # Check constitutional violations
        await self._check_constitutional_compliance(session, query)

        # Update cost tracking
        await self._update_cost_tracking(session, query)

        # Persist changes
        await self._update_session_storage(session)

        return session

    async def list_active_sessions(self,
                                 user_id: Optional[str] = None,
                                 limit: int = 100) -> List[ConversationSession]:
        """
        List active conversation sessions.

        Args:
            user_id: Filter by user ID (optional)
            limit: Maximum number of sessions to return

        Returns:
            List of active conversation sessions
        """
        sessions = []

        for session in self._active_sessions.values():
            if user_id and session.user_id != user_id:
                continue

            if not session.is_expired():
                sessions.append(session)
            else:
                # Clean up expired session
                await self._expire_session(session)

        # Sort by most recent first
        sessions.sort(key=lambda s: s.updated_at, reverse=True)

        return sessions[:limit]

    async def get_session_analytics(self,
                                  session_id: UUID) -> Dict[str, Any]:
        """
        Get analytics for a conversation session.

        Args:
            session_id: Session identifier

        Returns:
            Analytics data
        """
        session = await self.get_session(session_id)

        return {
            'session_summary': {
                'session_id': str(session.session_id),
                'user_id': session.user_id,
                'status': session.status.value,
                'duration_minutes': (session.updated_at - session.created_at).total_seconds() / 60,
                'query_count': session.query_count
            },
            'performance_metrics': session.performance_metrics.dict(),
            'quality_metrics': session.quality_metrics.dict(),
            'constitutional_compliance': {
                'latency_compliant': session.compliance_flags.get('latency_requirement', False),
                'cost_optimized': session.compliance_flags.get('cost_optimization', False),
                'average_latency_ms': session.performance_metrics.average_latency_ms,
                'success_rate': (session.performance_metrics.successful_queries /
                               max(1, session.performance_metrics.total_queries))
            },
            'cost_analysis': session.get_cost_summary(),
            'recommendations': await self._get_session_recommendations(session)
        }

    async def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired sessions.

        Returns:
            Number of sessions cleaned up
        """
        cleaned_count = 0
        expired_session_ids = []

        # Find expired sessions
        for session_id, session in self._active_sessions.items():
            if session.is_expired():
                expired_session_ids.append(session_id)

        # Clean up expired sessions
        for session_id in expired_session_ids:
            session = self._active_sessions[session_id]
            await self._expire_session(session)
            cleaned_count += 1

        logger.info(f"Cleaned up {cleaned_count} expired sessions")
        return cleaned_count

    async def get_system_metrics(self) -> Dict[str, Any]:
        """
        Get system-level conversation metrics.

        Returns:
            System metrics
        """
        active_sessions = len(self._active_sessions)

        # Calculate aggregate metrics
        total_queries = sum(s.query_count for s in self._active_sessions.values())

        if self._active_sessions:
            avg_latency = sum(s.performance_metrics.average_latency_ms
                            for s in self._active_sessions.values()) / len(self._active_sessions)

            total_cost = sum(s.performance_metrics.cost_estimate_usd
                           for s in self._active_sessions.values())
        else:
            avg_latency = 0.0
            total_cost = 0.0

        return {
            'current_sessions': active_sessions,
            'total_queries_today': total_queries,
            'average_latency_ms': avg_latency,
            'total_cost_usd': total_cost,
            'constitutional_compliance': {
                'latency_requirement_met': avg_latency <= 800.0,
                'session_limit_respected': active_sessions <= self._session_limits['max_concurrent_sessions']
            },
            'system_health': 'healthy' if avg_latency <= 800.0 and active_sessions <= 50 else 'degraded'
        }

    # Private helper methods

    async def _enforce_session_limits(self, user_id: str):
        """Enforce session limits per user and system-wide."""
        # Count user's active sessions
        user_sessions = [s for s in self._active_sessions.values() if s.user_id == user_id]
        if len(user_sessions) >= 5:  # Max 5 sessions per user
            raise ConversationServiceError("Maximum concurrent sessions per user exceeded")

        # Check system-wide limit
        if len(self._active_sessions) >= self._session_limits['max_concurrent_sessions']:
            # Clean up expired sessions first
            await self.cleanup_expired_sessions()

            if len(self._active_sessions) >= self._session_limits['max_concurrent_sessions']:
                raise ConversationServiceError("System at maximum capacity")

    async def _check_constitutional_compliance(self, session: ConversationSession, query: VoiceQuery):
        """Check and enforce constitutional compliance."""
        # Check latency requirement
        if query.total_processing_time_ms > 800.0:
            session.compliance_flags['latency_requirement'] = False
            logger.warning(f"Constitutional violation: Query {query.query_id} exceeded 800ms latency")

            # Trigger degradation if needed
            if session.performance_metrics.average_latency_ms > 800.0:
                session.degradation_level = "moderate"

    async def _update_cost_tracking(self, session: ConversationSession, query: VoiceQuery):
        """Update cost tracking for optimization."""
        # Track costs by service
        for service, cost in query.cost_breakdown.items():
            if service in session.cost_tracking:
                session.cost_tracking[service] += cost
            else:
                session.cost_tracking[service] = cost

    async def _get_session_recommendations(self, session: ConversationSession) -> List[str]:
        """Generate recommendations for session optimization."""
        recommendations = []

        # Performance recommendations
        if session.performance_metrics.average_latency_ms > 800.0:
            recommendations.append("Optimize processing pipeline to meet <800ms latency requirement")

        # Cost recommendations
        cost_per_query = (session.performance_metrics.cost_estimate_usd /
                         max(1, session.performance_metrics.total_queries))
        if cost_per_query > 0.25:
            recommendations.append("Consider cost optimization strategies")

        # Quality recommendations
        if session.quality_metrics.average_confidence < 0.7:
            recommendations.append("Improve audio quality or processing settings")

        return recommendations

    async def _expire_session(self, session: ConversationSession):
        """Expire a session and clean up resources."""
        session.status = SessionStatus.EXPIRED
        session_id_str = str(session.session_id)

        # Remove from active sessions
        if session_id_str in self._active_sessions:
            del self._active_sessions[session_id_str]

        # Update in persistent storage
        if self.database:
            await self._persist_session(session)

        # Remove from cache
        if self.cache:
            await self._remove_from_cache(session.session_id)

    async def _cache_session(self, session: ConversationSession):
        """Cache session for fast retrieval."""
        if self.cache:
            cache_key = f"session:{session.session_id}"
            await self.cache.set(cache_key, session.json(), expire=3600)  # 1 hour cache

    async def _get_cached_session(self, session_id: UUID) -> Optional[ConversationSession]:
        """Get session from cache."""
        if self.cache:
            cache_key = f"session:{session_id}"
            cached_data = await self.cache.get(cache_key)
            if cached_data:
                return ConversationSession.parse_raw(cached_data)
        return None

    async def _remove_from_cache(self, session_id: UUID):
        """Remove session from cache."""
        if self.cache:
            cache_key = f"session:{session_id}"
            await self.cache.delete(cache_key)

    async def _persist_session(self, session: ConversationSession):
        """Persist session to database."""
        if self.database:
            # This would interact with actual database
            # For now, this is a placeholder
            pass

    async def _get_persisted_session(self, session_id: UUID) -> Optional[ConversationSession]:
        """Get session from database."""
        if self.database:
            # This would query actual database
            # For now, this is a placeholder
            pass
        return None

    async def _update_session_storage(self, session: ConversationSession):
        """Update session in both cache and database."""
        if self.cache:
            await self._cache_session(session)

        if self.database:
            await self._persist_session(session)