"""Real-time conversation service for WebSocket-based voice processing."""
import asyncio
import base64
import json
import time
import logging
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from uuid import UUID, uuid4

from ..models.conversation_session import ConversationSession
from ..models.voice_query import VoiceQuery, AudioFormat
from ..integrations.azure_realtime_client import get_azure_realtime_client
from ..services.conversation_service import ConversationService
from ..services.vector_search_service import VectorSearchService
from ..services.transcript_service import TranscriptService
from ..lib.error_handling import log_constitutional_violation, log_graceful_degradation

logger = logging.getLogger(__name__)


class RealtimeConversationService:
    """
    Service for managing real-time voice conversations with constitutional compliance.

    Features:
    - Streaming audio processing with Azure Realtime API
    - Real-time transcription and response generation
    - Constitutional compliance monitoring (<800ms latency)
    - Cost optimization through intelligent buffering
    - Graceful degradation with fallback mechanisms
    """

    def __init__(self):
        self.conversation_service = ConversationService()
        self.vector_service = VectorSearchService()
        self.transcript_service = TranscriptService()

        # Active conversation tracking
        self.active_conversations: Dict[str, Dict[str, Any]] = {}

        # Constitutional compliance settings
        self.max_response_latency_ms = 800.0
        self.max_transcription_latency_ms = 300.0
        self.audio_buffer_size_ms = 100.0  # 100ms chunks

        # Real-time optimization settings
        self.optimization = {
            "enable_partial_transcription": True,
            "enable_interrupt_handling": True,
            "enable_adaptive_quality": True,
            "enable_predictive_responses": True
        }

    async def start_conversation(
        self,
        session_id: str,
        connection_id: str,
        connection_manager
    ):
        """Start a real-time conversation session."""
        try:
            # Initialize conversation state
            conversation_state = {
                "session_id": session_id,
                "connection_id": connection_id,
                "connection_manager": connection_manager,
                "azure_client": await get_azure_realtime_client(),
                "current_query": None,
                "audio_buffer": [],
                "transcription_buffer": "",
                "is_processing": False,
                "last_activity": time.time(),
                "metrics": {
                    "total_audio_chunks": 0,
                    "total_transcriptions": 0,
                    "total_responses": 0,
                    "average_latency_ms": 0.0,
                    "constitutional_violations": 0
                },
                "context": await self._load_session_context(session_id)
            }

            self.active_conversations[session_id] = conversation_state

            # Start Azure Realtime connection
            await self._initialize_azure_realtime_connection(conversation_state)

            logger.info(f"Started real-time conversation for session {session_id}")

        except Exception as e:
            logger.error(f"Failed to start real-time conversation: {str(e)}")
            await connection_manager.send_message(connection_id, {
                "type": "error",
                "error": f"Failed to start conversation: {str(e)}",
                "timestamp": datetime.now(timezone.utc).isoformat()
            })

    async def process_audio_chunk(
        self,
        session_id: str,
        audio_data: str,
        is_final: bool = False,
        chunk_id: Optional[str] = None,
        timestamp: float = None
    ):
        """Process incoming audio chunk in real-time."""
        if session_id not in self.active_conversations:
            logger.error(f"No active conversation for session {session_id}")
            return

        conversation = self.active_conversations[session_id]
        start_time = time.time()

        try:
            # Decode audio data
            audio_bytes = base64.b64decode(audio_data)

            # Add to buffer
            conversation["audio_buffer"].append({
                "data": audio_bytes,
                "timestamp": timestamp or time.time(),
                "chunk_id": chunk_id,
                "is_final": is_final
            })

            # Update metrics
            conversation["metrics"]["total_audio_chunks"] += 1
            conversation["last_activity"] = time.time()

            # Process with Azure Realtime API
            if len(audio_bytes) > 0:
                transcription_result = await self._process_audio_with_azure(
                    conversation, audio_bytes, is_final
                )

                if transcription_result:
                    # Send partial transcription
                    await self._send_transcription_update(
                        conversation, transcription_result, is_final
                    )

                    # If final, generate response
                    if is_final and transcription_result.get("text"):
                        await self._generate_realtime_response(
                            conversation, transcription_result["text"]
                        )

            # Check constitutional compliance
            processing_time_ms = (time.time() - start_time) * 1000
            if processing_time_ms > self.max_transcription_latency_ms:
                log_constitutional_violation(
                    violation_type="realtime_transcription_latency",
                    expected_value=self.max_transcription_latency_ms,
                    actual_value=processing_time_ms,
                    context={"session_id": session_id, "chunk_size": len(audio_bytes)}
                )
                conversation["metrics"]["constitutional_violations"] += 1

        except Exception as e:
            logger.error(f"Error processing audio chunk: {str(e)}")
            await self._send_error_message(conversation, f"Audio processing error: {str(e)}")

    async def finalize_audio_input(self, session_id: str, timestamp: float):
        """Finalize audio input and ensure complete processing."""
        if session_id not in self.active_conversations:
            return

        conversation = self.active_conversations[session_id]

        try:
            # Finalize any remaining audio processing
            await self._finalize_azure_processing(conversation)

            # Generate final response if not already done
            if conversation["transcription_buffer"] and not conversation["is_processing"]:
                await self._generate_realtime_response(
                    conversation, conversation["transcription_buffer"]
                )

        except Exception as e:
            logger.error(f"Error finalizing audio input: {str(e)}")
            await self._send_error_message(conversation, f"Finalization error: {str(e)}")

    async def handle_interrupt(self, session_id: str, timestamp: float):
        """Handle user interruption during processing."""
        if session_id not in self.active_conversations:
            return

        conversation = self.active_conversations[session_id]

        try:
            # Stop current processing
            conversation["is_processing"] = False

            # Clear buffers
            conversation["audio_buffer"] = []
            conversation["transcription_buffer"] = ""

            # Interrupt Azure processing
            await self._interrupt_azure_processing(conversation)

            # Send interrupt confirmation
            await conversation["connection_manager"].send_message(
                conversation["connection_id"],
                {
                    "type": "interrupted",
                    "message": "Processing interrupted, ready for new input",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
            )

            logger.info(f"Handled interrupt for session {session_id}")

        except Exception as e:
            logger.error(f"Error handling interrupt: {str(e)}")

    async def get_realtime_metrics(self, session_id: str) -> Dict[str, Any]:
        """Get real-time constitutional compliance metrics."""
        if session_id not in self.active_conversations:
            return {"error": "No active conversation"}

        conversation = self.active_conversations[session_id]
        current_time = time.time()

        metrics = conversation["metrics"].copy()
        metrics.update({
            "session_duration_seconds": current_time - conversation.get("start_time", current_time),
            "last_activity_seconds_ago": current_time - conversation["last_activity"],
            "constitutional_compliance": {
                "latency_compliant": metrics["average_latency_ms"] <= self.max_response_latency_ms,
                "violations_count": metrics["constitutional_violations"],
                "compliance_rate": 1.0 - (metrics["constitutional_violations"] / max(1, metrics["total_responses"]))
            },
            "real_time_performance": {
                "audio_chunks_processed": metrics["total_audio_chunks"],
                "transcriptions_generated": metrics["total_transcriptions"],
                "responses_generated": metrics["total_responses"],
                "is_processing": conversation["is_processing"]
            }
        })

        return metrics

    async def end_conversation(self, session_id: str):
        """End real-time conversation and cleanup resources."""
        if session_id not in self.active_conversations:
            return

        conversation = self.active_conversations[session_id]

        try:
            # Close Azure connection
            if "azure_client" in conversation:
                await conversation["azure_client"].close_realtime_connection()

            # Log final metrics
            final_metrics = await self.get_realtime_metrics(session_id)
            logger.info(f"Ended real-time conversation {session_id}: {final_metrics}")

            # Clean up
            del self.active_conversations[session_id]

        except Exception as e:
            logger.error(f"Error ending conversation: {str(e)}")

    # Private helper methods

    async def _load_session_context(self, session_id: str) -> Dict[str, Any]:
        """Load session context for conversation."""
        try:
            session = await self.conversation_service.get_session(UUID(session_id))
            return session.context_data
        except Exception as e:
            logger.error(f"Failed to load session context: {str(e)}")
            return {}

    async def _initialize_azure_realtime_connection(self, conversation: Dict[str, Any]):
        """Initialize Azure Realtime API connection."""
        try:
            azure_client = conversation["azure_client"]
            await azure_client.start_realtime_session()

            # Configure real-time settings
            await azure_client.configure_realtime_session({
                "input_audio_format": "pcm16",
                "output_audio_format": "pcm16",
                "input_audio_transcription": {"model": "whisper-1"},
                "turn_detection": {"type": "server_vad"},
                "tools": [],
                "temperature": 0.7,
                "max_response_output_tokens": 4096
            })

        except Exception as e:
            logger.error(f"Failed to initialize Azure realtime connection: {str(e)}")
            raise

    async def _process_audio_with_azure(
        self,
        conversation: Dict[str, Any],
        audio_bytes: bytes,
        is_final: bool
    ) -> Optional[Dict[str, Any]]:
        """Process audio with Azure Realtime API."""
        try:
            azure_client = conversation["azure_client"]

            # Send audio to Azure
            result = await azure_client.send_audio_chunk(audio_bytes, is_final)

            if result and "transcription" in result:
                # Update transcription buffer
                if is_final:
                    conversation["transcription_buffer"] = result["transcription"]["text"]
                else:
                    conversation["transcription_buffer"] += result["transcription"]["text"]

                conversation["metrics"]["total_transcriptions"] += 1

                return {
                    "text": result["transcription"]["text"],
                    "confidence": result["transcription"].get("confidence", 0.8),
                    "is_partial": not is_final
                }

        except Exception as e:
            logger.error(f"Azure audio processing error: {str(e)}")
            return None

    async def _send_transcription_update(
        self,
        conversation: Dict[str, Any],
        transcription_result: Dict[str, Any],
        is_final: bool
    ):
        """Send transcription update to client."""
        try:
            await conversation["connection_manager"].send_message(
                conversation["connection_id"],
                {
                    "type": "transcription",
                    "text": transcription_result["text"],
                    "confidence": transcription_result["confidence"],
                    "is_partial": not is_final,
                    "is_final": is_final,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
            )

        except Exception as e:
            logger.error(f"Error sending transcription update: {str(e)}")

    async def _generate_realtime_response(
        self,
        conversation: Dict[str, Any],
        transcription_text: str
    ):
        """Generate real-time response using knowledge base and Azure TTS."""
        if conversation["is_processing"]:
            return  # Already processing

        conversation["is_processing"] = True
        start_time = time.time()

        try:
            # Search knowledge base
            knowledge_response = await self.vector_service.search_knowledge(
                query_text=transcription_text,
                user_context=conversation["context"],
                session_id=UUID(conversation["session_id"]),
                user_id="realtime_user"  # Would be extracted from session
            )

            # Generate audio response with Azure
            azure_client = conversation["azure_client"]
            audio_response = await azure_client.generate_speech_realtime(
                knowledge_response.response_text
            )

            # Calculate total response time
            response_time_ms = (time.time() - start_time) * 1000

            # Send response to client
            await conversation["connection_manager"].send_message(
                conversation["connection_id"],
                {
                    "type": "response",
                    "transcription": transcription_text,
                    "response_text": knowledge_response.response_text,
                    "audio_url": audio_response.get("audio_url"),
                    "audio_data": audio_response.get("audio_data_base64"),
                    "processing_time_ms": response_time_ms,
                    "constitutional_compliant": response_time_ms <= self.max_response_latency_ms,
                    "sources_used": len(knowledge_response.knowledge_sources),
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
            )

            # Update metrics
            conversation["metrics"]["total_responses"] += 1
            conversation["metrics"]["average_latency_ms"] = (
                (conversation["metrics"]["average_latency_ms"] * (conversation["metrics"]["total_responses"] - 1) + response_time_ms) /
                conversation["metrics"]["total_responses"]
            )

            # Check constitutional compliance
            if response_time_ms > self.max_response_latency_ms:
                log_constitutional_violation(
                    violation_type="realtime_response_latency",
                    expected_value=self.max_response_latency_ms,
                    actual_value=response_time_ms,
                    context={"session_id": conversation["session_id"]}
                )
                conversation["metrics"]["constitutional_violations"] += 1

            logger.info(f"Generated real-time response in {response_time_ms:.1f}ms")

        except Exception as e:
            logger.error(f"Error generating real-time response: {str(e)}")
            await self._send_error_message(conversation, f"Response generation error: {str(e)}")

        finally:
            conversation["is_processing"] = False

    async def _finalize_azure_processing(self, conversation: Dict[str, Any]):
        """Finalize any pending Azure processing."""
        try:
            azure_client = conversation["azure_client"]
            await azure_client.finalize_audio_input()
        except Exception as e:
            logger.error(f"Error finalizing Azure processing: {str(e)}")

    async def _interrupt_azure_processing(self, conversation: Dict[str, Any]):
        """Interrupt current Azure processing."""
        try:
            azure_client = conversation["azure_client"]
            await azure_client.interrupt_processing()
        except Exception as e:
            logger.error(f"Error interrupting Azure processing: {str(e)}")

    async def _send_error_message(self, conversation: Dict[str, Any], error_message: str):
        """Send error message to client."""
        try:
            await conversation["connection_manager"].send_message(
                conversation["connection_id"],
                {
                    "type": "error",
                    "error": error_message,
                    "timestamp": datetime.now(timezone.utc).isoformat()
                }
            )
        except Exception as e:
            logger.error(f"Error sending error message: {str(e)}")


# Global service instance
_realtime_service = None


async def get_realtime_conversation_service() -> RealtimeConversationService:
    """Get global real-time conversation service instance."""
    global _realtime_service
    if _realtime_service is None:
        _realtime_service = RealtimeConversationService()
    return _realtime_service