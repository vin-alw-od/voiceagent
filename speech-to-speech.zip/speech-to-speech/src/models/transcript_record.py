"""TranscriptRecord data model for privacy-compliant conversation logging."""
from datetime import datetime, timezone, timedelta
from typing import Dict, Any, Optional, List
from enum import Enum
from pydantic import BaseModel, Field, validator
from uuid import UUID, uuid4
import hashlib


class RecordType(str, Enum):
    """Types of transcript records."""
    USER_QUERY = "user_query"
    SYSTEM_RESPONSE = "system_response"
    CONVERSATION_START = "conversation_start"
    CONVERSATION_END = "conversation_end"
    ERROR_EVENT = "error_event"
    SYSTEM_EVENT = "system_event"


class RetentionCategory(str, Enum):
    """Data retention categories with different policies."""
    ESSENTIAL = "essential"      # 30 days minimum
    OPERATIONAL = "operational"  # 7 days
    ANALYTICS = "analytics"      # 90 days (anonymized)
    AUDIT = "audit"             # 1 year (compliance)
    TEMPORARY = "temporary"      # 24 hours


class PrivacyLevel(str, Enum):
    """Privacy levels for transcript data."""
    PUBLIC = "public"           # No sensitive data
    INTERNAL = "internal"       # Internal company data
    CONFIDENTIAL = "confidential"  # Client confidential data
    RESTRICTED = "restricted"   # Highly sensitive data
    ANONYMIZED = "anonymized"   # Personally identifiable information removed


class ComplianceStatus(str, Enum):
    """Compliance review status."""
    PENDING = "pending"
    REVIEWED = "reviewed"
    APPROVED = "approved"
    FLAGGED = "flagged"
    EXPIRED = "expired"


class SensitivityAnalysis(BaseModel):
    """Analysis of content sensitivity for compliance."""
    contains_pii: bool = Field(default=False, description="Contains personally identifiable information")
    contains_financial: bool = Field(default=False, description="Contains financial information")
    contains_proprietary: bool = Field(default=False, description="Contains proprietary business information")
    contains_client_data: bool = Field(default=False, description="Contains client-specific data")
    sensitivity_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Overall sensitivity score")
    keywords_detected: List[str] = Field(default_factory=list, description="Sensitive keywords detected")
    confidence_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Confidence in sensitivity analysis")


class AnonymizationMetrics(BaseModel):
    """Metrics for data anonymization process."""
    anonymization_applied: bool = Field(default=False, description="Whether anonymization was applied")
    pii_redacted_count: int = Field(default=0, ge=0, description="Number of PII items redacted")
    entities_anonymized: List[str] = Field(default_factory=list, description="Types of entities anonymized")
    anonymization_method: Optional[str] = Field(default=None, description="Method used for anonymization")
    reversibility_hash: Optional[str] = Field(default=None, description="Hash for potential reversal if authorized")
    anonymization_timestamp: Optional[datetime] = Field(default=None, description="When anonymization was applied")


class RetentionMetrics(BaseModel):
    """Data retention tracking metrics."""
    retention_category: RetentionCategory = Field(default=RetentionCategory.OPERATIONAL, description="Retention category")
    retention_period_days: int = Field(default=30, gt=0, description="Retention period in days")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Record creation time")
    expires_at: datetime = Field(..., description="Record expiration time")
    deletion_scheduled: bool = Field(default=False, description="Whether deletion is scheduled")
    deletion_scheduled_at: Optional[datetime] = Field(default=None, description="When deletion was scheduled")
    compliance_holds: List[str] = Field(default_factory=list, description="Active compliance holds preventing deletion")

    @validator('expires_at', always=True)
    def calculate_expiration(cls, v, values):
        """Calculate expiration time based on retention period."""
        if 'created_at' in values and 'retention_period_days' in values:
            return values['created_at'] + timedelta(days=values['retention_period_days'])
        return v


class TranscriptRecord(BaseModel):
    """
    Privacy-compliant transcript record for conversation logging.

    Constitutional compliance:
    - Implements 30-day retention policy with automatic expiration
    - Supports anonymization for privacy protection
    - Includes sensitivity analysis for compliance review
    - Tracks data lineage and access for audit trails
    - Enables selective deletion and compliance holds
    """

    # Core identification
    record_id: UUID = Field(default_factory=uuid4, description="Unique record identifier")
    session_id: UUID = Field(..., description="Parent conversation session")
    query_id: Optional[UUID] = Field(default=None, description="Associated query if applicable")
    user_id: str = Field(..., min_length=1, max_length=255, description="User identifier")

    # Record content and metadata
    record_type: RecordType = Field(..., description="Type of transcript record")
    content: str = Field(..., description="Transcript content")
    content_hash: str = Field(..., description="Hash of original content for integrity")
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Record timestamp")
    sequence_number: int = Field(default=0, ge=0, description="Sequence number within session")

    # Privacy and compliance
    privacy_level: PrivacyLevel = Field(default=PrivacyLevel.INTERNAL, description="Privacy classification")
    compliance_status: ComplianceStatus = Field(default=ComplianceStatus.PENDING, description="Compliance review status")
    sensitivity_analysis: SensitivityAnalysis = Field(default_factory=SensitivityAnalysis, description="Content sensitivity analysis")
    anonymization_metrics: AnonymizationMetrics = Field(default_factory=AnonymizationMetrics, description="Anonymization tracking")

    # Retention management
    retention_metrics: RetentionMetrics = Field(..., description="Data retention tracking")

    # Context and metadata
    context_data: Dict[str, Any] = Field(default_factory=dict, description="Additional context information")
    processing_metadata: Dict[str, Any] = Field(default_factory=dict, description="Processing metadata")

    # Access tracking
    access_log: List[Dict[str, Any]] = Field(default_factory=list, description="Access history for audit trail")
    last_accessed_at: Optional[datetime] = Field(default=None, description="Last access timestamp")
    access_count: int = Field(default=0, ge=0, description="Number of times accessed")

    # Quality and confidence
    transcription_confidence: float = Field(default=0.0, ge=0.0, le=1.0, description="Transcription confidence score")
    quality_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Overall record quality score")

    class Config:
        """Pydantic model configuration."""
        use_enum_values = True
        validate_assignment = True
        extra = "forbid"
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }

    @validator('content_hash', always=True)
    def generate_content_hash(cls, v, values):
        """Generate hash of content for integrity verification."""
        if 'content' in values:
            content = values['content']
            return hashlib.sha256(content.encode('utf-8')).hexdigest()
        return v

    @validator('retention_metrics', always=True)
    def set_default_retention(cls, v, values):
        """Set default retention metrics if not provided."""
        if isinstance(v, dict):
            # Create RetentionMetrics from dict
            retention_data = v.copy()
            if 'created_at' not in retention_data:
                retention_data['created_at'] = datetime.now(timezone.utc)
            if 'expires_at' not in retention_data:
                retention_period = retention_data.get('retention_period_days', 30)
                retention_data['expires_at'] = retention_data['created_at'] + timedelta(days=retention_period)
            return RetentionMetrics(**retention_data)
        return v

    def analyze_sensitivity(self, enable_detailed_analysis: bool = True) -> SensitivityAnalysis:
        """
        Analyze content for sensitivity and compliance requirements.

        Args:
            enable_detailed_analysis: Whether to perform detailed NLP analysis

        Returns:
            Updated sensitivity analysis
        """
        analysis = self.sensitivity_analysis

        # Basic keyword-based detection
        sensitive_keywords = [
            # PII patterns
            'ssn', 'social security', 'credit card', 'passport',
            # Financial patterns
            'salary', 'budget', 'revenue', 'profit', 'cost',
            # Proprietary patterns
            'confidential', 'proprietary', 'trade secret', 'internal only'
        ]

        content_lower = self.content.lower()
        detected_keywords = [kw for kw in sensitive_keywords if kw in content_lower]

        analysis.keywords_detected = detected_keywords
        analysis.contains_pii = any(kw in ['ssn', 'social security', 'credit card', 'passport'] for kw in detected_keywords)
        analysis.contains_financial = any(kw in ['salary', 'budget', 'revenue', 'profit', 'cost'] for kw in detected_keywords)
        analysis.contains_proprietary = any(kw in ['confidential', 'proprietary', 'trade secret'] for kw in detected_keywords)

        # Calculate sensitivity score
        score = 0.0
        if analysis.contains_pii:
            score += 0.4
        if analysis.contains_financial:
            score += 0.3
        if analysis.contains_proprietary:
            score += 0.3

        analysis.sensitivity_score = min(1.0, score)
        analysis.confidence_score = 0.8 if enable_detailed_analysis else 0.6

        # Update privacy level based on sensitivity
        if analysis.sensitivity_score >= 0.8:
            self.privacy_level = PrivacyLevel.RESTRICTED
        elif analysis.sensitivity_score >= 0.5:
            self.privacy_level = PrivacyLevel.CONFIDENTIAL
        elif analysis.sensitivity_score >= 0.2:
            self.privacy_level = PrivacyLevel.INTERNAL
        else:
            self.privacy_level = PrivacyLevel.PUBLIC

        return analysis

    def apply_anonymization(self, method: str = "redaction") -> bool:
        """
        Apply anonymization to the transcript content.

        Args:
            method: Anonymization method to use

        Returns:
            True if anonymization was successful
        """
        if self.anonymization_metrics.anonymization_applied:
            return True  # Already anonymized

        try:
            original_content = self.content
            anonymized_content = original_content

            # Simple redaction-based anonymization
            sensitive_patterns = {
                'email': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
                'phone': r'\b\d{3}-\d{3}-\d{4}\b',
                'ssn': r'\b\d{3}-\d{2}-\d{4}\b',
                'credit_card': r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b'
            }

            entities_anonymized = []
            redaction_count = 0

            for entity_type, pattern in sensitive_patterns.items():
                import re
                matches = re.findall(pattern, anonymized_content)
                if matches:
                    anonymized_content = re.sub(pattern, f'[REDACTED_{entity_type.upper()}]', anonymized_content)
                    entities_anonymized.append(entity_type)
                    redaction_count += len(matches)

            # Update content and metrics
            if redaction_count > 0:
                # Store hash of original for potential authorized reversal
                self.anonymization_metrics.reversibility_hash = hashlib.sha256(
                    original_content.encode('utf-8')
                ).hexdigest()

                self.content = anonymized_content
                self.content_hash = hashlib.sha256(anonymized_content.encode('utf-8')).hexdigest()

            # Update anonymization metrics
            self.anonymization_metrics.anonymization_applied = True
            self.anonymization_metrics.pii_redacted_count = redaction_count
            self.anonymization_metrics.entities_anonymized = entities_anonymized
            self.anonymization_metrics.anonymization_method = method
            self.anonymization_metrics.anonymization_timestamp = datetime.now(timezone.utc)

            # Update privacy level
            if redaction_count > 0:
                self.privacy_level = PrivacyLevel.ANONYMIZED

            return True

        except Exception as e:
            self.processing_metadata['anonymization_error'] = str(e)
            return False

    def log_access(self, accessor_id: str, access_purpose: str, ip_address: Optional[str] = None):
        """
        Log access to this transcript record for audit trail.

        Args:
            accessor_id: ID of entity accessing the record
            access_purpose: Purpose of access
            ip_address: IP address of accessor if available
        """
        access_entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "accessor_id": accessor_id,
            "access_purpose": access_purpose,
            "ip_address": ip_address,
            "record_id": str(self.record_id)
        }

        self.access_log.append(access_entry)
        self.last_accessed_at = datetime.now(timezone.utc)
        self.access_count += 1

    def is_expired(self) -> bool:
        """Check if record has expired according to retention policy."""
        return datetime.now(timezone.utc) > self.retention_metrics.expires_at

    def can_be_deleted(self) -> bool:
        """Check if record can be deleted (expired and no compliance holds)."""
        return (self.is_expired() and
                not self.retention_metrics.compliance_holds and
                self.compliance_status != ComplianceStatus.FLAGGED)

    def schedule_deletion(self):
        """Schedule record for deletion."""
        if self.can_be_deleted():
            self.retention_metrics.deletion_scheduled = True
            self.retention_metrics.deletion_scheduled_at = datetime.now(timezone.utc)

    def extend_retention(self, additional_days: int, reason: str):
        """
        Extend retention period.

        Args:
            additional_days: Number of additional days to retain
            reason: Reason for extension
        """
        self.retention_metrics.expires_at += timedelta(days=additional_days)
        self.processing_metadata[f'retention_extended_{datetime.now(timezone.utc).isoformat()}'] = {
            'additional_days': additional_days,
            'reason': reason
        }

    def add_compliance_hold(self, hold_reason: str, requestor: str):
        """
        Add compliance hold to prevent deletion.

        Args:
            hold_reason: Reason for compliance hold
            requestor: Entity requesting the hold
        """
        hold_id = f"{requestor}_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}"
        self.retention_metrics.compliance_holds.append(hold_id)
        self.processing_metadata[f'compliance_hold_{hold_id}'] = {
            'reason': hold_reason,
            'requestor': requestor,
            'timestamp': datetime.now(timezone.utc).isoformat()
        }

    def remove_compliance_hold(self, hold_id: str, authorized_by: str):
        """
        Remove compliance hold.

        Args:
            hold_id: ID of hold to remove
            authorized_by: Entity authorizing hold removal
        """
        if hold_id in self.retention_metrics.compliance_holds:
            self.retention_metrics.compliance_holds.remove(hold_id)
            self.processing_metadata[f'hold_removed_{hold_id}'] = {
                'authorized_by': authorized_by,
                'timestamp': datetime.now(timezone.utc).isoformat()
            }

    def get_compliance_summary(self) -> Dict[str, Any]:
        """
        Get compliance summary for review.

        Returns:
            Dictionary with compliance information
        """
        return {
            "record_id": str(self.record_id),
            "privacy_level": self.privacy_level.value,
            "compliance_status": self.compliance_status.value,
            "sensitivity_score": self.sensitivity_analysis.sensitivity_score,
            "contains_sensitive_data": any([
                self.sensitivity_analysis.contains_pii,
                self.sensitivity_analysis.contains_financial,
                self.sensitivity_analysis.contains_proprietary
            ]),
            "anonymization_applied": self.anonymization_metrics.anonymization_applied,
            "retention_info": {
                "category": self.retention_metrics.retention_category.value,
                "expires_at": self.retention_metrics.expires_at.isoformat(),
                "days_until_expiry": (self.retention_metrics.expires_at - datetime.now(timezone.utc)).days,
                "can_be_deleted": self.can_be_deleted(),
                "compliance_holds": len(self.retention_metrics.compliance_holds)
            },
            "access_info": {
                "access_count": self.access_count,
                "last_accessed": self.last_accessed_at.isoformat() if self.last_accessed_at else None,
                "unique_accessors": len(set(entry.get("accessor_id") for entry in self.access_log))
            },
            "constitutional_compliance": {
                "retention_policy_met": self.retention_metrics.retention_period_days <= 30,
                "privacy_protection_active": self.privacy_level != PrivacyLevel.PUBLIC or self.anonymization_metrics.anonymization_applied
            }
        }

    def to_api_response(self, include_content: bool = True, accessor_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Convert to API response format with privacy controls.

        Args:
            include_content: Whether to include actual content
            accessor_id: ID of entity requesting data (for audit logging)

        Returns:
            Dictionary suitable for API response
        """
        if accessor_id:
            self.log_access(accessor_id, "api_response_generation")

        response = {
            "record_id": str(self.record_id),
            "session_id": str(self.session_id),
            "record_type": self.record_type.value,
            "timestamp": self.timestamp.isoformat(),
            "privacy_level": self.privacy_level.value,
            "quality_score": self.quality_score,
            "transcription_confidence": self.transcription_confidence,
            "sequence_number": self.sequence_number
        }

        # Include content based on privacy level and permissions
        if include_content:
            if self.privacy_level in [PrivacyLevel.PUBLIC, PrivacyLevel.ANONYMIZED]:
                response["content"] = self.content
            elif self.privacy_level == PrivacyLevel.INTERNAL:
                response["content"] = self.content
                response["content_warning"] = "Internal use only"
            else:
                response["content"] = "[RESTRICTED CONTENT]"
                response["access_denied_reason"] = "Insufficient permissions for sensitive content"

        # Include metadata
        response["compliance_info"] = {
            "compliance_status": self.compliance_status.value,
            "anonymized": self.anonymization_metrics.anonymization_applied,
            "retention_category": self.retention_metrics.retention_category.value
        }

        return response