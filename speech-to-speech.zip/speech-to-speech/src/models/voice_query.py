"""VoiceQuery data model."""
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from enum import Enum
from pydantic import BaseModel, Field, validator
from uuid import UUID, uuid4


class QueryStatus(str, Enum):
    """Enumeration of possible query processing statuses."""
    RECEIVED = "received"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    FALLBACK = "fallback"


class AudioFormat(str, Enum):
    """Supported audio formats."""
    WAV = "wav"
    MP3 = "mp3"
    FLAC = "flac"
    OGG = "ogg"


class ProcessingStage(BaseModel):
    """Represents a stage in query processing with timing."""
    stage_name: str = Field(..., description="Name of the processing stage")
    start_time: datetime = Field(..., description="Stage start time")
    end_time: Optional[datetime] = Field(default=None, description="Stage end time")
    duration_ms: float = Field(default=0.0, ge=0.0, description="Stage duration in milliseconds")
    success: bool = Field(default=False, description="Whether stage completed successfully")
    error_message: Optional[str] = Field(default=None, description="Error message if stage failed")
    cost_usd: float = Field(default=0.0, ge=0.0, description="Cost for this stage in USD")

    def complete_stage(self, success: bool = True, error_message: Optional[str] = None, cost_usd: float = 0.0):
        """Mark stage as completed."""
        self.end_time = datetime.now(timezone.utc)
        self.duration_ms = (self.end_time - self.start_time).total_seconds() * 1000
        self.success = success
        self.error_message = error_message
        self.cost_usd = cost_usd


class AudioMetrics(BaseModel):
    """Audio quality and processing metrics."""
    file_size_bytes: int = Field(default=0, ge=0, description="Audio file size in bytes")
    duration_seconds: float = Field(default=0.0, ge=0.0, description="Audio duration in seconds")
    sample_rate: Optional[int] = Field(default=None, description="Audio sample rate")
    bit_rate: Optional[int] = Field(default=None, description="Audio bit rate")
    audio_quality_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Audio quality score (0-1)")
    noise_level: float = Field(default=0.0, ge=0.0, le=1.0, description="Background noise level (0-1)")
    clarity_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Audio clarity score (0-1)")


class TranscriptionMetrics(BaseModel):
    """Speech-to-text transcription metrics."""
    confidence_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Transcription confidence (0-1)")
    word_count: int = Field(default=0, ge=0, description="Number of words transcribed")
    processing_time_ms: float = Field(default=0.0, ge=0.0, description="Transcription processing time")
    alternative_transcriptions: List[str] = Field(default_factory=list, description="Alternative transcription options")
    language_detected: Optional[str] = Field(default=None, description="Detected language code")
    accent_confidence: float = Field(default=0.0, ge=0.0, le=1.0, description="Accent detection confidence")


class ResponseGenerationMetrics(BaseModel):
    """Response generation and TTS metrics."""
    knowledge_retrieval_time_ms: float = Field(default=0.0, ge=0.0, description="Knowledge search time")
    text_generation_time_ms: float = Field(default=0.0, ge=0.0, description="Text response generation time")
    tts_processing_time_ms: float = Field(default=0.0, ge=0.0, description="Text-to-speech processing time")
    knowledge_sources_used: List[str] = Field(default_factory=list, description="Knowledge sources referenced")
    response_relevance_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Response relevance score")
    audio_generation_quality: float = Field(default=0.0, ge=0.0, le=1.0, description="Generated audio quality")


class VoiceQuery(BaseModel):
    """
    Represents a voice query submitted to the speech-to-speech system.

    Constitutional compliance:
    - Tracks processing time to ensure <800ms latency requirement
    - Includes cost tracking for optimization
    - Maintains audit trail for privacy compliance
    - Supports graceful degradation with fallback handling
    """

    # Core identification
    query_id: UUID = Field(default_factory=uuid4, description="Unique query identifier")
    session_id: UUID = Field(..., description="Parent session identifier")
    user_id: str = Field(..., min_length=1, max_length=255, description="User identifier")

    # Query lifecycle
    status: QueryStatus = Field(default=QueryStatus.RECEIVED, description="Current query processing status")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Query creation timestamp")
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Last update timestamp")
    completed_at: Optional[datetime] = Field(default=None, description="Query completion timestamp")

    # Audio input
    audio_format: AudioFormat = Field(..., description="Format of the input audio")
    audio_file_path: Optional[str] = Field(default=None, description="Path to stored audio file")
    audio_url: Optional[str] = Field(default=None, description="URL to access audio file")
    audio_metrics: AudioMetrics = Field(default_factory=AudioMetrics, description="Audio quality metrics")

    # Processing results
    transcription: str = Field(default="", description="Transcribed text from audio")
    transcription_metrics: TranscriptionMetrics = Field(default_factory=TranscriptionMetrics, description="Transcription quality metrics")

    response_text: str = Field(default="", description="Generated text response")
    response_audio_url: Optional[str] = Field(default=None, description="URL to generated audio response")
    response_metrics: ResponseGenerationMetrics = Field(default_factory=ResponseGenerationMetrics, description="Response generation metrics")

    # Processing pipeline
    processing_stages: List[ProcessingStage] = Field(default_factory=list, description="Detailed processing stage tracking")
    total_processing_time_ms: float = Field(default=0.0, ge=0.0, description="Total processing time in milliseconds")

    # Error handling and fallbacks
    error_details: Optional[Dict[str, Any]] = Field(default=None, description="Error details if processing failed")
    fallback_used: bool = Field(default=False, description="Whether fallback response was used")
    fallback_reason: Optional[str] = Field(default=None, description="Reason for using fallback")

    # Context and metadata
    context_used: Dict[str, Any] = Field(default_factory=dict, description="Conversation context used for this query")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional query metadata")

    # Cost optimization
    cost_breakdown: Dict[str, float] = Field(default_factory=dict, description="Cost breakdown by service")
    total_cost_usd: float = Field(default=0.0, ge=0.0, description="Total cost for this query")
    optimization_applied: Dict[str, bool] = Field(default_factory=dict, description="Cost optimizations applied")

    # Privacy and compliance
    retention_policy: str = Field(default="30_days", description="Data retention policy")
    privacy_flags: Dict[str, bool] = Field(default_factory=dict, description="Privacy compliance flags")

    class Config:
        """Pydantic model configuration."""
        use_enum_values = True
        validate_assignment = True
        extra = "forbid"
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }

    @validator('updated_at', always=True)
    def set_updated_at(cls, v):
        """Always update the timestamp when the model is modified."""
        return datetime.now(timezone.utc)

    @validator('total_processing_time_ms')
    def validate_constitutional_latency(cls, v):
        """Validate processing time meets constitutional requirement."""
        if v > 800.0:
            # Log constitutional violation but don't fail the model
            # This will be used for monitoring and alerts
            pass
        return v

    def start_processing_stage(self, stage_name: str) -> ProcessingStage:
        """
        Start a new processing stage.

        Args:
            stage_name: Name of the processing stage

        Returns:
            ProcessingStage object for tracking
        """
        stage = ProcessingStage(
            stage_name=stage_name,
            start_time=datetime.now(timezone.utc)
        )
        self.processing_stages.append(stage)
        self.status = QueryStatus.PROCESSING
        return stage

    def complete_processing(self, success: bool = True, error_details: Optional[Dict[str, Any]] = None):
        """
        Mark query processing as completed.

        Args:
            success: Whether processing was successful
            error_details: Error details if processing failed
        """
        self.completed_at = datetime.now(timezone.utc)
        self.total_processing_time_ms = (self.completed_at - self.created_at).total_seconds() * 1000

        if success:
            self.status = QueryStatus.COMPLETED
        else:
            self.status = QueryStatus.FAILED
            self.error_details = error_details

        # Check constitutional compliance
        if self.total_processing_time_ms > 800.0:
            self.metadata["constitutional_violation"] = {
                "requirement": "latency_800ms",
                "actual_ms": self.total_processing_time_ms,
                "violation_time": datetime.now(timezone.utc).isoformat()
            }

    def set_transcription(self, text: str, confidence: float, processing_time_ms: float, cost_usd: float = 0.0):
        """
        Set transcription results.

        Args:
            text: Transcribed text
            confidence: Confidence score (0-1)
            processing_time_ms: Processing time for transcription
            cost_usd: Cost for transcription service
        """
        self.transcription = text
        self.transcription_metrics.confidence_score = confidence
        self.transcription_metrics.processing_time_ms = processing_time_ms
        self.transcription_metrics.word_count = len(text.split()) if text else 0

        # Update cost tracking
        self.cost_breakdown["transcription"] = cost_usd
        self.total_cost_usd += cost_usd

    def set_response(self, text: str, audio_url: Optional[str] = None, relevance_score: float = 1.0, cost_usd: float = 0.0):
        """
        Set response generation results.

        Args:
            text: Generated response text
            audio_url: URL to generated audio
            relevance_score: Response relevance score (0-1)
            cost_usd: Cost for response generation
        """
        self.response_text = text
        self.response_audio_url = audio_url
        self.response_metrics.response_relevance_score = relevance_score

        # Update cost tracking
        self.cost_breakdown["response_generation"] = cost_usd
        self.total_cost_usd += cost_usd

    def use_fallback(self, reason: str, fallback_text: str):
        """
        Use fallback response for graceful degradation.

        Args:
            reason: Reason for using fallback
            fallback_text: Fallback response text
        """
        self.fallback_used = True
        self.fallback_reason = reason
        self.status = QueryStatus.FALLBACK
        self.response_text = fallback_text

        # Fallback responses should be fast and low-cost
        self.cost_breakdown["fallback"] = 0.0

    def get_performance_summary(self) -> Dict[str, Any]:
        """
        Get performance summary for monitoring.

        Returns:
            Dictionary with performance metrics
        """
        return {
            "query_id": str(self.query_id),
            "total_processing_time_ms": self.total_processing_time_ms,
            "constitutional_compliant": self.total_processing_time_ms <= 800.0,
            "status": self.status.value,
            "stages_completed": len([s for s in self.processing_stages if s.success]),
            "stages_failed": len([s for s in self.processing_stages if not s.success]),
            "transcription_confidence": self.transcription_metrics.confidence_score,
            "audio_quality": self.audio_metrics.audio_quality_score,
            "response_relevance": self.response_metrics.response_relevance_score,
            "total_cost_usd": self.total_cost_usd,
            "cost_per_second": (self.total_cost_usd / (self.total_processing_time_ms / 1000.0)
                               if self.total_processing_time_ms > 0 else 0.0),
            "fallback_used": self.fallback_used,
            "error_occurred": self.status == QueryStatus.FAILED
        }

    def get_quality_assessment(self) -> Dict[str, Any]:
        """
        Get quality assessment for the query.

        Returns:
            Dictionary with quality metrics and recommendations
        """
        audio_score = self.audio_metrics.audio_quality_score
        transcription_score = self.transcription_metrics.confidence_score
        response_score = self.response_metrics.response_relevance_score

        overall_quality = (audio_score + transcription_score + response_score) / 3

        return {
            "overall_quality_score": overall_quality,
            "audio_quality": audio_score,
            "transcription_quality": transcription_score,
            "response_quality": response_score,
            "quality_grade": self._get_quality_grade(overall_quality),
            "improvement_recommendations": self._get_quality_recommendations(audio_score, transcription_score, response_score),
            "meets_quality_threshold": overall_quality >= 0.7
        }

    def _get_quality_grade(self, score: float) -> str:
        """Get quality grade based on score."""
        if score >= 0.9:
            return "excellent"
        elif score >= 0.8:
            return "good"
        elif score >= 0.7:
            return "acceptable"
        elif score >= 0.5:
            return "poor"
        else:
            return "very_poor"

    def _get_quality_recommendations(self, audio: float, transcription: float, response: float) -> List[str]:
        """Get quality improvement recommendations."""
        recommendations = []

        if audio < 0.7:
            recommendations.append("Improve audio input quality - reduce background noise")
        if transcription < 0.7:
            recommendations.append("Consider audio preprocessing or alternative transcription service")
        if response < 0.7:
            recommendations.append("Enhance knowledge base or response generation prompts")

        if not recommendations:
            recommendations.append("Quality is good - consider optimizing for cost")

        return recommendations

    def should_trigger_quality_alert(self) -> bool:
        """Determine if this query should trigger a quality alert."""
        # Constitutional violation
        if self.total_processing_time_ms > 800.0:
            return True

        # Very low quality
        quality = self.get_quality_assessment()
        if quality["overall_quality_score"] < 0.5:
            return True

        # High cost
        if self.total_cost_usd > 1.00:  # $1.00 per query threshold
            return True

        # Processing failure
        if self.status == QueryStatus.FAILED:
            return True

        return False

    def to_api_response(self) -> Dict[str, Any]:
        """Convert to API response format."""
        return {
            "query_id": str(self.query_id),
            "session_id": str(self.session_id),
            "transcription": self.transcription,
            "response_text": self.response_text,
            "audio_url": self.response_audio_url,
            "processing_time_ms": self.total_processing_time_ms,
            "confidence_score": self.transcription_metrics.confidence_score,
            "audio_quality_score": self.audio_metrics.audio_quality_score,
            "status": self.status.value,
            "fallback_used": self.fallback_used,
            "constitutional_compliant": self.total_processing_time_ms <= 800.0,
            "quality_assessment": self.get_quality_assessment(),
            "cost_summary": {
                "total_cost_usd": self.total_cost_usd,
                "cost_breakdown": self.cost_breakdown
            },
            "created_at": self.created_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None
        }