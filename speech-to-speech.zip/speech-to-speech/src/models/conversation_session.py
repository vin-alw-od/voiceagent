"""ConversationSession data model."""
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from enum import Enum
from pydantic import BaseModel, Field, validator
from uuid import UUID, uuid4


class SessionStatus(str, Enum):
    """Enumeration of possible session statuses."""
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    EXPIRED = "expired"


class PerformanceMetrics(BaseModel):
    """Performance metrics for a conversation session."""
    total_queries: int = Field(default=0, ge=0, description="Total number of queries in this session")
    average_latency_ms: float = Field(default=0.0, ge=0.0, description="Average response latency in milliseconds")
    total_processing_time_ms: float = Field(default=0.0, ge=0.0, description="Total processing time across all queries")
    successful_queries: int = Field(default=0, ge=0, description="Number of successful queries")
    failed_queries: int = Field(default=0, ge=0, description="Number of failed queries")
    audio_quality_average: float = Field(default=0.0, ge=0.0, le=1.0, description="Average audio quality score")
    confidence_score_average: float = Field(default=0.0, ge=0.0, le=1.0, description="Average transcription confidence")
    cost_estimate_usd: float = Field(default=0.0, ge=0.0, description="Estimated cost for this session in USD")

    @validator('average_latency_ms')
    def validate_latency_constitutional_requirement(cls, v):
        """Validate that average latency meets constitutional requirement."""
        if v > 800.0:
            # Log warning but don't fail - this is for monitoring
            pass
        return v


class QualityMetrics(BaseModel):
    """Audio and transcription quality metrics."""
    average_confidence: float = Field(default=0.0, ge=0.0, le=1.0, description="Average transcription confidence")
    average_audio_quality: float = Field(default=0.0, ge=0.0, le=1.0, description="Average audio quality score")
    quality_trend: str = Field(default="stable", description="Quality trend: improving, stable, degrading")
    low_quality_count: int = Field(default=0, ge=0, description="Number of low quality audio inputs")
    processing_errors: int = Field(default=0, ge=0, description="Number of processing errors")
    fallback_responses: int = Field(default=0, ge=0, description="Number of fallback responses used")


class ConversationSession(BaseModel):
    """
    Represents a conversation session between a user and the speech-to-speech system.

    Constitutional compliance:
    - Tracks performance metrics to ensure <800ms latency requirement
    - Includes cost optimization tracking
    - Maintains audit trail for privacy compliance
    - Supports graceful degradation monitoring
    """

    # Core identification
    session_id: UUID = Field(default_factory=uuid4, description="Unique session identifier")
    user_id: str = Field(..., min_length=1, max_length=255, description="User identifier")

    # Session lifecycle
    status: SessionStatus = Field(default=SessionStatus.ACTIVE, description="Current session status")
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Session creation timestamp")
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), description="Last update timestamp")
    expires_at: Optional[datetime] = Field(default=None, description="Session expiration timestamp")
    completed_at: Optional[datetime] = Field(default=None, description="Session completion timestamp")

    # Context and configuration
    context_data: Dict[str, Any] = Field(default_factory=dict, description="User context and conversation metadata")
    session_config: Dict[str, Any] = Field(default_factory=dict, description="Session-specific configuration")

    # Performance and quality tracking
    performance_metrics: PerformanceMetrics = Field(default_factory=PerformanceMetrics, description="Session performance metrics")
    quality_metrics: QualityMetrics = Field(default_factory=QualityMetrics, description="Audio and transcription quality metrics")

    # Query tracking
    query_count: int = Field(default=0, ge=0, description="Number of queries processed in this session")
    last_query_at: Optional[datetime] = Field(default=None, description="Timestamp of last query")

    # Error tracking and graceful degradation
    error_count: int = Field(default=0, ge=0, description="Number of errors encountered")
    last_error_at: Optional[datetime] = Field(default=None, description="Timestamp of last error")
    degradation_level: str = Field(default="none", description="Current degradation level: none, minimal, moderate, high")

    # Privacy and compliance
    data_retention_policy: str = Field(default="30_days", description="Data retention policy for this session")
    compliance_flags: Dict[str, bool] = Field(default_factory=dict, description="Compliance tracking flags")

    # Cost optimization
    cost_tracking: Dict[str, float] = Field(default_factory=dict, description="Cost tracking by service")
    optimization_flags: Dict[str, bool] = Field(default_factory=dict, description="Cost optimization settings")

    class Config:
        """Pydantic model configuration."""
        use_enum_values = True
        validate_assignment = True
        extra = "forbid"
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            UUID: lambda v: str(v)
        }

    @validator('updated_at', always=True)
    def set_updated_at(cls, v):
        """Always update the timestamp when the model is modified."""
        return datetime.now(timezone.utc)

    @validator('expires_at')
    def validate_expiration(cls, v, values):
        """Validate expiration time is after creation time."""
        if v and 'created_at' in values:
            if v <= values['created_at']:
                raise ValueError("Expiration time must be after creation time")
        return v

    @validator('completed_at')
    def validate_completion(cls, v, values):
        """Validate completion time and set status."""
        if v and 'created_at' in values:
            if v < values['created_at']:
                raise ValueError("Completion time cannot be before creation time")
        return v

    def update_performance_metrics(self, latency_ms: float, success: bool, cost_usd: float = 0.0):
        """
        Update performance metrics after a query.

        Args:
            latency_ms: Response latency in milliseconds
            success: Whether the query was successful
            cost_usd: Estimated cost for this query
        """
        metrics = self.performance_metrics

        # Update query counts
        metrics.total_queries += 1
        if success:
            metrics.successful_queries += 1
        else:
            metrics.failed_queries += 1

        # Update timing metrics
        metrics.total_processing_time_ms += latency_ms
        metrics.average_latency_ms = metrics.total_processing_time_ms / metrics.total_queries

        # Update cost tracking
        metrics.cost_estimate_usd += cost_usd

        # Update session-level tracking
        self.query_count = metrics.total_queries
        self.last_query_at = datetime.now(timezone.utc)

        # Check constitutional compliance
        if metrics.average_latency_ms > 800.0:
            self.compliance_flags["latency_requirement"] = False
        else:
            self.compliance_flags["latency_requirement"] = True

    def update_quality_metrics(self, confidence_score: float, audio_quality: float, had_error: bool = False):
        """
        Update quality metrics after processing audio.

        Args:
            confidence_score: Transcription confidence (0.0-1.0)
            audio_quality: Audio quality score (0.0-1.0)
            had_error: Whether processing had errors
        """
        metrics = self.quality_metrics
        total_queries = self.performance_metrics.total_queries

        if total_queries > 0:
            # Update running averages
            metrics.average_confidence = (
                (metrics.average_confidence * (total_queries - 1) + confidence_score) / total_queries
            )
            metrics.average_audio_quality = (
                (metrics.average_audio_quality * (total_queries - 1) + audio_quality) / total_queries
            )

        # Track quality issues
        if audio_quality < 0.5:  # Low quality threshold
            metrics.low_quality_count += 1

        if had_error:
            metrics.processing_errors += 1
            self.error_count += 1
            self.last_error_at = datetime.now(timezone.utc)

    def should_use_fallback(self) -> bool:
        """
        Determine if fallback responses should be used based on session state.

        Returns:
            True if fallback should be used for graceful degradation
        """
        # Use fallback if error rate is high
        if self.performance_metrics.total_queries > 0:
            error_rate = self.performance_metrics.failed_queries / self.performance_metrics.total_queries
            if error_rate > 0.3:  # More than 30% errors
                return True

        # Use fallback if average quality is very low
        if self.quality_metrics.average_audio_quality < 0.3:
            return True

        # Use fallback if latency is consistently high
        if self.performance_metrics.average_latency_ms > 1000.0:
            return True

        return False

    def get_cost_summary(self) -> Dict[str, Any]:
        """
        Get cost summary for optimization analysis.

        Returns:
            Dictionary with cost breakdown and optimization opportunities
        """
        total_cost = self.performance_metrics.cost_estimate_usd
        queries = self.performance_metrics.total_queries

        return {
            "total_cost_usd": total_cost,
            "cost_per_query": total_cost / queries if queries > 0 else 0.0,
            "total_queries": queries,
            "cost_breakdown": self.cost_tracking.copy(),
            "optimization_active": self.optimization_flags.copy(),
            "efficiency_score": self._calculate_efficiency_score()
        }

    def _calculate_efficiency_score(self) -> float:
        """
        Calculate efficiency score based on performance and cost.

        Returns:
            Efficiency score from 0.0 to 1.0 (higher is better)
        """
        if self.performance_metrics.total_queries == 0:
            return 1.0

        # Factor in latency (constitutional requirement)
        latency_score = max(0.0, 1.0 - (self.performance_metrics.average_latency_ms / 800.0))

        # Factor in success rate
        success_rate = (self.performance_metrics.successful_queries /
                       self.performance_metrics.total_queries)

        # Factor in cost (lower cost per query is better)
        cost_per_query = self.performance_metrics.cost_estimate_usd / self.performance_metrics.total_queries
        cost_score = max(0.0, 1.0 - (cost_per_query / 0.50))  # $0.50 per query baseline

        # Weighted average
        return (latency_score * 0.4 + success_rate * 0.4 + cost_score * 0.2)

    def is_expired(self) -> bool:
        """Check if session has expired."""
        if self.expires_at:
            return datetime.now(timezone.utc) > self.expires_at
        return False

    def extend_session(self, hours: int = 1):
        """Extend session expiration time."""
        if not self.expires_at:
            self.expires_at = datetime.now(timezone.utc)

        from datetime import timedelta
        self.expires_at += timedelta(hours=hours)

    def complete_session(self, reason: str = "user_ended"):
        """Mark session as completed."""
        self.status = SessionStatus.COMPLETED
        self.completed_at = datetime.now(timezone.utc)
        self.context_data["completion_reason"] = reason

    def to_api_response(self) -> Dict[str, Any]:
        """Convert to API response format."""
        return {
            "session_id": str(self.session_id),
            "user_id": self.user_id,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "context_data": self.context_data,
            "performance_metrics": self.performance_metrics.dict(),
            "quality_metrics": self.quality_metrics.dict(),
            "query_count": self.query_count,
            "constitutional_compliance": {
                "latency_requirement_met": self.compliance_flags.get("latency_requirement", True),
                "average_latency_ms": self.performance_metrics.average_latency_ms
            },
            "cost_summary": self.get_cost_summary()
        }