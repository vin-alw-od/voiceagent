"""ChromaDB vector database integration client."""
import asyncio
import json
import time
from typing import Dict, Any, Optional, List, Tuple
from uuid import UUID
import logging
import chromadb
from chromadb.config import Settings

from ..lib.config import get_settings

logger = logging.getLogger(__name__)


class VectorDatabaseError(Exception):
    """Base exception for vector database errors."""
    pass


class VectorDatabaseClient:
    """
    ChromaDB integration client for semantic search and knowledge storage.

    Responsibilities:
    - Store and retrieve document embeddings
    - Perform semantic similarity searches
    - Manage knowledge base collections
    - Ensure fast retrieval for <800ms latency requirement
    - Implement cost optimization through efficient indexing
    """

    def __init__(self):
        """Initialize ChromaDB client."""
        self.settings = get_settings()
        self.client = None
        self.collections = {}
        self._initialize_client()

        # Performance settings for constitutional compliance
        self.max_search_time_ms = 300.0  # Reserve time for other processing
        self.default_collection = "knowledge_base"

    def _initialize_client(self):
        """Initialize ChromaDB client with configuration."""
        try:
            # Configure ChromaDB settings
            chroma_settings = Settings(
                chroma_db_impl="duckdb+parquet",
                persist_directory=self.settings.chroma_persist_directory,
                anonymized_telemetry=False
            )

            self.client = chromadb.Client(chroma_settings)
            logger.info("ChromaDB client initialized successfully")

            # Initialize default collection
            self._get_or_create_collection(self.default_collection)

        except Exception as e:
            logger.error(f"Failed to initialize ChromaDB client: {str(e)}")
            raise VectorDatabaseError(f"Client initialization failed: {str(e)}")

    def _get_or_create_collection(self, collection_name: str):
        """Get or create a ChromaDB collection."""
        try:
            if collection_name not in self.collections:
                collection = self.client.get_or_create_collection(
                    name=collection_name,
                    metadata={"hnsw:space": "cosine"}  # Use cosine similarity
                )
                self.collections[collection_name] = collection
                logger.info(f"Collection '{collection_name}' ready")

            return self.collections[collection_name]

        except Exception as e:
            logger.error(f"Failed to get/create collection {collection_name}: {str(e)}")
            raise VectorDatabaseError(f"Collection operation failed: {str(e)}")

    async def store_document(self,
                           document_id: str,
                           content: str,
                           metadata: Dict[str, Any],
                           collection_name: Optional[str] = None) -> bool:
        """
        Store a document with its embedding in the vector database.

        Args:
            document_id: Unique document identifier
            content: Document content to embed
            metadata: Document metadata
            collection_name: Target collection (uses default if None)

        Returns:
            True if successful
        """
        try:
            collection_name = collection_name or self.default_collection
            collection = self._get_or_create_collection(collection_name)

            # Add document to collection
            # ChromaDB will automatically generate embeddings
            collection.add(
                documents=[content],
                metadatas=[metadata],
                ids=[document_id]
            )

            logger.info(f"Stored document {document_id} in collection {collection_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to store document {document_id}: {str(e)}")
            return False

    async def search_similar(self,
                           query_text: str,
                           max_results: int = 5,
                           similarity_threshold: float = 0.5,
                           collection_name: Optional[str] = None,
                           filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """
        Search for similar documents using semantic similarity.

        Args:
            query_text: Query text to search for
            max_results: Maximum number of results to return
            similarity_threshold: Minimum similarity score
            collection_name: Collection to search (uses default if None)
            filters: Metadata filters to apply

        Returns:
            List of similar documents with scores
        """
        start_time = time.time()

        try:
            collection_name = collection_name or self.default_collection
            collection = self._get_or_create_collection(collection_name)

            # Perform semantic search
            results = collection.query(
                query_texts=[query_text],
                n_results=max_results,
                where=filters  # Apply metadata filters
            )

            # Process results
            processed_results = []
            if results['documents'] and results['documents'][0]:
                documents = results['documents'][0]
                metadatas = results['metadatas'][0] if results['metadatas'] else [{}] * len(documents)
                distances = results['distances'][0] if results['distances'] else [1.0] * len(documents)
                ids = results['ids'][0] if results['ids'] else [f"doc_{i}" for i in range(len(documents))]

                for i, (doc, metadata, distance, doc_id) in enumerate(zip(documents, metadatas, distances, ids)):
                    # Convert distance to similarity (cosine distance -> similarity)
                    similarity_score = 1.0 - distance

                    # Filter by similarity threshold
                    if similarity_score >= similarity_threshold:
                        processed_results.append({
                            'document_id': doc_id,
                            'content': doc,
                            'metadata': metadata or {},
                            'similarity_score': similarity_score,
                            'rank': i + 1
                        })

            # Check constitutional compliance
            search_time_ms = (time.time() - start_time) * 1000
            if search_time_ms > self.max_search_time_ms:
                logger.warning(f"Vector search exceeded {self.max_search_time_ms}ms: {search_time_ms}ms")

            logger.info(f"Vector search returned {len(processed_results)} results in {search_time_ms:.1f}ms")

            return processed_results

        except Exception as e:
            logger.error(f"Vector search failed: {str(e)}")
            raise VectorDatabaseError(f"Search failed: {str(e)}")

    async def update_document(self,
                            document_id: str,
                            content: Optional[str] = None,
                            metadata: Optional[Dict[str, Any]] = None,
                            collection_name: Optional[str] = None) -> bool:
        """
        Update an existing document.

        Args:
            document_id: Document identifier
            content: New content (optional)
            metadata: New metadata (optional)
            collection_name: Target collection

        Returns:
            True if successful
        """
        try:
            collection_name = collection_name or self.default_collection
            collection = self._get_or_create_collection(collection_name)

            # Update document
            update_params = {"ids": [document_id]}

            if content is not None:
                update_params["documents"] = [content]

            if metadata is not None:
                update_params["metadatas"] = [metadata]

            collection.update(**update_params)

            logger.info(f"Updated document {document_id} in collection {collection_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to update document {document_id}: {str(e)}")
            return False

    async def delete_document(self,
                            document_id: str,
                            collection_name: Optional[str] = None) -> bool:
        """
        Delete a document from the vector database.

        Args:
            document_id: Document identifier
            collection_name: Target collection

        Returns:
            True if successful
        """
        try:
            collection_name = collection_name or self.default_collection
            collection = self._get_or_create_collection(collection_name)

            # Delete document
            collection.delete(ids=[document_id])

            logger.info(f"Deleted document {document_id} from collection {collection_name}")
            return True

        except Exception as e:
            logger.error(f"Failed to delete document {document_id}: {str(e)}")
            return False

    async def get_collection_stats(self, collection_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Get statistics for a collection.

        Args:
            collection_name: Collection name

        Returns:
            Collection statistics
        """
        try:
            collection_name = collection_name or self.default_collection
            collection = self._get_or_create_collection(collection_name)

            # Get collection count
            count = collection.count()

            return {
                'collection_name': collection_name,
                'document_count': count,
                'status': 'healthy' if count > 0 else 'empty'
            }

        except Exception as e:
            logger.error(f"Failed to get collection stats: {str(e)}")
            return {
                'collection_name': collection_name,
                'document_count': 0,
                'status': 'error',
                'error': str(e)
            }

    async def health_check(self) -> Dict[str, Any]:
        """
        Check vector database health.

        Returns:
            Health status information
        """
        try:
            start_time = time.time()

            # Simple health check - get collection stats
            stats = await self.get_collection_stats()

            response_time_ms = (time.time() - start_time) * 1000

            return {
                'status': 'healthy',
                'response_time_ms': response_time_ms,
                'collections_available': len(self.collections),
                'default_collection_docs': stats['document_count'],
                'last_check': time.time()
            }

        except Exception as e:
            logger.error(f"Vector database health check failed: {str(e)}")
            return {
                'status': 'unhealthy',
                'error': str(e),
                'last_check': time.time()
            }

    async def create_knowledge_base(self, documents: List[Dict[str, Any]]) -> bool:
        """
        Initialize knowledge base with documents.

        Args:
            documents: List of documents with content and metadata

        Returns:
            True if successful
        """
        try:
            success_count = 0

            for doc in documents:
                success = await self.store_document(
                    document_id=doc['id'],
                    content=doc['content'],
                    metadata=doc.get('metadata', {}),
                    collection_name=doc.get('collection', self.default_collection)
                )

                if success:
                    success_count += 1

            logger.info(f"Initialized knowledge base with {success_count}/{len(documents)} documents")
            return success_count == len(documents)

        except Exception as e:
            logger.error(f"Failed to create knowledge base: {str(e)}")
            return False


# Global client instance
_vector_db_client = None


async def get_vector_db_client() -> VectorDatabaseClient:
    """Get global vector database client instance."""
    global _vector_db_client
    if _vector_db_client is None:
        _vector_db_client = VectorDatabaseClient()
    return _vector_db_client