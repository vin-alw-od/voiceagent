"""Azure OpenAI Realtime API integration for WebSocket streaming."""
import asyncio
import json
import websockets
import base64
import time
import logging
from typing import Dict, Any, Optional, Callable
from websockets.exceptions import ConnectionClosed, WebSocketException

from ..lib.config import get_settings

logger = logging.getLogger(__name__)


class AzureRealtimeError(Exception):
    """Base exception for Azure Realtime API errors."""
    pass


class AzureRealtimeClient:
    """
    Azure OpenAI Realtime API client for streaming voice conversations.

    Features:
    - WebSocket connection to Azure OpenAI Realtime API
    - Streaming audio input and output
    - Real-time transcription and response generation
    - Constitutional compliance monitoring
    - Circuit breaker pattern for resilience
    """

    def __init__(self):
        """Initialize Azure Realtime API client."""
        self.settings = get_settings()
        self.websocket = None
        self.is_connected = False
        self.session_config = None

        # Constitutional compliance settings
        self.max_response_time_ms = 800.0
        self.connection_timeout_seconds = 10.0

        # Circuit breaker for resilience
        self.circuit_breaker = {
            "failure_count": 0,
            "failure_threshold": 3,
            "reset_timeout": 60,  # 1 minute
            "last_failure_time": 0,
            "is_open": False
        }

        # Connection and session state
        self.conversation_id = None
        self.session_id = None
        self.event_handlers = {}

    async def start_realtime_session(self) -> bool:
        """Start a new realtime session with Azure OpenAI."""
        try:
            # Check circuit breaker
            if self._is_circuit_breaker_open():
                raise AzureRealtimeError("Circuit breaker is open - Azure API unavailable")

            # Construct WebSocket URL
            websocket_url = self._build_websocket_url()

            # Connect to Azure OpenAI Realtime API
            logger.info("Connecting to Azure OpenAI Realtime API...")

            self.websocket = await websockets.connect(
                websocket_url,
                additional_headers=self._get_auth_headers(),
                timeout=self.connection_timeout_seconds
            )

            self.is_connected = True

            # Start message handler
            asyncio.create_task(self._handle_messages())

            # Send session.create event
            await self._send_event({
                "type": "session.create",
                "session": {
                    "modalities": ["text", "audio"],
                    "instructions": "You are a helpful assistant for account managers. Provide concise, professional responses about project status, budgets, and client information.",
                    "voice": "alloy",
                    "input_audio_format": "pcm16",
                    "output_audio_format": "pcm16",
                    "input_audio_transcription": {
                        "model": "whisper-1"
                    },
                    "turn_detection": {
                        "type": "server_vad",
                        "threshold": 0.5,
                        "prefix_padding_ms": 300,
                        "silence_duration_ms": 500
                    },
                    "tools": [],
                    "tool_choice": "auto",
                    "temperature": 0.7,
                    "max_response_output_tokens": 4096
                }
            })

            # Reset circuit breaker on success
            self._reset_circuit_breaker()

            logger.info("Azure Realtime session started successfully")
            return True

        except Exception as e:
            self._record_failure()
            logger.error(f"Failed to start Azure Realtime session: {str(e)}")
            raise AzureRealtimeError(f"Session start failed: {str(e)}")

    async def configure_realtime_session(self, config: Dict[str, Any]):
        """Configure the realtime session parameters."""
        try:
            self.session_config = config

            # Send session.update event
            await self._send_event({
                "type": "session.update",
                "session": config
            })

            logger.info("Azure Realtime session configured")

        except Exception as e:
            logger.error(f"Failed to configure session: {str(e)}")
            raise AzureRealtimeError(f"Session configuration failed: {str(e)}")

    async def send_audio_chunk(self, audio_data: bytes, is_final: bool = False) -> Optional[Dict[str, Any]]:
        """Send audio chunk to Azure Realtime API."""
        if not self.is_connected:
            raise AzureRealtimeError("Not connected to Azure Realtime API")

        try:
            # Encode audio data as base64
            audio_base64 = base64.b64encode(audio_data).decode('utf-8')

            # Send input_audio_buffer.append event
            await self._send_event({
                "type": "input_audio_buffer.append",
                "audio": audio_base64
            })

            # If final, commit the audio buffer
            if is_final:
                await self._send_event({
                    "type": "input_audio_buffer.commit"
                })

                # Create response
                await self._send_event({
                    "type": "response.create",
                    "response": {
                        "modalities": ["text", "audio"],
                        "instructions": "Provide a helpful response based on the audio input."
                    }
                })

            return {"status": "sent", "is_final": is_final}

        except Exception as e:
            logger.error(f"Failed to send audio chunk: {str(e)}")
            return None

    async def generate_speech_realtime(self, text: str) -> Dict[str, Any]:
        """Generate speech from text using Azure Realtime API."""
        if not self.is_connected:
            raise AzureRealtimeError("Not connected to Azure Realtime API")

        start_time = time.time()

        try:
            # Send conversation.item.create event
            await self._send_event({
                "type": "conversation.item.create",
                "item": {
                    "type": "message",
                    "role": "assistant",
                    "content": [
                        {
                            "type": "text",
                            "text": text
                        }
                    ]
                }
            })

            # Create response
            await self._send_event({
                "type": "response.create",
                "response": {
                    "modalities": ["audio"],
                    "voice": "alloy",
                    "output_audio_format": "pcm16"
                }
            })

            # The actual audio will be received via message handler
            # For now, return a placeholder
            processing_time_ms = (time.time() - start_time) * 1000

            return {
                "status": "generating",
                "processing_time_ms": processing_time_ms,
                "text": text
            }

        except Exception as e:
            logger.error(f"Failed to generate speech: {str(e)}")
            raise AzureRealtimeError(f"Speech generation failed: {str(e)}")

    async def finalize_audio_input(self):
        """Finalize current audio input processing."""
        if not self.is_connected:
            return

        try:
            # Clear the audio buffer
            await self._send_event({
                "type": "input_audio_buffer.clear"
            })

        except Exception as e:
            logger.error(f"Failed to finalize audio input: {str(e)}")

    async def interrupt_processing(self):
        """Interrupt current processing."""
        if not self.is_connected:
            return

        try:
            # Cancel current response
            await self._send_event({
                "type": "response.cancel"
            })

            # Clear audio buffer
            await self._send_event({
                "type": "input_audio_buffer.clear"
            })

        except Exception as e:
            logger.error(f"Failed to interrupt processing: {str(e)}")

    def set_event_handler(self, event_type: str, handler: Callable):
        """Set event handler for specific Azure API events."""
        self.event_handlers[event_type] = handler

    async def close_realtime_connection(self):
        """Close the realtime WebSocket connection."""
        try:
            if self.websocket and not self.websocket.closed:
                await self.websocket.close()

            self.is_connected = False
            self.websocket = None

            logger.info("Azure Realtime connection closed")

        except Exception as e:
            logger.error(f"Error closing connection: {str(e)}")

    # Private helper methods

    def _build_websocket_url(self) -> str:
        """Build WebSocket URL for Azure OpenAI Realtime API."""
        base_url = self.settings.azure_openai_endpoint.replace("https://", "wss://")
        return f"{base_url}/openai/realtime?api-version=2024-10-01-preview&deployment={self.settings.azure_openai_deployment}"

    def _get_auth_headers(self) -> Dict[str, str]:
        """Get authentication headers for Azure API."""
        return {
            "api-key": self.settings.azure_openai_api_key,
            "OpenAI-Beta": "realtime=v1"
        }

    async def _send_event(self, event: Dict[str, Any]):
        """Send event to Azure Realtime API."""
        if not self.websocket or self.websocket.closed:
            raise AzureRealtimeError("WebSocket connection is closed")

        try:
            event_id = f"event_{int(time.time() * 1000)}"
            event["event_id"] = event_id

            message = json.dumps(event)
            await self.websocket.send(message)

            logger.debug(f"Sent event: {event['type']}")

        except Exception as e:
            logger.error(f"Failed to send event: {str(e)}")
            raise

    async def _handle_messages(self):
        """Handle incoming messages from Azure Realtime API."""
        try:
            while self.is_connected and self.websocket:
                try:
                    message = await self.websocket.recv()
                    event = json.loads(message)

                    await self._process_event(event)

                except ConnectionClosed:
                    logger.info("Azure Realtime connection closed")
                    self.is_connected = False
                    break
                except WebSocketException as e:
                    logger.error(f"WebSocket error: {str(e)}")
                    self.is_connected = False
                    break
                except json.JSONDecodeError as e:
                    logger.error(f"Invalid JSON from Azure: {str(e)}")
                except Exception as e:
                    logger.error(f"Error handling message: {str(e)}")

        except Exception as e:
            logger.error(f"Error in message handler: {str(e)}")
        finally:
            self.is_connected = False

    async def _process_event(self, event: Dict[str, Any]):
        """Process incoming event from Azure Realtime API."""
        event_type = event.get("type")

        try:
            # Handle specific event types
            if event_type == "session.created":
                self.session_id = event.get("session", {}).get("id")
                logger.info(f"Azure session created: {self.session_id}")

            elif event_type == "conversation.created":
                self.conversation_id = event.get("conversation", {}).get("id")
                logger.info(f"Azure conversation created: {self.conversation_id}")

            elif event_type == "input_audio_buffer.speech_started":
                logger.debug("Speech started")

            elif event_type == "input_audio_buffer.speech_stopped":
                logger.debug("Speech stopped")

            elif event_type == "conversation.item.input_audio_transcription.completed":
                # Handle transcription completion
                transcription = event.get("transcript", "")
                logger.info(f"Transcription completed: {transcription}")

            elif event_type == "response.audio.delta":
                # Handle audio response chunks
                audio_data = event.get("delta", "")
                logger.debug("Received audio delta")

            elif event_type == "response.audio.done":
                logger.info("Audio response completed")

            elif event_type == "response.done":
                logger.info("Response completed")

            elif event_type == "error":
                error_message = event.get("error", {}).get("message", "Unknown error")
                logger.error(f"Azure API error: {error_message}")

            # Call registered event handlers
            if event_type in self.event_handlers:
                await self.event_handlers[event_type](event)

        except Exception as e:
            logger.error(f"Error processing event {event_type}: {str(e)}")

    def _is_circuit_breaker_open(self) -> bool:
        """Check if circuit breaker is open."""
        if not self.circuit_breaker['is_open']:
            return False

        # Check if reset timeout has passed
        if (time.time() - self.circuit_breaker['last_failure_time']) > self.circuit_breaker['reset_timeout']:
            self._reset_circuit_breaker()
            return False

        return True

    def _record_failure(self):
        """Record a failure for circuit breaker."""
        self.circuit_breaker['failure_count'] += 1
        self.circuit_breaker['last_failure_time'] = time.time()

        if self.circuit_breaker['failure_count'] >= self.circuit_breaker['failure_threshold']:
            self.circuit_breaker['is_open'] = True
            logger.warning("Azure Realtime circuit breaker opened due to consecutive failures")

    def _reset_circuit_breaker(self):
        """Reset circuit breaker after successful operation."""
        self.circuit_breaker['failure_count'] = 0
        self.circuit_breaker['is_open'] = False

    async def get_connection_health(self) -> Dict[str, Any]:
        """Get connection health status."""
        return {
            "is_connected": self.is_connected,
            "session_id": self.session_id,
            "conversation_id": self.conversation_id,
            "circuit_breaker_open": self.circuit_breaker['is_open'],
            "failure_count": self.circuit_breaker['failure_count'],
            "websocket_state": str(self.websocket.state) if self.websocket else "disconnected"
        }


# Global client instances
_azure_realtime_clients: Dict[str, AzureRealtimeClient] = {}


async def get_azure_realtime_client(session_id: Optional[str] = None) -> AzureRealtimeClient:
    """Get Azure Realtime API client instance."""
    global _azure_realtime_clients

    # Use session-specific client if provided
    client_key = session_id or "default"

    if client_key not in _azure_realtime_clients:
        _azure_realtime_clients[client_key] = AzureRealtimeClient()

    return _azure_realtime_clients[client_key]


async def cleanup_realtime_client(session_id: str):
    """Cleanup session-specific realtime client."""
    global _azure_realtime_clients

    if session_id in _azure_realtime_clients:
        client = _azure_realtime_clients[session_id]
        await client.close_realtime_connection()
        del _azure_realtime_clients[session_id]