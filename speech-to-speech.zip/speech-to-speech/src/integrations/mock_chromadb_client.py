"""Mock ChromaDB client for development without ChromaDB installation."""
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


class MockCollection:
    """Mock ChromaDB collection."""

    def __init__(self, name: str):
        self.name = name
        self.documents = []
        self.embeddings = []
        self.metadatas = []
        self.ids = []

    def add(self, documents: List[str], embeddings: List[List[float]],
            metadatas: List[Dict], ids: List[str]):
        """Add documents to mock collection."""
        self.documents.extend(documents)
        self.embeddings.extend(embeddings)
        self.metadatas.extend(metadatas)
        self.ids.extend(ids)
        logger.info(f"Added {len(documents)} documents to mock collection {self.name}")

    def query(self, query_embeddings: List[List[float]], n_results: int = 5,
              where: Optional[Dict] = None) -> Dict[str, Any]:
        """Query mock collection - returns empty results."""
        logger.info(f"Querying mock collection {self.name} with {len(query_embeddings)} embeddings")
        return {
            "ids": [[]],
            "distances": [[]],
            "metadatas": [[]],
            "documents": [[]],
            "embeddings": None
        }


class MockChromaClient:
    """Mock ChromaDB client for development."""

    def __init__(self):
        self.collections = {}
        logger.info("Initialized mock ChromaDB client")

    def get_or_create_collection(self, name: str, **kwargs) -> MockCollection:
        """Get or create a mock collection."""
        if name not in self.collections:
            self.collections[name] = MockCollection(name)
            logger.info(f"Created mock collection: {name}")
        return self.collections[name]

    def delete_collection(self, name: str):
        """Delete a mock collection."""
        if name in self.collections:
            del self.collections[name]
            logger.info(f"Deleted mock collection: {name}")

    def list_collections(self) -> List[str]:
        """List all mock collections."""
        return list(self.collections.keys())


class MockVectorSearchService:
    """Mock vector search service that doesn't require ChromaDB."""

    def __init__(self):
        self.client = MockChromaClient()
        self.collection = None
        self.knowledge_base = [
            {
                "content": "This is a mock knowledge base entry about account management.",
                "metadata": {"topic": "account_management", "relevance": 0.9}
            },
            {
                "content": "Mock information about client consultation and best practices.",
                "metadata": {"topic": "consultation", "relevance": 0.8}
            },
            {
                "content": "Sample response about software development project management.",
                "metadata": {"topic": "project_management", "relevance": 0.7}
            }
        ]
        logger.info("Initialized mock vector search service")

    async def initialize(self, collection_name: str = "speech_knowledge"):
        """Initialize mock vector search."""
        self.collection = self.client.get_or_create_collection(collection_name)
        logger.info(f"Mock vector search initialized with collection: {collection_name}")

    async def add_documents(self, documents: List[str], metadata: List[Dict[str, Any]]):
        """Add documents to mock vector store."""
        if not self.collection:
            await self.initialize()

        # Mock embeddings
        embeddings = [[0.1] * 768 for _ in documents]
        ids = [f"doc_{i}_{datetime.now(timezone.utc).timestamp()}" for i in range(len(documents))]

        self.collection.add(documents, embeddings, metadata, ids)
        logger.info(f"Added {len(documents)} documents to mock vector store")

    async def search_similar(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Search for similar documents - returns mock results."""
        logger.info(f"Mock search for: {query[:50]}...")

        # Return mock knowledge base entries
        results = []
        for i, entry in enumerate(self.knowledge_base[:limit]):
            results.append({
                "content": entry["content"],
                "metadata": entry["metadata"],
                "similarity_score": max(0.1, 0.9 - i * 0.1),  # Decreasing relevance
                "source": "mock_knowledge_base"
            })

        logger.info(f"Returning {len(results)} mock search results")
        return results

    async def get_health_status(self) -> Dict[str, Any]:
        """Get mock health status."""
        return {
            "status": "healthy",
            "collection_count": len(self.client.collections),
            "document_count": sum(len(col.documents) for col in self.client.collections.values()),
            "service_type": "mock",
            "last_updated": datetime.now(timezone.utc).isoformat()
        }


# Singleton instance
_mock_vector_service = None


async def get_mock_vector_search_service() -> MockVectorSearchService:
    """Get mock vector search service instance."""
    global _mock_vector_service
    if _mock_vector_service is None:
        _mock_vector_service = MockVectorSearchService()
        await _mock_vector_service.initialize()
    return _mock_vector_service