"""PostgreSQL database integration client with constitutional compliance."""
import asyncio
import json
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from uuid import UUID
import logging
import asyncpg
from asyncpg import Pool

from ..lib.config import get_settings

logger = logging.getLogger(__name__)


class DatabaseError(Exception):
    """Base exception for database errors."""
    pass


class DatabaseClient:
    """
    PostgreSQL database client for persistent storage with constitutional compliance.

    Responsibilities:
    - Store conversation sessions, queries, and transcript records
    - Ensure fast database operations for <800ms latency requirement
    - Implement connection pooling for performance
    - Support privacy compliance with data retention
    - Handle database migrations and schema management
    """

    def __init__(self):
        """Initialize PostgreSQL database client."""
        self.settings = get_settings()
        self.pool: Optional[Pool] = None
        self.max_query_time_ms = 200.0  # Reserve time for other processing

    async def initialize(self):
        """Initialize database connection pool."""
        try:
            # Create connection pool
            self.pool = await asyncpg.create_pool(
                host=self.settings.database_host,
                port=self.settings.database_port,
                user=self.settings.database_user,
                password=self.settings.database_password,
                database=self.settings.database_name,
                min_size=5,
                max_size=20,
                command_timeout=self.max_query_time_ms / 1000,  # Convert to seconds
                server_settings={
                    'application_name': 'speech_to_speech_service'
                }
            )

            # Initialize database schema
            await self._initialize_schema()

            logger.info("Database client initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize database client: {str(e)}")
            raise DatabaseError(f"Database initialization failed: {str(e)}")

    async def _initialize_schema(self):
        """Initialize database schema if not exists."""
        schema_queries = [
            # Conversation sessions table
            """
            CREATE TABLE IF NOT EXISTS conversation_sessions (
                session_id UUID PRIMARY KEY,
                user_id VARCHAR(255) NOT NULL,
                status VARCHAR(50) NOT NULL DEFAULT 'active',
                created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                expires_at TIMESTAMP WITH TIME ZONE,
                completed_at TIMESTAMP WITH TIME ZONE,
                context_data JSONB DEFAULT '{}',
                session_config JSONB DEFAULT '{}',
                performance_metrics JSONB DEFAULT '{}',
                quality_metrics JSONB DEFAULT '{}',
                query_count INTEGER DEFAULT 0,
                error_count INTEGER DEFAULT 0,
                cost_tracking JSONB DEFAULT '{}',
                compliance_flags JSONB DEFAULT '{}',
                optimization_flags JSONB DEFAULT '{}'
            );
            """,

            # Voice queries table
            """
            CREATE TABLE IF NOT EXISTS voice_queries (
                query_id UUID PRIMARY KEY,
                session_id UUID NOT NULL REFERENCES conversation_sessions(session_id),
                user_id VARCHAR(255) NOT NULL,
                status VARCHAR(50) NOT NULL DEFAULT 'received',
                created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                completed_at TIMESTAMP WITH TIME ZONE,
                audio_format VARCHAR(20),
                audio_file_path TEXT,
                transcription TEXT DEFAULT '',
                response_text TEXT DEFAULT '',
                response_audio_url TEXT,
                total_processing_time_ms FLOAT DEFAULT 0,
                audio_metrics JSONB DEFAULT '{}',
                transcription_metrics JSONB DEFAULT '{}',
                response_metrics JSONB DEFAULT '{}',
                cost_breakdown JSONB DEFAULT '{}',
                total_cost_usd FLOAT DEFAULT 0,
                fallback_used BOOLEAN DEFAULT FALSE,
                error_details JSONB,
                metadata JSONB DEFAULT '{}'
            );
            """,

            # Knowledge responses table
            """
            CREATE TABLE IF NOT EXISTS knowledge_responses (
                response_id UUID PRIMARY KEY,
                query_id UUID NOT NULL REFERENCES voice_queries(query_id),
                session_id UUID NOT NULL REFERENCES conversation_sessions(session_id),
                user_id VARCHAR(255) NOT NULL,
                response_text TEXT NOT NULL,
                response_type VARCHAR(100) DEFAULT 'informational',
                retrieval_method VARCHAR(50) DEFAULT 'semantic_search',
                created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                processing_end TIMESTAMP WITH TIME ZONE,
                total_processing_time_ms FLOAT DEFAULT 0,
                knowledge_sources JSONB DEFAULT '[]',
                contextual_factors JSONB DEFAULT '{}',
                quality_metrics JSONB DEFAULT '{}',
                optimization_metrics JSONB DEFAULT '{}',
                total_cost_usd FLOAT DEFAULT 0,
                is_fallback BOOLEAN DEFAULT FALSE,
                fallback_reason TEXT
            );
            """,

            # Audio responses table
            """
            CREATE TABLE IF NOT EXISTS audio_responses (
                response_id UUID PRIMARY KEY,
                query_id UUID NOT NULL REFERENCES voice_queries(query_id),
                knowledge_response_id UUID NOT NULL REFERENCES knowledge_responses(response_id),
                session_id UUID NOT NULL REFERENCES conversation_sessions(session_id),
                user_id VARCHAR(255) NOT NULL,
                text_content TEXT NOT NULL,
                audio_format VARCHAR(20) DEFAULT 'mp3',
                audio_file_path TEXT,
                audio_url TEXT,
                status VARCHAR(50) NOT NULL DEFAULT 'pending',
                created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                generation_completed_at TIMESTAMP WITH TIME ZONE,
                processing_metrics JSONB DEFAULT '{}',
                tts_metrics JSONB DEFAULT '{}',
                optimization_settings JSONB DEFAULT '{}',
                cache_metrics JSONB DEFAULT '{}',
                total_cost_usd FLOAT DEFAULT 0,
                fallback_used BOOLEAN DEFAULT FALSE
            );
            """,

            # Transcript records table
            """
            CREATE TABLE IF NOT EXISTS transcript_records (
                record_id UUID PRIMARY KEY,
                session_id UUID NOT NULL REFERENCES conversation_sessions(session_id),
                query_id UUID REFERENCES voice_queries(query_id),
                user_id VARCHAR(255) NOT NULL,
                record_type VARCHAR(50) NOT NULL,
                content TEXT NOT NULL,
                content_hash VARCHAR(64) NOT NULL,
                timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
                sequence_number INTEGER DEFAULT 0,
                privacy_level VARCHAR(50) DEFAULT 'internal',
                compliance_status VARCHAR(50) DEFAULT 'pending',
                sensitivity_analysis JSONB DEFAULT '{}',
                anonymization_metrics JSONB DEFAULT '{}',
                retention_metrics JSONB NOT NULL,
                access_log JSONB DEFAULT '[]',
                last_accessed_at TIMESTAMP WITH TIME ZONE,
                access_count INTEGER DEFAULT 0,
                transcription_confidence FLOAT DEFAULT 0,
                quality_score FLOAT DEFAULT 0,
                context_data JSONB DEFAULT '{}',
                processing_metadata JSONB DEFAULT '{}'
            );
            """,

            # Indexes for performance
            """
            CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON conversation_sessions(user_id);
            CREATE INDEX IF NOT EXISTS idx_sessions_status ON conversation_sessions(status);
            CREATE INDEX IF NOT EXISTS idx_sessions_created_at ON conversation_sessions(created_at);
            CREATE INDEX IF NOT EXISTS idx_queries_session_id ON voice_queries(session_id);
            CREATE INDEX IF NOT EXISTS idx_queries_user_id ON voice_queries(user_id);
            CREATE INDEX IF NOT EXISTS idx_queries_status ON voice_queries(status);
            CREATE INDEX IF NOT EXISTS idx_transcript_session_id ON transcript_records(session_id);
            CREATE INDEX IF NOT EXISTS idx_transcript_user_id ON transcript_records(user_id);
            CREATE INDEX IF NOT EXISTS idx_transcript_timestamp ON transcript_records(timestamp);
            CREATE INDEX IF NOT EXISTS idx_transcript_retention ON transcript_records((retention_metrics->>'expires_at'));
            """,

            # Function to update updated_at timestamp
            """
            CREATE OR REPLACE FUNCTION update_updated_at_column()
            RETURNS TRIGGER AS $$
            BEGIN
                NEW.updated_at = NOW();
                RETURN NEW;
            END;
            $$ language 'plpgsql';
            """,

            # Triggers for updated_at
            """
            DROP TRIGGER IF EXISTS update_sessions_updated_at ON conversation_sessions;
            CREATE TRIGGER update_sessions_updated_at
                BEFORE UPDATE ON conversation_sessions
                FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
            """,

            """
            DROP TRIGGER IF EXISTS update_queries_updated_at ON voice_queries;
            CREATE TRIGGER update_queries_updated_at
                BEFORE UPDATE ON voice_queries
                FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
            """
        ]

        async with self.pool.acquire() as conn:
            for query in schema_queries:
                await conn.execute(query)

        logger.info("Database schema initialized")

    # Conversation Sessions operations

    async def create_session(self, session_data: Dict[str, Any]) -> bool:
        """Create a new conversation session."""
        try:
            query = """
                INSERT INTO conversation_sessions (
                    session_id, user_id, status, expires_at, context_data,
                    session_config, performance_metrics, quality_metrics,
                    compliance_flags, optimization_flags
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            """

            async with self.pool.acquire() as conn:
                await conn.execute(
                    query,
                    session_data['session_id'],
                    session_data['user_id'],
                    session_data['status'],
                    session_data.get('expires_at'),
                    json.dumps(session_data.get('context_data', {})),
                    json.dumps(session_data.get('session_config', {})),
                    json.dumps(session_data.get('performance_metrics', {})),
                    json.dumps(session_data.get('quality_metrics', {})),
                    json.dumps(session_data.get('compliance_flags', {})),
                    json.dumps(session_data.get('optimization_flags', {}))
                )

            return True

        except Exception as e:
            logger.error(f"Failed to create session: {str(e)}")
            return False

    async def get_session(self, session_id: UUID) -> Optional[Dict[str, Any]]:
        """Get a conversation session by ID."""
        try:
            query = """
                SELECT * FROM conversation_sessions WHERE session_id = $1
            """

            async with self.pool.acquire() as conn:
                row = await conn.fetchrow(query, session_id)

                if row:
                    return dict(row)

            return None

        except Exception as e:
            logger.error(f"Failed to get session {session_id}: {str(e)}")
            return None

    async def update_session(self, session_id: UUID, updates: Dict[str, Any]) -> bool:
        """Update a conversation session."""
        try:
            # Build dynamic update query
            set_clauses = []
            values = []
            param_count = 1

            for key, value in updates.items():
                if key in ['context_data', 'session_config', 'performance_metrics',
                          'quality_metrics', 'compliance_flags', 'optimization_flags', 'cost_tracking']:
                    set_clauses.append(f"{key} = ${param_count}")
                    values.append(json.dumps(value))
                else:
                    set_clauses.append(f"{key} = ${param_count}")
                    values.append(value)
                param_count += 1

            values.append(session_id)

            query = f"""
                UPDATE conversation_sessions
                SET {', '.join(set_clauses)}
                WHERE session_id = ${param_count}
            """

            async with self.pool.acquire() as conn:
                await conn.execute(query, *values)

            return True

        except Exception as e:
            logger.error(f"Failed to update session {session_id}: {str(e)}")
            return False

    # Voice Queries operations

    async def create_voice_query(self, query_data: Dict[str, Any]) -> bool:
        """Create a new voice query."""
        try:
            query = """
                INSERT INTO voice_queries (
                    query_id, session_id, user_id, status, audio_format,
                    audio_file_path, transcription, response_text, response_audio_url,
                    total_processing_time_ms, audio_metrics, transcription_metrics,
                    response_metrics, cost_breakdown, total_cost_usd, fallback_used,
                    metadata
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
            """

            async with self.pool.acquire() as conn:
                await conn.execute(
                    query,
                    query_data['query_id'],
                    query_data['session_id'],
                    query_data['user_id'],
                    query_data['status'],
                    query_data.get('audio_format'),
                    query_data.get('audio_file_path'),
                    query_data.get('transcription', ''),
                    query_data.get('response_text', ''),
                    query_data.get('response_audio_url'),
                    query_data.get('total_processing_time_ms', 0),
                    json.dumps(query_data.get('audio_metrics', {})),
                    json.dumps(query_data.get('transcription_metrics', {})),
                    json.dumps(query_data.get('response_metrics', {})),
                    json.dumps(query_data.get('cost_breakdown', {})),
                    query_data.get('total_cost_usd', 0),
                    query_data.get('fallback_used', False),
                    json.dumps(query_data.get('metadata', {}))
                )

            return True

        except Exception as e:
            logger.error(f"Failed to create voice query: {str(e)}")
            return False

    async def get_session_queries(self, session_id: UUID, limit: int = 100) -> List[Dict[str, Any]]:
        """Get all queries for a session."""
        try:
            query = """
                SELECT * FROM voice_queries
                WHERE session_id = $1
                ORDER BY created_at DESC
                LIMIT $2
            """

            async with self.pool.acquire() as conn:
                rows = await conn.fetch(query, session_id, limit)

            return [dict(row) for row in rows]

        except Exception as e:
            logger.error(f"Failed to get session queries: {str(e)}")
            return []

    # Transcript Records operations

    async def create_transcript_record(self, record_data: Dict[str, Any]) -> bool:
        """Create a new transcript record."""
        try:
            query = """
                INSERT INTO transcript_records (
                    record_id, session_id, query_id, user_id, record_type,
                    content, content_hash, sequence_number, privacy_level,
                    compliance_status, sensitivity_analysis, anonymization_metrics,
                    retention_metrics, transcription_confidence, quality_score,
                    context_data, processing_metadata
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
            """

            async with self.pool.acquire() as conn:
                await conn.execute(
                    query,
                    record_data['record_id'],
                    record_data['session_id'],
                    record_data.get('query_id'),
                    record_data['user_id'],
                    record_data['record_type'],
                    record_data['content'],
                    record_data['content_hash'],
                    record_data.get('sequence_number', 0),
                    record_data.get('privacy_level', 'internal'),
                    record_data.get('compliance_status', 'pending'),
                    json.dumps(record_data.get('sensitivity_analysis', {})),
                    json.dumps(record_data.get('anonymization_metrics', {})),
                    json.dumps(record_data['retention_metrics']),
                    record_data.get('transcription_confidence', 0),
                    record_data.get('quality_score', 0),
                    json.dumps(record_data.get('context_data', {})),
                    json.dumps(record_data.get('processing_metadata', {}))
                )

            return True

        except Exception as e:
            logger.error(f"Failed to create transcript record: {str(e)}")
            return False

    async def get_expired_transcript_records(self) -> List[Dict[str, Any]]:
        """Get expired transcript records for cleanup."""
        try:
            query = """
                SELECT * FROM transcript_records
                WHERE (retention_metrics->>'expires_at')::timestamp < NOW()
                AND (retention_metrics->'compliance_holds') = '[]'
                LIMIT 1000
            """

            async with self.pool.acquire() as conn:
                rows = await conn.fetch(query)

            return [dict(row) for row in rows]

        except Exception as e:
            logger.error(f"Failed to get expired records: {str(e)}")
            return []

    async def delete_transcript_record(self, record_id: UUID) -> bool:
        """Delete a transcript record."""
        try:
            query = "DELETE FROM transcript_records WHERE record_id = $1"

            async with self.pool.acquire() as conn:
                await conn.execute(query, record_id)

            return True

        except Exception as e:
            logger.error(f"Failed to delete record {record_id}: {str(e)}")
            return False

    # Health and maintenance operations

    async def health_check(self) -> Dict[str, Any]:
        """Check database health."""
        try:
            async with self.pool.acquire() as conn:
                # Simple query to test connection
                result = await conn.fetchval("SELECT 1")

                # Get pool stats
                pool_stats = {
                    'total_connections': self.pool.get_size(),
                    'available_connections': self.pool.get_idle_size(),
                    'max_connections': self.pool.get_max_size()
                }

            return {
                'status': 'healthy',
                'connection_test': result == 1,
                'pool_stats': pool_stats,
                'last_check': datetime.now(timezone.utc).isoformat()
            }

        except Exception as e:
            logger.error(f"Database health check failed: {str(e)}")
            return {
                'status': 'unhealthy',
                'error': str(e),
                'last_check': datetime.now(timezone.utc).isoformat()
            }

    async def get_metrics(self) -> Dict[str, Any]:
        """Get database metrics."""
        try:
            metrics = {}

            async with self.pool.acquire() as conn:
                # Count active sessions
                active_sessions = await conn.fetchval(
                    "SELECT COUNT(*) FROM conversation_sessions WHERE status = 'active'"
                )
                metrics['active_sessions'] = active_sessions

                # Count total queries today
                today_queries = await conn.fetchval(
                    "SELECT COUNT(*) FROM voice_queries WHERE created_at >= CURRENT_DATE"
                )
                metrics['queries_today'] = today_queries

                # Count transcript records
                total_transcripts = await conn.fetchval(
                    "SELECT COUNT(*) FROM transcript_records"
                )
                metrics['total_transcript_records'] = total_transcripts

            return metrics

        except Exception as e:
            logger.error(f"Failed to get database metrics: {str(e)}")
            return {}

    async def close(self):
        """Close database connection pool."""
        if self.pool:
            await self.pool.close()


# Global client instance
_database_client = None


async def get_database_client() -> DatabaseClient:
    """Get global database client instance."""
    global _database_client
    if _database_client is None:
        _database_client = DatabaseClient()
        await _database_client.initialize()
    return _database_client