"""Application configuration management."""
from typing import Optional
from pydantic import Field
from pydantic_settings import BaseSettings


class DatabaseSettings(BaseSettings):
    """Database configuration settings."""

    url: str = Field(
        default="postgresql+asyncpg://speechuser:speechpass@localhost:5432/speech_assistant",
        description="Database connection URL"
    )
    pool_size: int = Field(default=10, description="Database connection pool size")
    max_overflow: int = Field(default=20, description="Maximum connection overflow")
    echo: bool = Field(default=False, description="Enable SQL query logging")

    class Config:
        env_prefix = "DATABASE_"


class AzureOpenAISettings(BaseSettings):
    """Azure OpenAI configuration settings."""

    api_key: str = Field(..., description="Azure OpenAI API key")
    endpoint: str = Field(..., description="Azure OpenAI endpoint URL")
    deployment_name: str = Field(..., description="Azure OpenAI deployment name")
    api_version: str = Field(
        default="2024-02-15-preview",
        description="Azure OpenAI API version"
    )
    max_retries: int = Field(default=3, description="Maximum retry attempts")
    timeout_seconds: int = Field(default=30, description="Request timeout in seconds")

    class Config:
        env_prefix = "AZURE_OPENAI_"


class VectorDatabaseSettings(BaseSettings):
    """Vector database configuration settings."""

    host: str = Field(default="localhost", description="ChromaDB host")
    port: int = Field(default=8000, description="ChromaDB port")
    collection_name: str = Field(
        default="speech_knowledge",
        description="ChromaDB collection name"
    )
    similarity_threshold: float = Field(
        default=0.7,
        description="Minimum similarity score for relevant results"
    )

    class Config:
        env_prefix = "CHROMADB_"


class ApplicationSettings(BaseSettings):
    """Main application configuration settings."""

    host: str = Field(default="0.0.0.0", description="Application host")
    port: int = Field(default=8000, description="Application port")
    reload: bool = Field(default=False, description="Enable auto-reload")
    log_level: str = Field(default="INFO", description="Logging level")
    debug: bool = Field(default=False, description="Enable debug mode")
    testing: bool = Field(default=False, description="Enable testing mode")

    class Config:
        env_prefix = "APP_"


class SecuritySettings(BaseSettings):
    """Security configuration settings."""

    jwt_secret_key: str = Field(..., description="JWT secret key")
    jwt_algorithm: str = Field(default="HS256", description="JWT algorithm")
    jwt_access_token_expire_minutes: int = Field(
        default=30,
        description="JWT access token expiration time in minutes"
    )

    class Config:
        env_prefix = "JWT_"


class PerformanceSettings(BaseSettings):
    """Performance configuration settings."""

    max_audio_file_size_mb: int = Field(
        default=10,
        description="Maximum audio file size in MB"
    )
    max_processing_time_ms: int = Field(
        default=800,
        description="Maximum processing time in milliseconds"
    )
    max_concurrent_sessions: int = Field(
        default=100,
        description="Maximum concurrent user sessions"
    )

    class Config:
        env_prefix = "MAX_"


class MonitoringSettings(BaseSettings):
    """Monitoring configuration settings."""

    enable_metrics: bool = Field(default=True, description="Enable metrics collection")
    metrics_port: int = Field(default=9090, description="Metrics endpoint port")
    log_format: str = Field(default="json", description="Log format (json or text)")

    class Config:
        env_prefix = ""


class Settings(BaseSettings):
    """Complete application settings."""

    # Sub-configurations
    app: ApplicationSettings = ApplicationSettings()
    database: DatabaseSettings = DatabaseSettings()
    azure_openai: AzureOpenAISettings = AzureOpenAISettings()
    vector_db: VectorDatabaseSettings = VectorDatabaseSettings()
    security: SecuritySettings = SecuritySettings()
    performance: PerformanceSettings = PerformanceSettings()
    monitoring: MonitoringSettings = MonitoringSettings()

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


# Global settings instance
settings = Settings()


def get_settings() -> Settings:
    """Get application settings instance."""
    return settings