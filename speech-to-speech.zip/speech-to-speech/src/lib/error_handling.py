"""Error handling and logging setup with constitutional compliance."""
import logging
import traceback
from datetime import datetime, timezone
from typing import Dict, Any, Optional

from fastapi import FastAPI, Request, HTTPException, status
from fastapi.exception_handlers import (
    http_exception_handler,
    request_validation_exception_handler,
)
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from .schemas import ErrorResponseSchema, ValidationErrorResponseSchema, ValidationErrorSchema

# Configure logging
logger = logging.getLogger(__name__)


class ConstitutionalViolationError(Exception):
    """Exception for constitutional requirement violations."""

    def __init__(self, message: str, violation_type: str, actual_value: Any, expected_value: Any):
        self.message = message
        self.violation_type = violation_type
        self.actual_value = actual_value
        self.expected_value = expected_value
        super().__init__(self.message)


class GracefulDegradationError(Exception):
    """Exception for graceful degradation scenarios."""

    def __init__(self, message: str, fallback_available: bool, degradation_level: str):
        self.message = message
        self.fallback_available = fallback_available
        self.degradation_level = degradation_level
        super().__init__(self.message)


class CostOptimizationError(Exception):
    """Exception for cost optimization failures."""

    def __init__(self, message: str, current_cost: float, optimization_failed: str):
        self.message = message
        self.current_cost = current_cost
        self.optimization_failed = optimization_failed
        super().__init__(self.message)


def setup_error_handlers(app: FastAPI):
    """Setup comprehensive error handlers for the FastAPI application."""

    @app.exception_handler(ConstitutionalViolationError)
    async def constitutional_violation_handler(request: Request, exc: ConstitutionalViolationError):
        """Handle constitutional requirement violations."""
        logger.error(
            f"Constitutional violation: {exc.violation_type} - {exc.message} "
            f"(expected: {exc.expected_value}, actual: {exc.actual_value})"
        )

        error_response = ErrorResponseSchema(
            error="Constitutional Requirement Violation",
            error_code="CONSTITUTIONAL_VIOLATION",
            timestamp=datetime.now(timezone.utc).isoformat(),
            details={
                "violation_type": exc.violation_type,
                "expected_value": exc.expected_value,
                "actual_value": exc.actual_value,
                "requirement": "All responses must meet constitutional requirements"
            },
            constitutional_impact="High - System not meeting core requirements"
        )

        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content=error_response.dict(),
            headers={
                "X-Constitutional-Violation": exc.violation_type,
                "X-Expected-Value": str(exc.expected_value),
                "X-Actual-Value": str(exc.actual_value)
            }
        )

    @app.exception_handler(GracefulDegradationError)
    async def graceful_degradation_handler(request: Request, exc: GracefulDegradationError):
        """Handle graceful degradation scenarios."""
        logger.warning(
            f"Graceful degradation triggered: {exc.message} "
            f"(fallback available: {exc.fallback_available}, level: {exc.degradation_level})"
        )

        if exc.fallback_available:
            status_code = status.HTTP_206_PARTIAL_CONTENT
            error_type = "Partial Service Degradation"
        else:
            status_code = status.HTTP_503_SERVICE_UNAVAILABLE
            error_type = "Service Degradation"

        error_response = ErrorResponseSchema(
            error=error_type,
            error_code="GRACEFUL_DEGRADATION",
            timestamp=datetime.now(timezone.utc).isoformat(),
            details={
                "degradation_level": exc.degradation_level,
                "fallback_available": exc.fallback_available,
                "expected_behavior": "Graceful degradation with fallback mechanisms"
            },
            constitutional_impact="Low - Graceful degradation maintains service availability"
        )

        return JSONResponse(
            status_code=status_code,
            content=error_response.dict(),
            headers={
                "X-Degradation-Level": exc.degradation_level,
                "X-Fallback-Available": str(exc.fallback_available)
            }
        )

    @app.exception_handler(CostOptimizationError)
    async def cost_optimization_handler(request: Request, exc: CostOptimizationError):
        """Handle cost optimization failures."""
        logger.warning(
            f"Cost optimization issue: {exc.message} "
            f"(current cost: ${exc.current_cost}, failed: {exc.optimization_failed})"
        )

        error_response = ErrorResponseSchema(
            error="Cost Optimization Warning",
            error_code="COST_OPTIMIZATION_ISSUE",
            timestamp=datetime.now(timezone.utc).isoformat(),
            details={
                "current_cost_usd": exc.current_cost,
                "optimization_failed": exc.optimization_failed,
                "recommendation": "Review cost optimization settings"
            },
            constitutional_impact="Medium - Cost optimization not meeting targets"
        )

        return JSONResponse(
            status_code=status.HTTP_200_OK,  # Not a failure, just a warning
            content=error_response.dict(),
            headers={
                "X-Cost-Warning": "true",
                "X-Current-Cost": str(exc.current_cost)
            }
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(request: Request, exc: RequestValidationError):
        """Handle request validation errors with detailed information."""
        logger.warning(f"Validation error for {request.method} {request.url.path}: {exc.errors()}")

        validation_errors = []
        for error in exc.errors():
            field_path = " -> ".join(str(loc) for loc in error["loc"])
            validation_errors.append(
                ValidationErrorSchema(
                    field=field_path,
                    message=error["msg"],
                    value=error.get("input", "N/A")
                )
            )

        error_response = ValidationErrorResponseSchema(
            timestamp=datetime.now(timezone.utc).isoformat(),
            validation_errors=validation_errors
        )

        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content=error_response.dict(),
            headers={"X-Validation-Error": "true"}
        )

    @app.exception_handler(HTTPException)
    async def custom_http_exception_handler(request: Request, exc: HTTPException):
        """Handle HTTP exceptions with constitutional compliance context."""
        logger.warning(f"HTTP {exc.status_code} for {request.method} {request.url.path}: {exc.detail}")

        # Determine constitutional impact
        constitutional_impact = "None"
        if exc.status_code >= 500:
            constitutional_impact = "High - Service availability affected"
        elif exc.status_code == 429:
            constitutional_impact = "Medium - Rate limiting may affect performance"
        elif exc.status_code >= 400:
            constitutional_impact = "Low - Client error, service operational"

        error_response = ErrorResponseSchema(
            error=exc.detail,
            error_code=f"HTTP_{exc.status_code}",
            timestamp=datetime.now(timezone.utc).isoformat(),
            details={
                "status_code": exc.status_code,
                "path": str(request.url.path),
                "method": request.method
            },
            constitutional_impact=constitutional_impact
        )

        return JSONResponse(
            status_code=exc.status_code,
            content=error_response.dict(),
            headers=getattr(exc, "headers", None) or {}
        )

    @app.exception_handler(Exception)
    async def general_exception_handler(request: Request, exc: Exception):
        """Handle unexpected exceptions with comprehensive logging."""
        logger.error(
            f"Unexpected error for {request.method} {request.url.path}: {str(exc)}",
            exc_info=True
        )

        # Get stack trace for debugging
        stack_trace = traceback.format_exc()

        error_response = ErrorResponseSchema(
            error="Internal Server Error",
            error_code="INTERNAL_ERROR",
            timestamp=datetime.now(timezone.utc).isoformat(),
            details={
                "exception_type": type(exc).__name__,
                "path": str(request.url.path),
                "method": request.method,
                # Include stack trace only in debug mode
                "stack_trace": stack_trace if logger.level == logging.DEBUG else None
            },
            constitutional_impact="High - Unexpected error may affect system reliability"
        )

        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=error_response.dict(),
            headers={
                "X-Error-Type": type(exc).__name__,
                "X-Constitutional-Impact": "HIGH"
            }
        )


def log_constitutional_violation(
    violation_type: str,
    expected_value: Any,
    actual_value: Any,
    context: Optional[Dict[str, Any]] = None
):
    """Log constitutional violations for monitoring and alerting."""
    violation_data = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "violation_type": violation_type,
        "expected_value": expected_value,
        "actual_value": actual_value,
        "context": context or {}
    }

    logger.error(f"CONSTITUTIONAL_VIOLATION: {violation_data}")

    # In a production system, this would also:
    # - Send alerts to monitoring systems
    # - Update constitutional compliance metrics
    # - Trigger automated remediation if configured


def log_graceful_degradation(
    degradation_type: str,
    fallback_used: str,
    performance_impact: str,
    context: Optional[Dict[str, Any]] = None
):
    """Log graceful degradation events for monitoring."""
    degradation_data = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "degradation_type": degradation_type,
        "fallback_used": fallback_used,
        "performance_impact": performance_impact,
        "context": context or {}
    }

    logger.warning(f"GRACEFUL_DEGRADATION: {degradation_data}")


def log_cost_optimization_event(
    event_type: str,
    cost_impact: float,
    optimization_applied: str,
    context: Optional[Dict[str, Any]] = None
):
    """Log cost optimization events for tracking."""
    cost_data = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_type": event_type,
        "cost_impact_usd": cost_impact,
        "optimization_applied": optimization_applied,
        "context": context or {}
    }

    logger.info(f"COST_OPTIMIZATION: {cost_data}")


def create_error_context(
    request: Request,
    additional_context: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Create error context for detailed logging."""
    context = {
        "request_id": getattr(request.state, "request_id", "unknown"),
        "user_agent": request.headers.get("user-agent", "unknown"),
        "client_host": request.client.host if request.client else "unknown",
        "path": str(request.url.path),
        "method": request.method,
        "timestamp": datetime.now(timezone.utc).isoformat()
    }

    if additional_context:
        context.update(additional_context)

    return context


def setup_logging_configuration():
    """Setup comprehensive logging configuration."""
    # Configure root logger
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            # In production, add file handlers, structured logging, etc.
        ]
    )

    # Configure specific loggers
    loggers_config = {
        "uvicorn": logging.INFO,
        "uvicorn.access": logging.INFO,
        "fastapi": logging.INFO,
        "src.api": logging.INFO,
        "src.services": logging.INFO,
        "src.integrations": logging.INFO,
        "constitutional_compliance": logging.WARNING,  # For constitutional violations
        "graceful_degradation": logging.WARNING,       # For degradation events
        "cost_optimization": logging.INFO              # For cost tracking
    }

    for logger_name, level in loggers_config.items():
        logger = logging.getLogger(logger_name)
        logger.setLevel(level)

    logger.info("Logging configuration completed")


# Performance monitoring decorator
def monitor_constitutional_compliance(func):
    """Decorator to monitor constitutional compliance of functions."""
    import functools
    import time

    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        start_time = time.time()

        try:
            result = await func(*args, **kwargs)
            execution_time_ms = (time.time() - start_time) * 1000

            # Check constitutional compliance
            if execution_time_ms > 800.0:
                log_constitutional_violation(
                    violation_type="latency_800ms",
                    expected_value=800.0,
                    actual_value=execution_time_ms,
                    context={"function": func.__name__}
                )

            return result

        except Exception as e:
            execution_time_ms = (time.time() - start_time) * 1000
            logger.error(
                f"Function {func.__name__} failed after {execution_time_ms:.1f}ms: {str(e)}"
            )
            raise

    return wrapper


# Initialize logging when module is imported
setup_logging_configuration()