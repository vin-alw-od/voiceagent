"""Pydantic schemas for input validation and API documentation."""
from datetime import datetime
from typing import Dict, Any, Optional, List, Union
from uuid import UUID
from enum import Enum

from pydantic import BaseModel, Field, validator, root_validator


# Enum schemas
class SessionStatusSchema(str, Enum):
    """Session status enumeration."""
    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    EXPIRED = "expired"


class AudioFormatSchema(str, Enum):
    """Audio format enumeration."""
    WAV = "wav"
    MP3 = "mp3"
    FLAC = "flac"
    OGG = "ogg"


class AudioQualitySchema(str, Enum):
    """Audio quality enumeration."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    PREMIUM = "premium"


# Base schemas
class ConstitutionalComplianceSchema(BaseModel):
    """Constitutional compliance tracking schema."""
    latency_requirement_met: bool = Field(..., description="Whether <800ms latency requirement is met")
    actual_latency_ms: float = Field(..., ge=0, description="Actual processing latency in milliseconds")
    cost_optimized: bool = Field(default=True, description="Whether cost optimization is active")
    privacy_compliant: bool = Field(default=True, description="Whether privacy requirements are met")
    graceful_degradation_active: bool = Field(default=True, description="Whether graceful degradation is enabled")

    @validator('actual_latency_ms')
    def validate_latency(cls, v):
        """Validate latency is reasonable."""
        if v > 10000:  # 10 seconds is unreasonable
            raise ValueError("Latency cannot exceed 10 seconds")
        return v


class PerformanceMetricsSchema(BaseModel):
    """Performance metrics schema."""
    total_queries: int = Field(default=0, ge=0, description="Total number of queries processed")
    average_latency_ms: float = Field(default=0.0, ge=0.0, description="Average processing latency")
    successful_queries: int = Field(default=0, ge=0, description="Number of successful queries")
    failed_queries: int = Field(default=0, ge=0, description="Number of failed queries")
    total_cost_usd: float = Field(default=0.0, ge=0.0, description="Total cost in USD")

    @validator('failed_queries')
    def validate_failure_rate(cls, v, values):
        """Validate failure rate is reasonable."""
        if 'total_queries' in values and values['total_queries'] > 0:
            failure_rate = v / values['total_queries']
            if failure_rate > 0.5:  # More than 50% failure rate
                raise ValueError("Failure rate is too high")
        return v


class QualityMetricsSchema(BaseModel):
    """Audio and response quality metrics schema."""
    audio_quality_score: float = Field(default=0.0, ge=0.0, le=1.0, description="Audio quality score")
    transcription_confidence: float = Field(default=0.0, ge=0.0, le=1.0, description="Transcription confidence")
    response_relevance: float = Field(default=0.0, ge=0.0, le=1.0, description="Response relevance score")
    overall_quality: float = Field(default=0.0, ge=0.0, le=1.0, description="Overall quality score")


class CostSummarySchema(BaseModel):
    """Cost tracking and optimization schema."""
    total_cost_usd: float = Field(default=0.0, ge=0.0, description="Total cost in USD")
    cost_per_query: float = Field(default=0.0, ge=0.0, description="Average cost per query")
    cost_breakdown: Dict[str, float] = Field(default_factory=dict, description="Cost breakdown by service")
    optimization_savings_usd: float = Field(default=0.0, ge=0.0, description="Savings from optimization")
    efficiency_score: float = Field(default=1.0, ge=0.0, le=1.0, description="Cost efficiency score")


# Request schemas
class ConversationStartRequestSchema(BaseModel):
    """Schema for starting a conversation."""
    user_id: str = Field(..., min_length=1, max_length=255, description="User identifier")
    context: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Initial conversation context")
    session_config: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Session configuration")

    @validator('user_id')
    def validate_user_id(cls, v):
        """Validate user ID format."""
        if not v.strip():
            raise ValueError("User ID cannot be empty")
        # Additional validation could include checking against user database
        return v.strip()

    @validator('context')
    def validate_context(cls, v):
        """Validate context data."""
        if v is None:
            return {}

        # Ensure context doesn't contain sensitive data patterns
        sensitive_keys = ['password', 'secret', 'token', 'key']
        for key in v.keys():
            if any(sensitive in key.lower() for sensitive in sensitive_keys):
                raise ValueError(f"Context cannot contain sensitive key: {key}")

        return v


class VoiceQueryRequestSchema(BaseModel):
    """Schema for voice query form data."""
    audio_format: AudioFormatSchema = Field(..., description="Audio format")
    quality_preference: Optional[AudioQualitySchema] = Field(default=AudioQualitySchema.MEDIUM, description="Audio quality preference")
    enable_optimization: bool = Field(default=True, description="Enable cost optimization")


class ConversationUpdateRequestSchema(BaseModel):
    """Schema for updating a conversation."""
    status: Optional[SessionStatusSchema] = Field(default=None, description="New session status")
    context_data: Optional[Dict[str, Any]] = Field(default=None, description="Context data updates")
    session_config: Optional[Dict[str, Any]] = Field(default=None, description="Session configuration updates")
    completion_reason: Optional[str] = Field(default=None, max_length=500, description="Reason for completion")

    @root_validator
    def validate_completion(cls, values):
        """Validate completion requirements."""
        status = values.get('status')
        completion_reason = values.get('completion_reason')

        if status == SessionStatusSchema.COMPLETED and not completion_reason:
            raise ValueError("Completion reason is required when marking session as completed")

        return values


# Response schemas
class ConversationStartResponseSchema(BaseModel):
    """Schema for conversation start response."""
    session_id: str = Field(..., description="Unique session identifier")
    user_id: str = Field(..., description="User identifier")
    status: SessionStatusSchema = Field(..., description="Session status")
    created_at: str = Field(..., description="Session creation timestamp")
    expires_at: Optional[str] = Field(default=None, description="Session expiration timestamp")
    context_data: Dict[str, Any] = Field(default_factory=dict, description="Session context")
    constitutional_compliance: ConstitutionalComplianceSchema = Field(..., description="Constitutional compliance status")


class VoiceQueryResponseSchema(BaseModel):
    """Schema for voice query response."""
    query_id: str = Field(..., description="Unique query identifier")
    session_id: str = Field(..., description="Session identifier")
    transcription: str = Field(..., description="Transcribed text from audio")
    response_text: str = Field(..., description="Generated response text")
    audio_url: Optional[str] = Field(default=None, description="URL to generated audio response")
    processing_time_ms: float = Field(..., ge=0, description="Total processing time")
    confidence_score: float = Field(..., ge=0.0, le=1.0, description="Transcription confidence")
    audio_quality_score: float = Field(..., ge=0.0, le=1.0, description="Audio quality score")
    status: str = Field(..., description="Query processing status")
    constitutional_compliant: bool = Field(..., description="Whether query meets constitutional requirements")
    cost_summary: CostSummarySchema = Field(..., description="Cost information")
    quality_assessment: QualityMetricsSchema = Field(..., description="Quality metrics")


class ConversationResponseSchema(BaseModel):
    """Schema for conversation details response."""
    session_id: str = Field(..., description="Session identifier")
    user_id: str = Field(..., description="User identifier")
    status: SessionStatusSchema = Field(..., description="Session status")
    created_at: str = Field(..., description="Creation timestamp")
    updated_at: str = Field(..., description="Last update timestamp")
    expires_at: Optional[str] = Field(default=None, description="Expiration timestamp")
    context_data: Dict[str, Any] = Field(default_factory=dict, description="Session context")
    performance_metrics: PerformanceMetricsSchema = Field(..., description="Performance metrics")
    quality_metrics: QualityMetricsSchema = Field(..., description="Quality metrics")
    query_count: int = Field(default=0, ge=0, description="Number of queries in session")
    constitutional_compliance: ConstitutionalComplianceSchema = Field(..., description="Constitutional compliance")
    cost_summary: CostSummarySchema = Field(..., description="Cost summary")


# Health and metrics schemas
class ServiceHealthSchema(BaseModel):
    """Schema for individual service health."""
    status: str = Field(..., description="Service health status")
    response_time_ms: float = Field(..., ge=0, description="Service response time")
    details: Dict[str, Any] = Field(default_factory=dict, description="Additional health details")


class HealthResponseSchema(BaseModel):
    """Schema for comprehensive health check response."""
    status: str = Field(..., description="Overall system health status")
    timestamp: str = Field(..., description="Health check timestamp")
    services: Dict[str, ServiceHealthSchema] = Field(..., description="Individual service health")
    constitutional_compliance: Dict[str, Any] = Field(..., description="Constitutional compliance status")
    overall_healthy: bool = Field(..., description="Whether system is healthy overall")


class MetricsResponseSchema(BaseModel):
    """Schema for system metrics response."""
    timestamp: str = Field(..., description="Metrics collection timestamp")
    current_sessions: int = Field(..., ge=0, description="Number of active sessions")
    total_queries_today: int = Field(..., ge=0, description="Total queries processed today")
    average_latency_ms: float = Field(..., ge=0, description="Average response latency")
    p95_latency_ms: float = Field(..., ge=0, description="95th percentile latency")
    error_rate_percent: float = Field(..., ge=0.0, le=100.0, description="Error rate percentage")
    azure_api_health: str = Field(..., description="Azure API health status")
    constitutional_compliance: Dict[str, Any] = Field(..., description="Constitutional compliance metrics")
    cost_metrics: CostSummarySchema = Field(..., description="Cost optimization metrics")
    performance_trends: Dict[str, Any] = Field(default_factory=dict, description="Performance trend analysis")


class ConstitutionalComplianceMetricsSchema(BaseModel):
    """Schema for detailed constitutional compliance metrics."""
    timestamp: str = Field(..., description="Metrics timestamp")
    total_sessions_analyzed: int = Field(..., ge=0, description="Number of sessions analyzed")
    latency_compliance: Dict[str, Any] = Field(..., description="Latency requirement compliance")
    cost_optimization: Dict[str, Any] = Field(..., description="Cost optimization metrics")
    privacy_compliance: Dict[str, Any] = Field(..., description="Privacy compliance metrics")
    graceful_degradation: Dict[str, Any] = Field(..., description="Graceful degradation metrics")
    overall_constitutional_compliance: Dict[str, Any] = Field(..., description="Overall compliance summary")


# Error response schemas
class ErrorResponseSchema(BaseModel):
    """Schema for error responses."""
    error: str = Field(..., description="Error message")
    error_code: str = Field(..., description="Error code")
    timestamp: str = Field(..., description="Error timestamp")
    details: Optional[Dict[str, Any]] = Field(default=None, description="Additional error details")
    constitutional_impact: Optional[str] = Field(default=None, description="Impact on constitutional compliance")


class ValidationErrorSchema(BaseModel):
    """Schema for validation errors."""
    field: str = Field(..., description="Field with validation error")
    message: str = Field(..., description="Validation error message")
    value: Any = Field(..., description="Invalid value")


class ValidationErrorResponseSchema(BaseModel):
    """Schema for validation error responses."""
    error: str = Field(default="Validation Error", description="Error type")
    timestamp: str = Field(..., description="Error timestamp")
    validation_errors: List[ValidationErrorSchema] = Field(..., description="List of validation errors")


# Streaming and real-time schemas
class ConversationUpdateEventSchema(BaseModel):
    """Schema for real-time conversation updates."""
    session_id: str = Field(..., description="Session identifier")
    status: SessionStatusSchema = Field(..., description="Current session status")
    query_count: int = Field(..., ge=0, description="Current query count")
    performance_metrics: PerformanceMetricsSchema = Field(..., description="Current performance metrics")
    constitutional_compliance: ConstitutionalComplianceSchema = Field(..., description="Current compliance status")
    timestamp: str = Field(..., description="Update timestamp")


# Utility functions for schema validation
def validate_uuid(uuid_string: str) -> bool:
    """Validate UUID format."""
    try:
        UUID(uuid_string)
        return True
    except ValueError:
        return False


def validate_timestamp(timestamp_string: str) -> bool:
    """Validate ISO timestamp format."""
    try:
        datetime.fromisoformat(timestamp_string.replace('Z', '+00:00'))
        return True
    except ValueError:
        return False


def sanitize_user_input(input_string: str) -> str:
    """Sanitize user input for security."""
    if not input_string:
        return ""

    # Remove potentially dangerous characters
    dangerous_chars = ['<', '>', '&', '"', "'", '\n', '\r', '\t']
    sanitized = input_string

    for char in dangerous_chars:
        sanitized = sanitized.replace(char, '')

    return sanitized.strip()


def validate_cost_amount(amount: float) -> bool:
    """Validate cost amount is reasonable."""
    # Costs should be positive and not exceed reasonable limits
    return 0.0 <= amount <= 1000.0  # Max $1000 per operation


def validate_latency(latency_ms: float) -> bool:
    """Validate latency measurement."""
    # Latency should be positive and not exceed reasonable limits
    return 0.0 <= latency_ms <= 60000.0  # Max 60 seconds