# Speech-to-Speech Voice Assistant - Local Setup

## Quick Start

1. **Setup the environment:**
   ```cmd
   setup.bat
   ```

2. **Configure your settings:**
   - Copy `.env.example` to `.env`
   - Add your Azure OpenAI credentials

3. **Start the application:**
   ```cmd
   start.bat
   ```

4. **Test the application:**
   - API: http://localhost:8000
   - Test Client: http://localhost:8000/static/realtime_client.html
   - Documentation: http://localhost:8000/docs

## Detailed Setup Instructions

### Prerequisites
- Python 3.8 or higher
- Azure OpenAI account with Realtime API access

### 1. Environment Setup

Run the setup script:
```cmd
setup.bat
```

This will:
- Create a virtual environment in `venv/`
- Install all dependencies from `requirements.txt`
- Set up the development environment

### 2. Configuration

Copy the example environment file:
```cmd
copy .env.example .env
```

Edit `.env` and configure:

#### Required Settings:
```env
# Azure OpenAI Configuration
AZURE_OPENAI_API_KEY=your_azure_openai_api_key_here
AZURE_OPENAI_ENDPOINT=https://your-resource-name.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT_NAME=your_deployment_name
AZURE_OPENAI_API_VERSION=2024-02-15-preview
```

#### Optional Settings (defaults work for local dev):
```env
# Application Configuration
APP_HOST=localhost
APP_PORT=8000
DEBUG=true

# Database (SQLite for local development)
DATABASE_URL=sqlite+aiosqlite:///./speech_assistant.db

# ChromaDB (local file storage)
CHROMADB_PERSIST_DIRECTORY=./chroma_data
```

### 3. Starting the Application

Run the start script:
```cmd
start.bat
```

Or manually:
```cmd
venv\Scripts\activate.bat
python -m src.api.main
```

### 4. Testing the Real-Time Voice Assistant

1. **Open the test client:** http://localhost:8000/static/realtime_client.html

2. **Connect to a session:**
   - Enter a session ID or leave empty for auto-generation
   - Click "Connect"

3. **Start voice conversation:**
   - Click "Start Recording"
   - Speak into your microphone
   - Watch real-time transcription
   - Hear the AI response

4. **Monitor compliance:**
   - View latency metrics (<800ms requirement)
   - Track constitutional compliance violations
   - Monitor system performance

## Architecture Overview

### Components:
- **FastAPI Application**: REST and WebSocket APIs
- **Azure OpenAI Integration**: Real-time speech processing
- **SQLite Database**: Session and transcript storage
- **ChromaDB**: Vector knowledge retrieval
- **Web Client**: Interactive voice interface

### Constitutional Compliance:
- **<800ms Latency**: All operations monitored
- **Cost Optimization**: Caching and quality adjustments
- **Privacy**: 30-day data retention
- **Graceful Degradation**: Circuit breakers and fallbacks

## API Endpoints

### REST Endpoints:
- `GET /` - API information
- `GET /health` - Health check
- `GET /metrics` - System metrics
- `POST /conversation/start` - Start new session
- `POST /conversation/{session_id}/query` - Voice query

### WebSocket Endpoints:
- `WS /realtime/conversation/{session_id}` - Real-time voice chat
- `WS /realtime/conversation/{session_id}/stream` - Metrics stream

### Static Files:
- `/static/realtime_client.html` - Test client interface

## Troubleshooting

### Common Issues:

1. **"Module not found" errors:**
   ```cmd
   venv\Scripts\activate.bat
   pip install -r requirements.txt
   ```

2. **Azure OpenAI connection errors:**
   - Verify your API key in `.env`
   - Check endpoint URL format
   - Ensure deployment name is correct

3. **WebSocket connection fails:**
   - Check if port 8000 is available
   - Verify firewall settings
   - Try using localhost instead of 0.0.0.0

4. **Audio recording doesn't work:**
   - Use HTTPS or localhost (required for microphone access)
   - Check browser permissions for microphone
   - Ensure microphone is connected

### Development Mode:

For development with auto-reload:
```cmd
venv\Scripts\activate.bat
uvicorn src.api.main:app --reload --host localhost --port 8000
```

### Logs and Debugging:

Application logs are displayed in the console. For more detailed debugging:
1. Set `DEBUG=true` in `.env`
2. Check the debug panel in the web client
3. Monitor browser console for client-side issues

## Next Steps

1. **Production Deployment**: Use PostgreSQL and external ChromaDB
2. **Security**: Update JWT secret and implement authentication
3. **Monitoring**: Set up Prometheus metrics collection
4. **Scaling**: Configure load balancing and session clustering