// <copyright file="TestTTSRequest.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.Data
{
    /// <summary>
    /// Request model for testing text-to-speech.
    /// </summary>
    public class TestTTSRequest
    {
        /// <summary>
        /// Gets or sets the text to synthesize.
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// Gets or sets the voice to use (optional).
        /// </summary>
        public string Voice { get; set; }

        /// <summary>
        /// Gets or sets the language code (optional, defaults to "en-US").
        /// </summary>
        public string Language { get; set; } = "en-US";
    }
}