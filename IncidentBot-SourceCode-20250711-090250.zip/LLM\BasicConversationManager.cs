// <copyright file="BasicConversationManager.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Basic implementation of conversation manager for LLM agent integration.
    /// This can be extended to integrate with your LangChain agent.
    /// </summary>
    public class BasicConversationManager : IConversationManager
    {
        private readonly ILogger<BasicConversationManager> logger;
        private readonly ConcurrentDictionary<string, ConversationContext> conversations;
        private readonly Dictionary<string, string> responses;

        /// <summary>
        /// Initializes a new instance of the <see cref="BasicConversationManager"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        public BasicConversationManager(ILogger<BasicConversationManager> logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.conversations = new ConcurrentDictionary<string, ConversationContext>();
            this.responses = this.InitializeResponses();
        }

        /// <inheritdoc/>
        public void InitializeConversation(string callId)
        {
            if (string.IsNullOrEmpty(callId))
            {
                throw new ArgumentException("Call ID cannot be null or empty", nameof(callId));
            }

            var context = new ConversationContext
            {
                CallId = callId,
                StartTime = DateTime.UtcNow,
                MessageHistory = new List<ConversationMessage>(),
            };

            this.conversations.TryAdd(callId, context);
            this.logger.LogInformation("Initialized conversation for call {CallId}", callId);
        }

        /// <inheritdoc/>
        public async Task<string> ProcessUserInputAsync(string userText, string callId)
        {
            if (string.IsNullOrEmpty(userText))
            {
                return "I didn't catch that. Could you please repeat?";
            }

            if (string.IsNullOrEmpty(callId))
            {
                throw new ArgumentException("Call ID cannot be null or empty", nameof(callId));
            }

            if (!this.conversations.TryGetValue(callId, out var context))
            {
                this.logger.LogWarning("No conversation context found for call {CallId}", callId);
                return "I'm sorry, but I'm having trouble with this conversation. Please try again.";
            }

            // Add user message to history
            context.MessageHistory.Add(new ConversationMessage
            {
                Timestamp = DateTime.UtcNow,
                Sender = "User",
                Content = userText,
            });

            this.logger.LogInformation("Processing user input for call {CallId}: {UserText}", callId, userText);

            // TODO: Replace this with your LangChain agent integration
            var response = await this.GenerateResponseAsync(userText, context).ConfigureAwait(false);

            // Add bot response to history
            context.MessageHistory.Add(new ConversationMessage
            {
                Timestamp = DateTime.UtcNow,
                Sender = "Bot",
                Content = response,
            });

            this.logger.LogInformation("Generated response for call {CallId}: {Response}", callId, response);

            return response;
        }

        /// <inheritdoc/>
        public void EndConversation(string callId)
        {
            if (string.IsNullOrEmpty(callId))
            {
                throw new ArgumentException("Call ID cannot be null or empty", nameof(callId));
            }

            if (this.conversations.TryRemove(callId, out var context))
            {
                this.logger.LogInformation(
                    "Ended conversation for call {CallId}. Duration: {Duration}",
                    callId,
                    DateTime.UtcNow - context.StartTime);
            }
        }

        /// <summary>
        /// Get conversation statistics for a call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <returns>Conversation statistics or null if not found.</returns>
        public ConversationStats GetConversationStats(string callId)
        {
            if (this.conversations.TryGetValue(callId, out var context))
            {
                return new ConversationStats
                {
                    CallId = callId,
                    StartTime = context.StartTime,
                    Duration = DateTime.UtcNow - context.StartTime,
                    MessageCount = context.MessageHistory.Count,
                    UserMessageCount = context.MessageHistory.Count(m => m.Sender == "User"),
                    BotMessageCount = context.MessageHistory.Count(m => m.Sender == "Bot"),
                };
            }

            return null;
        }

        /// <summary>
        /// Generate a response based on user input and conversation context.
        /// This is where you would integrate your LangChain agent.
        /// </summary>
        /// <param name="userText">The user's input text.</param>
        /// <param name="context">The conversation context.</param>
        /// <returns>The generated response.</returns>
        private async Task<string> GenerateResponseAsync(string userText, ConversationContext context)
        {
            // Simulate async processing
            await Task.Delay(100).ConfigureAwait(false);

            var lowerText = userText.ToLowerInvariant();

            // Basic response logic - replace this with your LangChain agent
            if (lowerText.Contains("hello") || lowerText.Contains("hi") || lowerText.Contains("hey"))
            {
                return "Hello! I'm your AI assistant. How can I help you today?";
            }
            else if (lowerText.Contains("how are you"))
            {
                return "I'm doing well, thank you for asking! How can I assist you?";
            }
            else if (lowerText.Contains("bye") || lowerText.Contains("goodbye"))
            {
                return "Goodbye! It was nice talking to you. Have a great day!";
            }
            else if (lowerText.Contains("help"))
            {
                return "I'm here to help! You can ask me questions, and I'll do my best to assist you. What would you like to know?";
            }
            else if (lowerText.Contains("thank"))
            {
                return "You're welcome! Is there anything else I can help you with?";
            }
            else if (lowerText.Contains("name"))
            {
                return "I'm an AI assistant created to help you. What's your name?";
            }
            else if (lowerText.Contains("weather"))
            {
                return "I'm sorry, I don't have access to weather information right now. Is there something else I can help you with?";
            }
            else if (lowerText.Contains("time"))
            {
                return $"The current time is {DateTime.Now:HH:mm}.";
            }
            else
            {
                // Default response for unrecognized input
                return "That's interesting! Could you tell me more about that?";
            }
        }

        /// <summary>
        /// Initialize basic response patterns.
        /// </summary>
        /// <returns>Dictionary of response patterns.</returns>
        private Dictionary<string, string> InitializeResponses()
        {
            return new Dictionary<string, string>
            {
                { "hello", "Hello! I'm your AI assistant. How can I help you today?" },
                { "hi", "Hi there! How can I assist you?" },
                { "help", "I'm here to help! What would you like to know?" },
                { "bye", "Goodbye! Have a great day!" },
            };
        }
    }
}