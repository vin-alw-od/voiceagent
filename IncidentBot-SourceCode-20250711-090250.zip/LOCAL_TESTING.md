# Local Testing Guide for TeamsAudioStreamService

## 🚀 Quick Start for Local Testing

### Prerequisites
- .NET Framework 4.7.1
- Visual Studio 2017 or later
- Azure Bot Service (for full functionality)
- Azure Speech Services (for TTS/STT)

### 1. Build and Run Locally

```powershell
# Build the project
dotnet build

# Run the application
dotnet run
```

The application will start on `http://localhost:9442`

### 2. Test Endpoints

#### Health Check
```bash
curl http://localhost:9442/health
```

#### LLM Agent Endpoints

**Get Available Voices:**
```bash
curl http://localhost:9442/LLMAgent/voices
```

**Test Text-to-Speech:**
```bash
curl -X POST http://localhost:9442/LLMAgent/testTTS \
  -H "Content-Type: application/json" \
  -d '{
    "Text": "Hello, this is a test of the Teams Audio Stream Service",
    "Voice": "en-US-JennyNeural",
    "Language": "en-US"
  }'
```

**Test Audio Stream:**
```bash
curl -X POST http://localhost:9442/LLMAgent/testAudioStream \
  -H "Content-Type: application/json" \
  -d '{
    "CallId": "test-call-123",
    "AudioData": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
  }'
```

**Join Call with LLM Agent:**
```bash
curl -X POST http://localhost:9442/LLMAgent/joinCall \
  -H "Content-Type: application/json" \
  -d '{
    "JoinURL": "https://teams.microsoft.com/l/meetup-join/...",
    "MeetingId": "meeting-id",
    "TenantId": "your-tenant-id"
  }'
```

### 3. Configuration for Local Testing

Update `appsettings.json` with your credentials:

```json
{
  "Bot": {
    "AppId": "YOUR_BOT_APP_ID",
    "AppSecret": "YOUR_BOT_APP_SECRET",
    "BotBaseUrl": "http://localhost:9442"
  },
  "AzureSpeech": {
    "SubscriptionKey": "YOUR_SPEECH_KEY",
    "Region": "YOUR_SPEECH_REGION"
  }
}
```

### 4. Testing TeamsAudioStreamService Features

#### Audio Stream Subscription
The `TeamsAudioStreamService` provides:
- ✅ Real-time audio subscription management
- ✅ Event-driven call state handling
- ✅ Automatic cleanup and resource management
- ✅ Thread-safe operations

#### Test Audio Data Processing
```csharp
// Simulate audio data for testing
var audioStreamService = new TeamsAudioStreamService(logger);
audioStreamService.SetCallReference("test-call", call);
audioStreamService.SubscribeToAudioStreamAsync("test-call");

// Simulate incoming audio data
var testAudioData = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
audioStreamService.SimulateAudioData("test-call", testAudioData);
```

### 5. Troubleshooting

#### Application Not Starting
- Check if port 9442 is available
- Ensure .NET Framework 4.7.1 is installed
- Check Windows Event Logs for errors

#### Endpoints Not Responding
- Verify the application is running: `netstat -an | findstr :9442`
- Check if running as Windows Service vs Console App
- Ensure proper configuration in `appsettings.json`

#### Azure Services Issues
- Verify Azure Bot Service credentials
- Check Azure Speech Services subscription
- Ensure proper permissions are configured

### 6. Next Steps for Full Testing

1. **Configure Azure Bot Service:**
   - Create bot in Azure Portal
   - Enable Teams and Skype channels
   - Configure calling webhook: `http://localhost:9442/callback/calling`

2. **Set up Azure Speech Services:**
   - Create Speech Service in Azure
   - Get subscription key and region
   - Update `appsettings.json`

3. **Test with Real Teams Calls:**
   - Join a Teams meeting
   - Test audio streaming functionality
   - Verify speech-to-text and text-to-speech

### 7. Development Tips

- Use Visual Studio debugging for step-through testing
- Check application logs for detailed error information
- Use Fiddler or Postman for API testing
- Monitor Azure Application Insights for cloud-side issues

## 🎯 Expected Results

When working correctly, you should see:
- ✅ Health endpoint returns 200 OK
- ✅ Voices endpoint returns available Azure Speech voices
- ✅ TTS endpoint generates audio data
- ✅ Audio Stream endpoint processes simulated audio
- ✅ Join Call endpoint successfully joins Teams meetings

## 🔧 Advanced Testing

For advanced testing scenarios, consider:
- Load testing with multiple concurrent calls
- Testing error conditions and edge cases
- Performance monitoring and optimization
- Integration testing with other services 