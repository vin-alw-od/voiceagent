# Voice Response Troubleshooting Guide

## 🎯 **Issue: Bot Not Responding to Voice Commands**

Your bot joins Teams meetings and plays audio, but doesn't respond when you say "Hello" or other voice commands.

## 🔍 **Root Cause Analysis**

The issue is likely in one of these areas:

### 1. **Teams Audio Subscription Not Working**
- The bot isn't receiving real audio data from Teams
- Audio subscription setup is incomplete
- Microsoft Graph Communications SDK audio events not firing

### 2. **Speech-to-Text Service Issues**
- Azure Speech Services not configured properly
- Audio data not being processed correctly
- Transcription events not being raised

### 3. **LLM Processing Issues**
- Conversation manager not processing transcribed text
- Response generation failing
- TTS service not working

## 🛠️ **Immediate Fixes Applied**

### ✅ **Fixed Teams Audio Subscription**
- Added proper `SubscribeToMediaAsync()` call
- Implemented real Teams audio event handling
- Added `OnAudioDataReceived` event subscription

### ✅ **Improved TTS Integration**
- Enhanced welcome message with TTS
- Improved response playback with TTS
- Added fallback mechanisms

### ✅ **Better Error Handling**
- Added comprehensive logging
- Implemented graceful fallbacks
- Enhanced error reporting

## 🧪 **Testing Steps**

### **Step 1: Run Diagnostic Script**
```powershell
.\diagnose-voice-issue.ps1 -AzureUrl "https://your-bot.azurewebsites.net" -CallId "your-call-id"
```

### **Step 2: Check Azure Application Insights**
1. Go to Azure Portal → Application Insights
2. Check for these log entries:
   - "Setting up Teams audio stream subscription"
   - "Received audio data from Teams"
   - "Received transcription"
   - "LLM Response"

### **Step 3: Test Individual Components**

#### **Test TTS Service**
```powershell
$ttsRequest = @{
    Text = "Hello, this is a test"
    Voice = "en-US-JennyNeural"
    Language = "en-US"
} | ConvertTo-Json

Invoke-WebRequest -Uri "https://your-bot.azurewebsites.net/LLMAgent/testTTS" -Method POST -Body $ttsRequest -ContentType "application/json"
```

#### **Test Audio Stream**
```powershell
$audioRequest = @{
    CallId = "your-call-id"
    AudioData = @(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
} | ConvertTo-Json

Invoke-WebRequest -Uri "https://your-bot.azurewebsites.net/LLMAgent/testAudioStream" -Method POST -Body $audioRequest -ContentType "application/json"
```

#### **Test LLM Processing**
```powershell
$messageRequest = @{
    Message = "Hello, can you hear me?"
} | ConvertTo-Json

Invoke-WebRequest -Uri "https://your-bot.azurewebsites.net/LLMAgent/processMessage" -Method POST -Body $messageRequest -ContentType "application/json"
```

## 🔧 **Manual Verification Steps**

### **1. Check Teams Meeting**
- [ ] Bot appears in participants list
- [ ] Bot shows as "In meeting"
- [ ] Bot plays welcome message
- [ ] Bot microphone is not muted

### **2. Check Audio Permissions**
- [ ] Teams meeting allows bot audio
- [ ] Bot has microphone permissions
- [ ] No audio restrictions in meeting

### **3. Check Azure Configuration**
- [ ] Azure Speech Services key is valid
- [ ] Region matches configuration
- [ ] Service is not rate-limited

### **4. Check Bot Framework**
- [ ] Bot is registered correctly
- [ ] Webhook URL is accessible
- [ ] Permissions are granted

## 🚨 **Common Issues and Solutions**

### **Issue: No Audio Data Received**
**Symptoms:**
- No "Received audio data" logs
- Audio subscription shows as inactive

**Solutions:**
1. Check Teams meeting audio permissions
2. Verify bot has microphone access
3. Ensure call is in "Established" state
4. Check Microsoft Graph permissions

### **Issue: TTS Not Working**
**Symptoms:**
- Bot doesn't speak responses
- TTS test endpoint fails

**Solutions:**
1. Verify Azure Speech Services key
2. Check region configuration
3. Ensure service is not rate-limited
4. Check network connectivity

### **Issue: Transcription Not Working**
**Symptoms:**
- No "Received transcription" logs
- Speech not being converted to text

**Solutions:**
1. Check Azure Speech Services configuration
2. Verify audio format compatibility
3. Ensure real-time transcription is enabled
4. Check language settings

### **Issue: LLM Not Processing**
**Symptoms:**
- No "LLM Response" logs
- Bot doesn't respond to text messages

**Solutions:**
1. Check conversation manager configuration
2. Verify LLM service connectivity
3. Check conversation initialization
4. Review error logs

## 📊 **Monitoring and Logging**

### **Key Log Entries to Monitor**
```
✅ "Setting up Teams audio stream subscription for call: {CallId}"
✅ "Successfully subscribed to Teams audio stream for call: {CallId}"
✅ "Received audio data from Teams for call: {CallId}, Size: {Size} bytes"
✅ "Received transcription for call {CallId}: {Text}"
✅ "LLM Response: {Response}"
✅ "Generated TTS audio: {Size} bytes"
```

### **Error Logs to Watch For**
```
❌ "Failed to subscribe to Teams audio stream"
❌ "Error handling Teams audio data"
❌ "Failed to process audio data through speech-to-text service"
❌ "TTS service returned null or empty audio data"
❌ "Failed to play response"
```

## 🎯 **Next Steps**

### **Immediate Actions**
1. **Deploy the updated code** to Azure
2. **Run the diagnostic script** to check current status
3. **Monitor Application Insights** for real-time logs
4. **Test with a simple voice command** like "Hello"

### **If Still Not Working**
1. **Check Azure Application Insights** for detailed error logs
2. **Verify Teams meeting permissions** and audio settings
3. **Test individual components** using the test endpoints
4. **Review Microsoft Graph permissions** for audio access

### **Long-term Improvements**
1. **Implement dynamic audio playback** from TTS data
2. **Add audio quality monitoring**
3. **Implement retry mechanisms** for failed operations
4. **Add comprehensive health checks**

## 📞 **Getting Help**

If the issue persists after following these steps:

1. **Collect logs** from Azure Application Insights
2. **Run diagnostic script** and share results
3. **Check Teams meeting settings** and permissions
4. **Verify Azure Speech Services** configuration
5. **Review Microsoft Graph permissions** for audio access

The most common issue is that Teams audio subscription isn't working properly, which the recent fixes should resolve. 