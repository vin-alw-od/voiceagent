# Test script for local TeamsAudioStreamService testing
Write-Host "Testing IncidentBot TeamsAudioStreamService locally..." -ForegroundColor Green

$baseUrl = "http://localhost:9442"

# Test 1: Health endpoint
Write-Host "`n1. Testing Health Endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$baseUrl/health" -Method GET -UseBasicParsing -TimeoutSec 10
    Write-Host "✅ Health endpoint: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "❌ Health endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: LLM Agent Voices endpoint
Write-Host "`n2. Testing LLM Agent Voices Endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$baseUrl/LLMAgent/voices" -Method GET -UseBasicParsing -TimeoutSec 10
    Write-Host "✅ Voices endpoint: $($response.StatusCode)" -ForegroundColor Green
    $voices = $response.Content | ConvertFrom-Json
    Write-Host "   Available voices: $($voices.VoiceCount)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Voices endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test TTS functionality
Write-Host "`n3. Testing Text-to-Speech..." -ForegroundColor Yellow
$ttsRequest = @{
    Text = "Hello, this is a test of the Teams Audio Stream Service"
    Voice = "en-US-JennyNeural"
    Language = "en-US"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$baseUrl/LLMAgent/testTTS" -Method POST -Body $ttsRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 10
    Write-Host "✅ TTS endpoint: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Audio data size: $($result.AudioDataSize) bytes" -ForegroundColor Cyan
} catch {
    Write-Host "❌ TTS endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Test Audio Stream functionality
Write-Host "`n4. Testing Audio Stream Service..." -ForegroundColor Yellow
$audioRequest = @{
    CallId = "test-call-123"
    AudioData = @(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$baseUrl/LLMAgent/testAudioStream" -Method POST -Body $audioRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 10
    Write-Host "✅ Audio Stream endpoint: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Audio data processed: $($result.AudioDataSize) bytes" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Audio Stream endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Local testing completed!" -ForegroundColor Green
Write-Host "`nNext steps:" -ForegroundColor Cyan
Write-Host "1. Configure your Azure Bot Service with the local URL: $baseUrl" -ForegroundColor White
Write-Host "2. Update appsettings.json with your bot credentials" -ForegroundColor White
Write-Host "3. Test with actual Teams calls using the /LLMAgent/joinCall endpoint" -ForegroundColor White 