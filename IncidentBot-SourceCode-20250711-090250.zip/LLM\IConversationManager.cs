// <copyright file="IConversationManager.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System.Threading.Tasks;

    /// <summary>
    /// Interface for managing LLM agent conversations.
    /// </summary>
    public interface IConversationManager
    {
        /// <summary>
        /// Initialize a new conversation for a call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        void InitializeConversation(string callId);

        /// <summary>
        /// Process user input and generate a response using the LLM agent.
        /// </summary>
        /// <param name="userText">The user's input text.</param>
        /// <param name="callId">The call identifier.</param>
        /// <returns>The LLM agent's response.</returns>
        Task<string> ProcessUserInputAsync(string userText, string callId);

        /// <summary>
        /// End a conversation and cleanup resources.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        void EndConversation(string callId);
    }
}