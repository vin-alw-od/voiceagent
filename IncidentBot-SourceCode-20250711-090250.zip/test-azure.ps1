# Test script for Azure-deployed TeamsAudioStreamService
param(
    [Parameter(Mandatory=$true)]
    [string]$AzureUrl
)

Write-Host "Testing TeamsAudioStreamService on Azure: $AzureUrl" -ForegroundColor Green

# Test 1: Health endpoint
Write-Host "`n1. Testing Health Endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/health" -Method GET -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ Health endpoint: $($response.StatusCode)" -ForegroundColor Green
    Write-Host "   Response: $($response.Content)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Health endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: LLM Agent Voices endpoint
Write-Host "`n2. Testing LLM Agent Voices Endpoint..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/voices" -Method GET -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ Voices endpoint: $($response.StatusCode)" -ForegroundColor Green
    $voices = $response.Content | ConvertFrom-Json
    Write-Host "   Available voices: $($voices.VoiceCount)" -ForegroundColor Cyan
    Write-Host "   Sample voices: $($voices.Voices[0..2] -join ', ')" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Voices endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test TTS functionality
Write-Host "`n3. Testing Text-to-Speech..." -ForegroundColor Yellow
$ttsRequest = @{
    Text = "Hello, this is a test of the Teams Audio Stream Service deployed on Azure"
    Voice = "en-US-JennyNeural"
    Language = "en-US"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/testTTS" -Method POST -Body $ttsRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ TTS endpoint: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Audio data size: $($result.AudioDataSize) bytes" -ForegroundColor Cyan
    Write-Host "   Status: $($result.Status)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ TTS endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Test Audio Stream functionality
Write-Host "`n4. Testing Audio Stream Service..." -ForegroundColor Yellow
$audioRequest = @{
    CallId = "test-call-azure-123"
    AudioData = @(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/testAudioStream" -Method POST -Body $audioRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ Audio Stream endpoint: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Audio data processed: $($result.AudioDataSize) bytes" -ForegroundColor Cyan
    Write-Host "   Status: $($result.Status)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Audio Stream endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Test Audio Subscription Info
Write-Host "`n5. Testing Audio Subscription Info..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/audioSubscription/test-call-azure-123" -Method GET -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ Audio Subscription endpoint: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Call ID: $($result.CallId)" -ForegroundColor Cyan
    Write-Host "   Is Active: $($result.IsActive)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Audio Subscription endpoint failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Azure testing completed!" -ForegroundColor Green
Write-Host "`nNext steps for full Teams integration:" -ForegroundColor Cyan
Write-Host "1. Configure Azure Bot Service with webhook: $AzureUrl/callback/calling" -ForegroundColor White
Write-Host "2. Test with real Teams calls using /LLMAgent/joinCall endpoint" -ForegroundColor White
Write-Host "3. Monitor Azure Application Insights for performance" -ForegroundColor White 