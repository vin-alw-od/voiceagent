// <copyright file="TestAudioStreamRequest.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.Data
{
    /// <summary>
    /// Request model for testing audio streaming.
    /// </summary>
    public class TestAudioStreamRequest
    {
        /// <summary>
        /// Gets or sets the call identifier.
        /// </summary>
        public string CallId { get; set; }

        /// <summary>
        /// Gets or sets the audio data to simulate.
        /// </summary>
        public byte[] AudioData { get; set; }
    }
}