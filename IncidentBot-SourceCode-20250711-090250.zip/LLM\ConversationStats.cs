// <copyright file="ConversationStats.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System;

    /// <summary>
    /// Represents conversation statistics.
    /// </summary>
    public class ConversationStats
    {
        /// <summary>
        /// Gets or sets the call identifier.
        /// </summary>
        public string CallId { get; set; }

        /// <summary>
        /// Gets or sets the start time.
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// Gets or sets the duration.
        /// </summary>
        public TimeSpan Duration { get; set; }

        /// <summary>
        /// Gets or sets the total message count.
        /// </summary>
        public int MessageCount { get; set; }

        /// <summary>
        /// Gets or sets the user message count.
        /// </summary>
        public int UserMessageCount { get; set; }

        /// <summary>
        /// Gets or sets the bot message count.
        /// </summary>
        public int BotMessageCount { get; set; }
    }
}