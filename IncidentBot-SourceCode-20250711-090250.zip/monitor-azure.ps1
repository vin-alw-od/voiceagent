# Monitor Azure Application Insights for TeamsAudioStreamService
param(
    [Parameter(Mandatory=$true)]
    [string]$AppInsightsConnectionString,
    [Parameter(Mandatory=$false)]
    [int]$Minutes = 30
)

Write-Host "Monitoring TeamsAudioStreamService in Azure Application Insights" -ForegroundColor Green
Write-Host "Time range: Last $Minutes minutes" -ForegroundColor Cyan

# You can use Azure CLI or REST API to query Application Insights
# This is a simplified version - you'll need to implement the actual queries

Write-Host "`n📊 Key Metrics to Monitor:" -ForegroundColor Yellow
Write-Host "1. Request Rate (requests/minute)" -ForegroundColor White
Write-Host "2. Response Time (avg, p95, p99)" -ForegroundColor White
Write-Host "3. Error Rate (%)" -ForegroundColor White
Write-Host "4. Audio Stream Events" -ForegroundColor White
Write-Host "5. Teams Call Events" -ForegroundColor White

Write-Host "`n🔍 Custom Queries to Run:" -ForegroundColor Yellow

# Query 1: Audio Stream Events
Write-Host "`nQuery 1: Audio Stream Events" -ForegroundColor Cyan
Write-Host "customEvents" -ForegroundColor Gray
Write-Host "| where name contains 'AudioStream'" -ForegroundColor Gray
Write-Host "| where timestamp > ago($Minutes m)" -ForegroundColor Gray
Write-Host "| summarize count() by name" -ForegroundColor Gray

# Query 2: Teams Call Events
Write-Host "`nQuery 2: Teams Call Events" -ForegroundColor Cyan
Write-Host "customEvents" -ForegroundColor Gray
Write-Host "| where name contains 'Call'" -ForegroundColor Gray
Write-Host "| where timestamp > ago($Minutes m)" -ForegroundColor Gray
Write-Host "| summarize count() by name" -ForegroundColor Gray

# Query 3: Performance Metrics
Write-Host "`nQuery 3: Performance Metrics" -ForegroundColor Cyan
Write-Host "requests" -ForegroundColor Gray
Write-Host "| where timestamp > ago($Minutes m)" -ForegroundColor Gray
Write-Host "| summarize avg(duration), percentile(duration, 95), percentile(duration, 99)" -ForegroundColor Gray

# Query 4: Error Analysis
Write-Host "`nQuery 4: Error Analysis" -ForegroundColor Cyan
Write-Host "exceptions" -ForegroundColor Gray
Write-Host "| where timestamp > ago($Minutes m)" -ForegroundColor Gray
Write-Host "| summarize count() by type" -ForegroundColor Gray

Write-Host "`n📈 How to Access Application Insights:" -ForegroundColor Yellow
Write-Host "1. Go to Azure Portal" -ForegroundColor White
Write-Host "2. Navigate to your Application Insights resource" -ForegroundColor White
Write-Host "3. Use 'Logs (Analytics)' to run these queries" -ForegroundColor White
Write-Host "4. Set up alerts for critical metrics" -ForegroundColor White

Write-Host "`n🚨 Recommended Alerts:" -ForegroundColor Yellow
Write-Host "• Error rate > 5%" -ForegroundColor White
Write-Host "• Response time > 5 seconds" -ForegroundColor White
Write-Host "• Audio stream failures" -ForegroundColor White
Write-Host "• Teams call join failures" -ForegroundColor White 