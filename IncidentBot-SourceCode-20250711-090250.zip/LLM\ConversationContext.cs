// <copyright file="ConversationContext.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Represents a conversation context for a call.
    /// </summary>
    public class ConversationContext
    {
        /// <summary>
        /// Gets or sets the call identifier.
        /// </summary>
        public string CallId { get; set; }

        /// <summary>
        /// Gets or sets the conversation start time.
        /// </summary>
        public DateTime StartTime { get; set; }

        /// <summary>
        /// Gets or sets the message history.
        /// </summary>
        public List<ConversationMessage> MessageHistory { get; set; }
    }
}