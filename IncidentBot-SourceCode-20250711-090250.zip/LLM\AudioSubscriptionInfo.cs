// <copyright file="AudioSubscriptionInfo.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System;
    using Microsoft.Graph.Communications.Calls;

    /// <summary>
    /// Information about an audio subscription for a call.
    /// </summary>
    public class AudioSubscriptionInfo
    {
        /// <summary>
        /// Gets or sets the call identifier.
        /// </summary>
        public string CallId { get; set; }

        /// <summary>
        /// Gets or sets the call reference.
        /// </summary>
        public ICall Call { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the subscription is active.
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Gets or sets the subscription start time.
        /// </summary>
        public DateTime SubscriptionStartTime { get; set; }

        /// <summary>
        /// Gets or sets the subscription end time.
        /// </summary>
        public DateTime? SubscriptionEndTime { get; set; }

        /// <summary>
        /// Gets the duration of the subscription.
        /// </summary>
        public TimeSpan Duration => this.SubscriptionEndTime.HasValue
            ? this.SubscriptionEndTime.Value - this.SubscriptionStartTime
            : DateTime.UtcNow - this.SubscriptionStartTime;
    }
}