# Azure Testing Checklist for TeamsAudioStreamService

## 🚀 **Pre-Testing Setup**

### ✅ **Azure Configuration**
- [ ] Azure App Service is running
- [ ] Application Insights is enabled
- [ ] Azure Speech Services is configured
- [ ] Bot Framework is registered
- [ ] Microsoft Graph permissions are set
- [ ] SSL certificate is valid
- [ ] Environment variables are configured

### ✅ **Teams Configuration**
- [ ] Bot is registered in Teams
- [ ] Webhook URL is configured: `https://your-bot.azurewebsites.net/callback/calling`
- [ ] Bot permissions are granted
- [ ] Meeting join permissions are enabled

## 🧪 **Basic Endpoint Testing**

### ✅ **Health Check**
```powershell
.\test-azure.ps1 -AzureUrl "https://your-bot.azurewebsites.net"
```

**Expected Results:**
- [ ] Health endpoint returns 200 OK
- [ ] Service status shows "Healthy"
- [ ] Response time < 2 seconds

### ✅ **LLM Agent Endpoints**
- [ ] `/LLMAgent/voices` - Returns available voices
- [ ] `/LLMAgent/testTTS` - Text-to-speech works
- [ ] `/LLMAgent/testAudioStream` - Audio processing works
- [ ] `/LLMAgent/audioSubscription/{callId}` - Subscription info

## 🎯 **Teams Integration Testing**

### ✅ **Join Teams Meeting**
```powershell
.\test-teams-integration.ps1 -AzureUrl "https://your-bot.azurewebsites.net" -TeamsMeetingUrl "https://teams.microsoft.com/l/meetup-join/..." -TenantId "your-tenant-id"
```

**Expected Results:**
- [ ] Bot successfully joins meeting
- [ ] Call ID is returned
- [ ] Audio subscription is active
- [ ] Bot appears in Teams meeting

### ✅ **Audio Streaming**
- [ ] Real-time audio capture works
- [ ] Audio processing is responsive
- [ ] No audio lag or delays
- [ ] Audio quality is acceptable

### ✅ **Voice Commands**
- [ ] Bot responds to voice commands
- [ ] Speech-to-text accuracy is good
- [ ] Bot speaks clearly
- [ ] Conversation flow is natural

## 📊 **Performance Testing**

### ✅ **Load Testing**
- [ ] Multiple concurrent calls
- [ ] Audio stream stability
- [ ] Memory usage is stable
- [ ] CPU usage is reasonable

### ✅ **Latency Testing**
- [ ] Audio processing latency < 500ms
- [ ] TTS response time < 2 seconds
- [ ] Call join time < 10 seconds
- [ ] Overall responsiveness is good

## 🔍 **Monitoring & Logging**

### ✅ **Application Insights**
```powershell
.\monitor-azure.ps1 -AppInsightsConnectionString "your-connection-string" -Minutes 30
```

**Check These Metrics:**
- [ ] Request rate is stable
- [ ] Error rate < 5%
- [ ] Response times are acceptable
- [ ] Custom events are logged

### ✅ **Log Analysis**
- [ ] Audio stream events are logged
- [ ] Teams call events are tracked
- [ ] Error details are captured
- [ ] Performance metrics are recorded

## 🚨 **Error Handling**

### ✅ **Network Issues**
- [ ] Handles connection timeouts
- [ ] Reconnects automatically
- [ ] Graceful degradation
- [ ] Error messages are clear

### ✅ **Teams API Issues**
- [ ] Handles meeting join failures
- [ ] Manages call disconnections
- [ ] Retries failed operations
- [ ] Logs detailed error info

## 🔧 **Troubleshooting Common Issues**

### ❌ **Bot doesn't join meeting**
**Check:**
- [ ] Bot permissions in Teams
- [ ] Webhook URL configuration
- [ ] Azure Bot Service settings
- [ ] Network connectivity

### ❌ **Audio not working**
**Check:**
- [ ] Azure Speech Services configuration
- [ ] Audio subscription status
- [ ] Teams audio permissions
- [ ] Codec compatibility

### ❌ **High latency**
**Check:**
- [ ] Azure region proximity
- [ ] Network bandwidth
- [ ] Audio processing settings
- [ ] Resource allocation

### ❌ **Authentication errors**
**Check:**
- [ ] Bot Framework credentials
- [ ] Microsoft Graph permissions
- [ ] Token expiration
- [ ] Tenant configuration

## 📈 **Success Criteria**

### ✅ **Functional Success**
- [ ] Bot joins Teams meetings successfully
- [ ] Real-time audio streaming works
- [ ] Voice commands are processed
- [ ] TTS responses are clear
- [ ] Error handling is robust

### ✅ **Performance Success**
- [ ] Response times < 2 seconds
- [ ] Audio latency < 500ms
- [ ] 99% uptime
- [ ] Error rate < 5%

### ✅ **Integration Success**
- [ ] Seamless Teams integration
- [ ] Stable audio connections
- [ ] Proper event handling
- [ ] Comprehensive logging

## 🎉 **Next Steps After Testing**

1. **Production Deployment**
   - [ ] Configure production environment
   - [ ] Set up monitoring alerts
   - [ ] Implement backup strategies
   - [ ] Document procedures

2. **User Training**
   - [ ] Create user documentation
   - [ ] Train support team
   - [ ] Set up feedback channels
   - [ ] Monitor user adoption

3. **Maintenance Plan**
   - [ ] Regular performance reviews
   - [ ] Update dependencies
   - [ ] Monitor Azure costs
   - [ ] Plan scaling strategies 