# AudioSocket Diagnostic Script
# This script helps you check if AudioSocket is working in your IncidentBot

param(
    [string]$BotUrl = "https://localhost:9442",
    [string]$CallId = ""
)

Write-Host "🎯 AudioSocket Diagnostic Tool" -ForegroundColor Green
Write-Host "================================" -ForegroundColor Green

# 1. Check if bot is running
Write-Host "`n1. Checking if bot is running..." -ForegroundColor Yellow
try {
    $healthResponse = Invoke-WebRequest -Uri "$BotUrl/health" -Method GET -UseBasicParsing -TimeoutSec 10
    if ($healthResponse.StatusCode -eq 200) {
        Write-Host "✅ Bot is running and healthy" -ForegroundColor Green
    } else {
        Write-Host "❌ Bot is running but health check failed" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ Bot is not running or not accessible at $BotUrl" -ForegroundColor Red
    Write-Host "   Make sure to run: dotnet run" -ForegroundColor Yellow
    exit 1
}

# 2. Test TTS functionality
Write-Host "`n2. Testing Text-to-Speech..." -ForegroundColor Yellow
try {
    $ttsRequest = @{
        text = "AudioSocket test message"
        voice = "en-US-JennyNeural"
        language = "en-US"
    } | ConvertTo-Json

    $ttsResponse = Invoke-WebRequest -Uri "$BotUrl/LLMAgent/testTTS" -Method POST -Body $ttsRequest -ContentType "application/json" -UseBasicParsing
    if ($ttsResponse.StatusCode -eq 200) {
        Write-Host "✅ TTS service is working" -ForegroundColor Green
        $ttsResult = $ttsResponse.Content | ConvertFrom-Json
        Write-Host "   Audio data size: $($ttsResult.audioData.Length) bytes" -ForegroundColor Cyan
    } else {
        Write-Host "❌ TTS service failed" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ TTS service error: $($_.Exception.Message)" -ForegroundColor Red
}

# 3. Test message processing
Write-Host "`n3. Testing message processing..." -ForegroundColor Yellow
try {
    $messageRequest = @{
        message = "Hello, this is a test message for AudioSocket"
    } | ConvertTo-Json

    $messageResponse = Invoke-WebRequest -Uri "$BotUrl/LLMAgent/processMessage" -Method POST -Body $messageRequest -ContentType "application/json" -UseBasicParsing
    if ($messageResponse.StatusCode -eq 200) {
        Write-Host "✅ Message processing is working" -ForegroundColor Green
        $messageResult = $messageResponse.Content | ConvertFrom-Json
        Write-Host "   Response: $($messageResult.response)" -ForegroundColor Cyan
    } else {
        Write-Host "❌ Message processing failed" -ForegroundColor Red
    }
} catch {
    Write-Host "❌ Message processing error: $($_.Exception.Message)" -ForegroundColor Red
}

# 4. Check AudioSocket status (if call ID provided)
if ($CallId) {
    Write-Host "`n4. Checking AudioSocket status for call $CallId..." -ForegroundColor Yellow
    try {
        $audioResponse = Invoke-WebRequest -Uri "$BotUrl/LLMAgent/audioSubscription/$CallId" -Method GET -UseBasicParsing
        if ($audioResponse.StatusCode -eq 200) {
            Write-Host "✅ Audio subscription info retrieved" -ForegroundColor Green
            $audioResult = $audioResponse.Content | ConvertFrom-Json
            Write-Host "   Is Active: $($audioResult.isActive)" -ForegroundColor Cyan
            Write-Host "   Subscription Time: $($audioResult.subscriptionStartTime)" -ForegroundColor Cyan
        } else {
            Write-Host "❌ Audio subscription check failed" -ForegroundColor Red
        }
    } catch {
        Write-Host "❌ Audio subscription error: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# 5. Log analysis instructions
Write-Host "`n5. How to check AudioSocket in logs:" -ForegroundColor Yellow
Write-Host "   Look for these log messages:" -ForegroundColor White
Write-Host "   ✅ 'AudioSocket found, setting up real-time audio processing'" -ForegroundColor Green
Write-Host "   ✅ 'AudioSocket initialized successfully with real-time audio processing'" -ForegroundColor Green
Write-Host "   ✅ 'AudioSocket mode set to ReceiveAndSend'" -ForegroundColor Green
Write-Host "   ✅ 'Received audio frame, processing for speech recognition'" -ForegroundColor Green
Write-Host "   ❌ 'AudioSocket property not found - falling back to simulated audio'" -ForegroundColor Red
Write-Host "   ❌ 'OnAudioMediaFrameReceived event not found - falling back to simulated audio'" -ForegroundColor Red

# 6. Manual testing instructions
Write-Host "`n6. Manual Testing Steps:" -ForegroundColor Yellow
Write-Host "   1. Join a Teams meeting using: POST $BotUrl/LLMAgent/joinCall" -ForegroundColor White
Write-Host "   2. Speak in the meeting and check if bot responds" -ForegroundColor White
Write-Host "   3. Monitor logs for AudioSocket messages" -ForegroundColor White
Write-Host "   4. If bot doesn't respond to voice, it's using fallback mode" -ForegroundColor White

Write-Host "`n🎯 Summary:" -ForegroundColor Green
Write-Host "   - If you see 'AudioSocket initialized successfully' in logs, it's working" -ForegroundColor White
Write-Host "   - If you see 'falling back to simulated audio', AudioSocket is not available" -ForegroundColor White
Write-Host "   - The bot will still function in fallback mode, but with simulated audio" -ForegroundColor White

Write-Host "`n📝 Next Steps:" -ForegroundColor Yellow
Write-Host "   1. Join a Teams meeting and test voice interaction" -ForegroundColor White
Write-Host "   2. Check application logs for AudioSocket messages" -ForegroundColor White
Write-Host "   3. If AudioSocket doesn't work, the bot will use fallback mechanisms" -ForegroundColor White 