// <copyright file="ITextToSpeechService.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System.Threading.Tasks;

    /// <summary>
    /// Interface for text-to-speech conversion services.
    /// </summary>
    public interface ITextToSpeechService
    {
        /// <summary>
        /// Synthesize text to speech audio.
        /// </summary>
        /// <param name="text">The text to synthesize.</param>
        /// <param name="voice">The voice to use (optional).</param>
        /// <param name="language">The language code (optional, defaults to "en-US").</param>
        /// <returns>The synthesized audio data.</returns>
        Task<byte[]> SynthesizeSpeechAsync(string text, string voice = null, string language = "en-US");

        /// <summary>
        /// Get available voices for the service.
        /// </summary>
        /// <param name="language">Filter by language code (optional).</param>
        /// <returns>Array of available voice names.</returns>
        Task<string[]> GetAvailableVoicesAsync(string language = null);
    }
}