# Diagnostic script for Teams bot voice response issues
param(
    [Parameter(Mandatory=$true)]
    [string]$AzureUrl,
    [Parameter(Mandatory=$true)]
    [string]$CallId
)

Write-Host "🔍 Diagnosing Voice Response Issues for Teams Bot" -ForegroundColor Green
Write-Host "Azure URL: $AzureUrl" -ForegroundColor Cyan
Write-Host "Call ID: $CallId" -ForegroundColor Cyan

# Test 1: Check Audio Subscription Status
Write-Host "`n1. Checking Audio Subscription Status..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/audioSubscription/$CallId" -Method GET -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ Audio Subscription: $($response.StatusCode)" -ForegroundColor Green
    $subscription = $response.Content | ConvertFrom-Json
    Write-Host "   Is Active: $($subscription.IsActive)" -ForegroundColor Cyan
    Write-Host "   Duration: $($subscription.Duration)" -ForegroundColor Cyan
    Write-Host "   Start Time: $($subscription.SubscriptionStartTime)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Audio Subscription check failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 2: Test TTS Service
Write-Host "`n2. Testing Text-to-Speech Service..." -ForegroundColor Yellow
$ttsRequest = @{
    Text = "Hello, this is a test of the text-to-speech service. Can you hear me?"
    Voice = "en-US-JennyNeural"
    Language = "en-US"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/testTTS" -Method POST -Body $ttsRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ TTS Service: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Audio Data Size: $($result.AudioDataSize) bytes" -ForegroundColor Cyan
    Write-Host "   Status: $($result.Status)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ TTS Service failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 3: Test Audio Stream Processing
Write-Host "`n3. Testing Audio Stream Processing..." -ForegroundColor Yellow
$audioRequest = @{
    CallId = $CallId
    AudioData = @(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20)
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/testAudioStream" -Method POST -Body $audioRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ Audio Stream Processing: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Audio Data Processed: $($result.AudioDataSize) bytes" -ForegroundColor Cyan
    Write-Host "   Status: $($result.Status)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Audio Stream Processing failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 4: Test LLM Message Processing
Write-Host "`n4. Testing LLM Message Processing..." -ForegroundColor Yellow
$messageRequest = @{
    Message = "Hello, can you hear me?"
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/processMessage" -Method POST -Body $messageRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ LLM Message Processing: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Response: $($result.Response)" -ForegroundColor Cyan
    Write-Host "   Status: $($result.Status)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ LLM Message Processing failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test 5: Check Health Status
Write-Host "`n5. Checking Overall Health..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/health" -Method GET -UseBasicParsing -TimeoutSec 30
    Write-Host "✅ Health Check: $($response.StatusCode)" -ForegroundColor Green
    Write-Host "   Response: $($response.Content)" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Health Check failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🔧 Troubleshooting Steps:" -ForegroundColor Yellow
Write-Host "1. Check Azure Application Insights logs for errors" -ForegroundColor White
Write-Host "2. Verify Azure Speech Services configuration" -ForegroundColor White
Write-Host "3. Check Teams meeting audio permissions" -ForegroundColor White
Write-Host "4. Ensure bot has proper Microsoft Graph permissions" -ForegroundColor White
Write-Host "5. Verify call is in 'Established' state" -ForegroundColor White

Write-Host "`n📋 Common Issues and Solutions:" -ForegroundColor Yellow
Write-Host "• No audio subscription: Bot may not have joined call properly" -ForegroundColor White
Write-Host "• TTS failures: Check Azure Speech Services key and region" -ForegroundColor White
Write-Host "• Audio stream issues: Verify Teams audio permissions" -ForegroundColor White
Write-Host "• LLM processing errors: Check conversation manager configuration" -ForegroundColor White

Write-Host "`n🎯 Next Steps:" -ForegroundColor Yellow
Write-Host "1. Check Azure Application Insights for detailed error logs" -ForegroundColor White
Write-Host "2. Verify the bot is actually receiving audio from Teams" -ForegroundColor White
Write-Host "3. Test with a simple voice command like 'Hello'" -ForegroundColor White
Write-Host "4. Check if the bot responds to text messages in the meeting" -ForegroundColor White 