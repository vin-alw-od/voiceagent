# Test Teams Integration with Azure-deployed TeamsAudioStreamService
param(
    [Parameter(Mandatory=$true)]
    [string]$AzureUrl,
    [Parameter(Mandatory=$true)]
    [string]$TeamsMeetingUrl,
    [Parameter(Mandatory=$true)]
    [string]$TenantId
)

Write-Host "Testing Teams Integration with TeamsAudioStreamService" -ForegroundColor Green
Write-Host "Azure URL: $AzureUrl" -ForegroundColor Cyan
Write-Host "Teams Meeting: $TeamsMeetingUrl" -ForegroundColor Cyan

# Test 1: Join Teams Meeting with LLM Agent
Write-Host "`n1. Joining Teams Meeting with LLM Agent..." -ForegroundColor Yellow
$joinCallRequest = @{
    JoinURL = $TeamsMeetingUrl
    MeetingId = "test-meeting-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
    TenantId = $TenantId
} | ConvertTo-Json

try {
    $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/joinCall" -Method POST -Body $joinCallRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 60
    Write-Host "✅ Join Call successful: $($response.StatusCode)" -ForegroundColor Green
    $result = $response.Content | ConvertFrom-Json
    Write-Host "   Call ID: $($result.CallId)" -ForegroundColor Cyan
    Write-Host "   Status: $($result.Status)" -ForegroundColor Cyan
    
    $callId = $result.CallId
    
    # Test 2: Process LLM Message
    Write-Host "`n2. Testing LLM Message Processing..." -ForegroundColor Yellow
    $messageRequest = @{
        Message = "Hello, I am the Teams Audio Stream Service bot. I can help you with this meeting."
    } | ConvertTo-Json
    
    try {
        $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/processMessage" -Method POST -Body $messageRequest -ContentType "application/json" -UseBasicParsing -TimeoutSec 30
        Write-Host "✅ LLM Message processed: $($response.StatusCode)" -ForegroundColor Green
    } catch {
        Write-Host "❌ LLM Message processing failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    
    # Test 3: Check Audio Subscription Status
    Write-Host "`n3. Checking Audio Subscription Status..." -ForegroundColor Yellow
    try {
        $response = Invoke-WebRequest -Uri "$AzureUrl/LLMAgent/audioSubscription/$callId" -Method GET -UseBasicParsing -TimeoutSec 30
        Write-Host "✅ Audio Subscription check: $($response.StatusCode)" -ForegroundColor Green
        $subscription = $response.Content | ConvertFrom-Json
        Write-Host "   Is Active: $($subscription.IsActive)" -ForegroundColor Cyan
        Write-Host "   Duration: $($subscription.Duration)" -ForegroundColor Cyan
    } catch {
        Write-Host "❌ Audio Subscription check failed: $($_.Exception.Message)" -ForegroundColor Red
    }
    
} catch {
    Write-Host "❌ Join Call failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n🎉 Teams Integration testing completed!" -ForegroundColor Green
Write-Host "`nWhat to expect:" -ForegroundColor Cyan
Write-Host "1. Bot should join the Teams meeting" -ForegroundColor White
Write-Host "2. Audio streaming should be active" -ForegroundColor White
Write-Host "3. Bot should respond to voice commands" -ForegroundColor White
Write-Host "4. Check Teams meeting for bot presence" -ForegroundColor White 