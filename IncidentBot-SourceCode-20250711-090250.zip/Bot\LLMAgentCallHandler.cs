// <copyright file="LLMAgentCallHandler.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.Bot
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.Graph;
    using Microsoft.Graph.Communications.Calls;
    using Microsoft.Graph.Communications.Common.Telemetry;
    using Microsoft.Graph.Communications.Resources;
    using Sample.IncidentBot.LLM;

    /// <summary>
    /// Call handler for LLM agent functionality with real-time audio processing.
    /// This handler implements the EchoBot pattern for application-hosted media bot capabilities.
    /// </summary>
    public class LLMAgentCallHandler : CallHandler
    {
        private readonly IConversationManager conversationManager;
        private readonly ISpeechToTextService speechToTextService;
        private readonly ITextToSpeechService textToSpeechService;
        private readonly IAudioStreamService audioStreamService;
        private readonly IGraphLogger graphLogger;
        private int welcomeMessagePlayed;
        private bool audioSocketInitialized = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="LLMAgentCallHandler"/> class.
        /// </summary>
        /// <param name="bot">The bot.</param>
        /// <param name="call">The call.</param>
        /// <param name="conversationManager">The conversation manager.</param>
        /// <param name="speechToTextService">The speech-to-text service.</param>
        /// <param name="textToSpeechService">The text-to-speech service.</param>
        /// <param name="audioStreamService">The audio stream service.</param>
        public LLMAgentCallHandler(Bot bot, ICall call, IConversationManager conversationManager, ISpeechToTextService speechToTextService, ITextToSpeechService textToSpeechService, IAudioStreamService audioStreamService)
            : base(bot, call)
        {
            this.conversationManager = conversationManager ?? throw new ArgumentNullException(nameof(conversationManager));
            this.speechToTextService = speechToTextService ?? throw new ArgumentNullException(nameof(speechToTextService));
            this.textToSpeechService = textToSpeechService ?? throw new ArgumentNullException(nameof(textToSpeechService));
            this.audioStreamService = audioStreamService ?? throw new ArgumentNullException(nameof(audioStreamService));
            this.graphLogger = call.GraphLogger.CreateShim(nameof(LLMAgentCallHandler));

            // Set the call reference in the audio stream service
            if (this.audioStreamService is TeamsAudioStreamService teamsAudioService)
            {
                teamsAudioService.SetCallReference(call.Id, call);
            }

            // Subscribe to transcription events
            this.speechToTextService.OnTranscriptionReceived += this.OnTranscriptionReceived;
            
            // Subscribe to audio stream events (for fallback)
            this.audioStreamService.OnAudioDataReceived += this.OnAudioDataReceived;
        }

        /// <summary>
        /// Gets the conversation manager.
        /// </summary>
        public IConversationManager ConversationManager => this.conversationManager;

        /// <summary>
        /// Gets the speech-to-text service.
        /// </summary>
        public ISpeechToTextService SpeechToTextService => this.speechToTextService;

        /// <summary>
        /// Gets the text-to-speech service.
        /// </summary>
        public ITextToSpeechService TextToSpeechService => this.textToSpeechService;

        /// <summary>
        /// Gets the audio stream service.
        /// </summary>
        public IAudioStreamService AudioStreamService => this.audioStreamService;

        /// <summary>
        /// Process user input and generate response.
        /// </summary>
        /// <param name="userInput">The user input text.</param>
        /// <returns>The task for await.</returns>
        public async Task ProcessUserInputAsync(string userInput)
        {
            try
            {
                this.graphLogger.Info($"Processing user input: {userInput}");

                // Get AI response from conversation manager
                var response = await this.conversationManager.ProcessUserInputAsync(userInput, this.Call.Id).ConfigureAwait(false);

                if (!string.IsNullOrEmpty(response))
                {
                    this.graphLogger.Info($"AI Response: {response}");

                    // Generate TTS audio for the response
                    var audioData = await this.textToSpeechService.SynthesizeSpeechAsync(response, "en-US-JennyNeural", "en-US").ConfigureAwait(false);

                    if (audioData != null && audioData.Length > 0)
                    {
                        this.graphLogger.Info($"Generated TTS audio: {audioData.Length} bytes");

                        // Try to send audio via AudioSocket if available
                        if (this.audioSocketInitialized)
                        {
                            try
                            {
                                await this.SendAudioViaSocketAsync(audioData).ConfigureAwait(false);
                                this.graphLogger.Info("Sent response via AudioSocket");
                                return;
                            }
                            catch (Exception audioEx)
                            {
                                this.graphLogger.Warn($"Failed to send audio via AudioSocket: {audioEx.Message}");
                            }
                        }

                        // Fallback to existing audio prompt
                        await this.Call.PlayPromptAsync(new List<MediaPrompt> { this.Bot.MediaMap[Bot.BotIncomingPromptName] }).ConfigureAwait(false);
                    }
                    else
                    {
                        this.graphLogger.Warn("TTS service returned null or empty audio data");

                        // Fallback to existing audio prompt
                        await this.Call.PlayPromptAsync(new List<MediaPrompt> { this.Bot.MediaMap[Bot.BotIncomingPromptName] }).ConfigureAwait(false);
                    }
                }
                else
                {
                    this.graphLogger.Warn("No response generated from conversation manager");
                    await this.PlayErrorResponseAsync().ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                this.graphLogger.Error(ex, "Failed to process user input");

                // Fallback to existing audio prompt
                try
                {
                    await this.Call.PlayPromptAsync(new List<MediaPrompt> { this.Bot.MediaMap[Bot.BotIncomingPromptName] }).ConfigureAwait(false);
                }
                catch (Exception fallbackEx)
                {
                    this.graphLogger.Error(fallbackEx, "Failed to play fallback audio prompt");
                }
            }
        }

        /// <summary>
        /// End the conversation for this call.
        /// </summary>
        public void EndConversation()
        {
            try
            {
                this.conversationManager.EndConversation(this.Call.Id);
                this.graphLogger.Info($"Ended conversation for call {this.Call.Id}");
            }
            catch (Exception ex)
            {
                this.graphLogger.Error(ex, "Failed to end conversation");
            }
        }

        /// <inheritdoc/>
        protected override void CallOnUpdated(ICall sender, ResourceEventArgs<Call> args)
        {
            if (sender.Resource.State == CallState.Established)
            {
                var currentWelcomeTimes = Interlocked.Increment(ref this.welcomeMessagePlayed);
                if (currentWelcomeTimes == 1)
                {
                    this.graphLogger.Info("Call established, initializing LLM agent conversation with EchoBot audio pattern");
                    this.InitializeConversation();
                    this.InitializeAudioSocket();
                    _ = this.PlayWelcomeMessageAsync();
                }
            }
        }

        /// <inheritdoc/>
        protected override void ParticipantsOnUpdated(IParticipantCollection sender, CollectionEventArgs<IParticipant> args)
        {
            foreach (var participant in args.AddedResources)
            {
                var userId = participant.Resource?.Info?.Identity?.User?.Id;
                if (!string.IsNullOrEmpty(userId))
                {
                    this.graphLogger.Info($"User {userId} joined the conversation");
                }
            }
        }

        /// <inheritdoc/>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                // Unsubscribe from transcription events
                this.speechToTextService.OnTranscriptionReceived -= this.OnTranscriptionReceived;
                
                // Unsubscribe from audio stream events
                this.audioStreamService.OnAudioDataReceived -= this.OnAudioDataReceived;
                
                // Stop real-time transcription
                Task.Run(async () =>
                {
                    try
                    {
                        await this.speechToTextService.StopRealTimeTranscriptionAsync(this.Call.Id).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        this.graphLogger.Error(ex, "Failed to stop real-time transcription");
                    }
                });

                // Unsubscribe from audio stream
                Task.Run(async () =>
                {
                    try
                    {
                        await this.audioStreamService.UnsubscribeFromAudioStreamAsync(this.Call.Id).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                        this.graphLogger.Error(ex, "Failed to unsubscribe from audio stream");
                    }
                });

                this.EndConversation();
            }

            base.Dispose(disposing);
        }

        /// <summary>
        /// Initialize the conversation for this call.
        /// </summary>
        private void InitializeConversation()
        {
            try
            {
                this.conversationManager.InitializeConversation(this.Call.Id);
                this.graphLogger.Info($"Initialized conversation for call {this.Call.Id}");
            }
            catch (Exception ex)
            {
                this.graphLogger.Error(ex, "Failed to initialize conversation");
            }
        }

        /// <summary>
        /// Initialize AudioSocket for real-time audio processing using EchoBot pattern.
        /// This enables application-hosted media bot capabilities.
        /// </summary>
        private void InitializeAudioSocket()
        {
            try
            {
                if (this.audioSocketInitialized)
                {
                    this.graphLogger.Info("AudioSocket already initialized");
                    return;
                }

                this.graphLogger.Info("Initializing AudioSocket using EchoBot pattern for real-time audio processing");

                // Try to access AudioSocket using reflection (in case it's not directly accessible)
                var audioSocketProperty = this.Call.GetType().GetProperty("AudioSocket");
                if (audioSocketProperty != null)
                {
                    var audioSocket = audioSocketProperty.GetValue(this.Call);
                    if (audioSocket != null)
                    {
                        this.graphLogger.Info("AudioSocket found, setting up real-time audio processing");

                        // Try to set the mode to receive and send
                        var modeProperty = audioSocket.GetType().GetProperty("Mode");
                        if (modeProperty != null)
                        {
                            try
                            {
                                // Try to set MediaStreamMode.ReceiveAndSend
                                var receiveAndSendMode = Enum.Parse(modeProperty.PropertyType, "ReceiveAndSend");
                                modeProperty.SetValue(audioSocket, receiveAndSendMode);
                                this.graphLogger.Info("AudioSocket mode set to ReceiveAndSend");
                            }
                            catch (Exception modeEx)
                            {
                                this.graphLogger.Warn($"Could not set AudioSocket mode: {modeEx.Message}");
                            }
                        }

                        // Hook the incoming audio for real-time processing
                        var audioFrameEvent = audioSocket.GetType().GetEvent("OnAudioMediaFrameReceived");
                        if (audioFrameEvent != null)
                        {
                            // Create a delegate for the audio frame handler
                            var audioFrameHandler = new Action<object>(this.OnAudioMediaFrameReceived);
                            audioFrameEvent.AddEventHandler(audioSocket, audioFrameHandler);

                            this.audioSocketInitialized = true;
                            this.graphLogger.Info("AudioSocket initialized successfully with real-time audio processing");
                        }
                        else
                        {
                            this.graphLogger.Warn("OnAudioMediaFrameReceived event not found - falling back to simulated audio");
                            this.StartRealTimeTranscription();
                            this.StartAudioStreamSubscription();
                        }
                    }
                    else
                    {
                        this.graphLogger.Warn("AudioSocket is null - falling back to simulated audio");
                        this.StartRealTimeTranscription();
                        this.StartAudioStreamSubscription();
                    }
                }
                else
                {
                    this.graphLogger.Warn("AudioSocket property not found - falling back to simulated audio");
                    this.StartRealTimeTranscription();
                    this.StartAudioStreamSubscription();
                }
            }
            catch (Exception ex)
            {
                this.graphLogger.Error(ex, "Failed to initialize AudioSocket - falling back to simulated audio");
                this.StartRealTimeTranscription();
                this.StartAudioStreamSubscription();
            }
        }

        /// <summary>
        /// Handle real-time audio frames from Teams meeting using EchoBot pattern.
        /// This is the core method for application-hosted media bot functionality.
        /// </summary>
        /// <param name="frame">The audio frame containing raw PCM data.</param>
        private void OnAudioMediaFrameReceived(object frame)
        {
            Task.Run(async () =>
            {
                try
                {
                    if (frame == null)
                    {
                        return;
                    }

                    this.graphLogger.Info("Received audio frame, processing for speech recognition");

                    // Extract audio data from the frame
                    byte[] audioData = this.ExtractAudioDataFromFrame(frame);

                    if (audioData != null && audioData.Length > 0)
                    {
                        // Process the audio frame for speech recognition
                        var transcribedText = await this.speechToTextService.TranscribeAudioAsync(audioData, "en-US").ConfigureAwait(false);

                        if (!string.IsNullOrEmpty(transcribedText))
                        {
                            this.graphLogger.Info($"Real-time transcription: {transcribedText}");

                            // Process the transcribed text and generate AI response
                            await this.ProcessUserInputAsync(transcribedText).ConfigureAwait(false);
                        }
                    }
                }
                catch (Exception ex)
                {
                    this.graphLogger.Error(ex, "Error processing audio frame");
                }
            });
        }

        /// <summary>
        /// Extract audio data from the audio frame object.
        /// </summary>
        /// <param name="frame">The audio frame object.</param>
        /// <returns>The audio data as byte array.</returns>
        private byte[] ExtractAudioDataFromFrame(object frame)
        {
            try
            {
                // Try to get the Data property from the frame
                var dataProperty = frame.GetType().GetProperty("Data");
                if (dataProperty != null)
                {
                    var data = dataProperty.GetValue(frame);
                    if (data is byte[] audioData)
                    {
                        return audioData;
                    }
                }

                // Try to get the Buffer property
                var bufferProperty = frame.GetType().GetProperty("Buffer");
                if (bufferProperty != null)
                {
                    var buffer = bufferProperty.GetValue(frame);
                    if (buffer is byte[] audioBuffer)
                    {
                        return audioBuffer;
                    }
                }

                // If frame is already a byte array
                if (frame is byte[] directAudioData)
                {
                    return directAudioData;
                }

                this.graphLogger.Warn("Could not extract audio data from frame");
                return new byte[0];
            }
            catch (Exception ex)
            {
                this.graphLogger.Error(ex, "Error extracting audio data from frame");
                return new byte[0];
            }
        }

        /// <summary>
        /// Start real-time transcription as fallback.
        /// </summary>
        private void StartRealTimeTranscription()
        {
            Task.Run(async () =>
            {
                try
                {
                    await this.speechToTextService.StartRealTimeTranscriptionAsync(this.Call.Id).ConfigureAwait(false);
                    this.graphLogger.Info("Started real-time transcription as fallback");
                }
                catch (Exception ex)
                {
                    this.graphLogger.Error(ex, "Failed to start real-time transcription");
                }
            });
        }

        /// <summary>
        /// Start audio stream subscription as fallback.
        /// </summary>
        private void StartAudioStreamSubscription()
        {
            Task.Run(async () =>
            {
                try
                {
                    await this.audioStreamService.SubscribeToAudioStreamAsync(this.Call.Id).ConfigureAwait(false);
                    this.graphLogger.Info("Started audio stream subscription as fallback");
                }
                catch (Exception ex)
                {
                    this.graphLogger.Error(ex, "Failed to start audio stream subscription");
                }
            });
        }

        /// <summary>
        /// Play welcome message using TTS.
        /// </summary>
        /// <returns>The task for await.</returns>
        private async Task PlayWelcomeMessageAsync()
        {
            try
            {
                this.graphLogger.Info("Playing welcome message using TTS");

                var welcomeText = "Hello! I'm your AI assistant. I'm here to help you with this incident. You can speak to me naturally, and I'll respond to your questions and requests.";

                var audioData = await this.textToSpeechService.SynthesizeSpeechAsync(welcomeText, "en-US-JennyNeural", "en-US").ConfigureAwait(false);

                if (audioData != null && audioData.Length > 0)
                {
                    this.graphLogger.Info($"Generated welcome TTS audio: {audioData.Length} bytes");

                    // Try to send audio via AudioSocket if available
                    if (this.audioSocketInitialized)
                    {
                        try
                        {
                            await this.SendAudioViaSocketAsync(audioData).ConfigureAwait(false);
                            this.graphLogger.Info("Sent welcome message via AudioSocket");
                            return;
                        }
                        catch (Exception audioEx)
                        {
                            this.graphLogger.Warn($"Failed to send audio via AudioSocket: {audioEx.Message}");
                        }
                    }

                    // Fallback to existing audio prompt
                    await this.Call.PlayPromptAsync(new List<MediaPrompt> { this.Bot.MediaMap[Bot.BotIncomingPromptName] }).ConfigureAwait(false);
                }
                else
                {
                    this.graphLogger.Warn("TTS service returned null or empty audio data for welcome message");

                    // Fallback to existing audio prompt
                    await this.Call.PlayPromptAsync(new List<MediaPrompt> { this.Bot.MediaMap[Bot.BotIncomingPromptName] }).ConfigureAwait(false);
                }

                this.graphLogger.Info("Started playing welcome message");
            }
            catch (Exception ex)
            {
                this.graphLogger.Error(ex, "Failed to play welcome message");

                // Fallback to existing audio prompt
                try
                {
                    await this.Call.PlayPromptAsync(new List<MediaPrompt> { this.Bot.MediaMap[Bot.BotIncomingPromptName] }).ConfigureAwait(false);
                }
                catch (Exception fallbackEx)
                {
                    this.graphLogger.Error(fallbackEx, "Failed to play fallback audio prompt");
                }
            }
        }

        /// <summary>
        /// Send audio data via AudioSocket using reflection.
        /// </summary>
        /// <param name="audioData">The audio data to send.</param>
        /// <returns>The task for await.</returns>
        private async Task SendAudioViaSocketAsync(byte[] audioData)
        {
            try
            {
                var audioSocketProperty = this.Call.GetType().GetProperty("AudioSocket");
                if (audioSocketProperty != null)
                {
                    var audioSocket = audioSocketProperty.GetValue(this.Call);
                    if (audioSocket != null)
                    {
                        var sendMethod = audioSocket.GetType().GetMethod("SendAsync");
                        if (sendMethod != null)
                        {
                            var task = (Task)sendMethod.Invoke(audioSocket, new object[] { audioData });
                            await task.ConfigureAwait(false);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                this.graphLogger.Error(ex, "Failed to send audio via AudioSocket");
                throw;
            }
        }

        /// <summary>
        /// Play an error response.
        /// </summary>
        /// <returns>The task for await.</returns>
        private async Task PlayErrorResponseAsync()
        {
            try
            {
                this.graphLogger.Info("Playing error response");

                // Try to send error audio via AudioSocket if available
                if (this.audioSocketInitialized)
                {
                    try
                    {
                        var errorText = "I'm sorry, I didn't understand that. Could you please repeat?";
                        var audioData = await this.textToSpeechService.SynthesizeSpeechAsync(errorText, "en-US-JennyNeural", "en-US").ConfigureAwait(false);

                        if (audioData != null && audioData.Length > 0)
                        {
                            await this.SendAudioViaSocketAsync(audioData).ConfigureAwait(false);
                            this.graphLogger.Info("Sent error response via AudioSocket");
                            return;
                        }
                    }
                    catch (Exception audioEx)
                    {
                        this.graphLogger.Warn($"Failed to send error audio via AudioSocket: {audioEx.Message}");
                    }
                }

                // Fallback to existing audio prompt
                await this.Call.PlayPromptAsync(new List<MediaPrompt> { this.Bot.MediaMap[Bot.BotEndpointIncomingPromptName] }).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                this.graphLogger.Error(ex, "Failed to play error response");
            }
        }

        /// <summary>
        /// Handle transcription events from the speech-to-text service (fallback method).
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="transcribedText">The transcribed text.</param>
        private void OnTranscriptionReceived(string callId, string transcribedText)
        {
            if (callId != this.Call.Id)
            {
                return;
            }

            this.graphLogger.Info($"Received transcription for call {callId}: {transcribedText}");

            // Process the transcribed text
            Task.Run(async () => { await this.ProcessUserInputAsync(transcribedText).ConfigureAwait(false); });
        }

        /// <summary>
        /// Handle audio data received from the audio stream service (fallback method).
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="audioData">The audio data.</param>
        private void OnAudioDataReceived(string callId, byte[] audioData)
        {
            if (callId != this.Call.Id)
            {
                return;
            }

            this.graphLogger.Info($"Received audio data for call {callId}: {audioData?.Length ?? 0} bytes");
                
            // Process audio data for speech recognition
                Task.Run(async () =>
                {
                    try
                    {
                        await this.speechToTextService.ProcessAudioDataAsync(callId, audioData).ConfigureAwait(false);
                    }
                    catch (Exception ex)
                    {
                    this.graphLogger.Error(ex, "Error processing audio data");
                    }
                });
        }
    }
}