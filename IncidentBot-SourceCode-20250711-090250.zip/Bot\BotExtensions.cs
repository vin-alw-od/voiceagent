// <copyright file="BotExtensions.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.Bot
{
    using System;
    using System.Collections.Concurrent;
    using System.Threading.Tasks;
    using Microsoft.Graph.Communications.Calls;
    using Microsoft.Graph.Communications.Common.Telemetry;
    using Microsoft.Graph.Communications.Core.Notifications;
    using Microsoft.Graph.Communications.Resources;
    using Sample.Common.Logging;
    using Sample.IncidentBot.Data;
    using Sample.IncidentBot.LLM;

    /// <summary>
    /// Extension methods for the Bot class to add LLM agent functionality.
    /// </summary>
    public static class BotExtensions
    {
        /// <summary>
        /// Join a call with LLM agent capabilities.
        /// </summary>
        /// <param name="bot">The bot instance.</param>
        /// <param name="joinCallBody">The join call request data.</param>
        /// <param name="conversationManager">The conversation manager.</param>
        /// <param name="speechToTextService">The speech-to-text service.</param>
        /// <param name="textToSpeechService">The text-to-speech service.</param>
        /// <param name="audioStreamService">The audio stream service.</param>
        /// <returns>The call that was joined.</returns>
        public static async Task<ICall> JoinCallWithLLMAgentAsync(this Bot bot, JoinCallRequestData joinCallBody, IConversationManager conversationManager, ISpeechToTextService speechToTextService, ITextToSpeechService textToSpeechService, IAudioStreamService audioStreamService)
        {
            if (bot == null)
            {
                throw new ArgumentNullException(nameof(bot));
            }

            if (joinCallBody == null)
            {
                throw new ArgumentNullException(nameof(joinCallBody));
            }

            if (conversationManager == null)
            {
                throw new ArgumentNullException(nameof(conversationManager));
            }

            if (speechToTextService == null)
            {
                throw new ArgumentNullException(nameof(speechToTextService));
            }

            if (textToSpeechService == null)
            {
                throw new ArgumentNullException(nameof(textToSpeechService));
            }

            if (audioStreamService == null)
            {
                throw new ArgumentNullException(nameof(audioStreamService));
            }

            // Use the existing JoinCallAsync method to join the call
            var call = await bot.JoinCallAsync(joinCallBody).ConfigureAwait(false);

            // Replace the default call handler with LLM agent call handler
            if (bot.CallHandlers.TryGetValue(call.Id, out var existingHandler))
            {
                // Dispose the existing handler
                existingHandler.Dispose();

                // Remove from handlers
                bot.CallHandlers.TryRemove(call.Id, out _);
            }

            // Create and add the LLM agent call handler
            var llmHandler = new LLMAgentCallHandler(bot, call, conversationManager, speechToTextService, textToSpeechService, audioStreamService);
            bot.CallHandlers.TryAdd(call.Id, llmHandler);

            // Use the client's logger since graphLogger is private
            bot.Client.GraphLogger.Info($"Joined call {call.Id} with LLM agent capabilities");

            return call;
        }

        /// <summary>
        /// Join a call with LLM agent capabilities (legacy overload for backward compatibility).
        /// </summary>
        /// <param name="bot">The bot instance.</param>
        /// <param name="joinCallBody">The join call request data.</param>
        /// <param name="conversationManager">The conversation manager.</param>
        /// <param name="speechToTextService">The speech-to-text service.</param>
        /// <returns>The call that was joined.</returns>
        public static Task<ICall> JoinCallWithLLMAgentAsync(this Bot bot, JoinCallRequestData joinCallBody, IConversationManager conversationManager, ISpeechToTextService speechToTextService)
        {
            // This method is kept for backward compatibility but will throw an exception
            // indicating that the new services are required
            throw new InvalidOperationException("This overload is deprecated. Use the overload that includes ITextToSpeechService and IAudioStreamService parameters.");
        }

        /// <summary>
        /// Get the LLM agent call handler for a specific call.
        /// </summary>
        /// <param name="bot">The bot instance.</param>
        /// <param name="callId">The call identifier.</param>
        /// <returns>The LLM agent call handler or null if not found.</returns>
        public static LLMAgentCallHandler GetLLMAgentCallHandler(this Bot bot, string callId)
        {
            if (bot?.CallHandlers?.TryGetValue(callId, out var handler) == true && handler is LLMAgentCallHandler llmHandler)
            {
                return llmHandler;
            }

            return null;
        }

        /// <summary>
        /// Check if a call is managed by an LLM agent.
        /// </summary>
        /// <param name="bot">The bot instance.</param>
        /// <param name="callId">The call identifier.</param>
        /// <returns>True if the call is managed by an LLM agent, false otherwise.</returns>
        public static bool IsLLMAgentCall(this Bot bot, string callId)
        {
            return bot.GetLLMAgentCallHandler(callId) != null;
        }

        /// <summary>
        /// Process a text message through the LLM agent for a specific call.
        /// </summary>
        /// <param name="bot">The bot instance.</param>
        /// <param name="callId">The call identifier.</param>
        /// <param name="message">The message to process.</param>
        /// <returns>The task for await.</returns>
        public static async Task ProcessLLMMessageAsync(this Bot bot, string callId, string message)
        {
            var llmHandler = bot.GetLLMAgentCallHandler(callId);
            if (llmHandler != null)
            {
                await llmHandler.ProcessUserInputAsync(message).ConfigureAwait(false);
            }
            else
            {
                throw new InvalidOperationException($"No LLM agent call handler found for call {callId}");
            }
        }
    }
}