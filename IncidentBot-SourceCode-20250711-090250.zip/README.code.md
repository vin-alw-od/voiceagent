﻿Solution
- Solution Items
- IncidentBot
	- wwwroot
		- audio
			<Files for audio prompt>
	- Bot
		- Bot.cs
			<Calls management>
		- CallHandler.cs
			<Base call handler for each call>
		- MeetingCallHandler.cs
			<Call handler for bot meeting calls>
		- ResponderCallHandler.cs
			<Call handler for responder calls>
		- AuthenticationProvider.cs
			<Provide the auth token from bot, and check the Incoming Request token from platform>
		- CallAffinityHelper.cs
			<Helper class to keep IncomingRequest keep in the same web instance>
	- Controller
		- IncidentsController.cs
			<Raise incidents, and get incident logs>
		- PlatformCallController.cs
			<Receive Incoming Request from platform, and hand over the message to Bot to process
		- <Other controllers>
			<Test purpose for each call actions>
	- Data
		<Data structures used by controller>
	- IncidentManagement
		<Data structures used by Bot to store the incident status>
	- Logging
		<Logging helper classes, might be updated soon>
	- appsettings.json
		<The configuration file>
	- Program.cs
		<The entry class of the executable file>
	- Startup.cs
		<The class to initialize and configure the web site>

# TeamsAudioStreamService Implementation

## Overview

The `TeamsAudioStreamService` is a complete implementation of real-time audio streaming for Microsoft Teams calls using the Microsoft Graph Communications SDK. This service provides the foundation for building intelligent voice assistants and audio processing applications.

## Architecture

### Core Components

1. **TeamsAudioStreamService** - Main service for audio stream management
2. **AudioSubscriptionInfo** - Data structure for tracking subscription state
3. **LLMAgentCallHandler** - Integration point with Teams calls
4. **Azure Speech Services** - Speech-to-text and text-to-speech capabilities

### Key Features

- ✅ **Real-time Audio Subscription** - Subscribe to Teams call audio streams
- ✅ **Event-driven Architecture** - React to call state changes and participant updates
- ✅ **Automatic Cleanup** - Proper disposal of resources and event handlers
- ✅ **Azure Speech Integration** - Seamless integration with speech services
- ✅ **Thread-safe Operations** - Concurrent dictionary for managing multiple calls
- ✅ **Comprehensive Logging** - Detailed logging for debugging and monitoring

## Implementation Details

### Audio Stream Subscription

The service manages audio subscriptions through the following process:

1. **Call Reference Setup** - Store call references for audio access
2. **Event Handler Registration** - Subscribe to call and participant events
3. **State Management** - Track subscription status and lifecycle
4. **Automatic Cleanup** - Handle call termination and failures

```csharp
// Subscribe to audio stream
await audioStreamService.SubscribeToAudioStreamAsync(callId);

// Check if subscription is active
bool isActive = audioStreamService.IsAudioStreamActive(callId);

// Unsubscribe from audio stream
await audioStreamService.UnsubscribeFromAudioStreamAsync(callId);
```

### Event Handling

The service automatically handles various Teams call events:

- **Call State Changes** - Established, Terminated, Failed
- **Participant Updates** - Join, Leave, Mute state changes
- **Audio Data Processing** - Real-time audio stream processing

### Integration with Azure Speech Services

The audio stream service integrates seamlessly with Azure Speech services:

```csharp
// Audio data flows from Teams → TeamsAudioStreamService → Azure Speech → LLM
audioStreamService.OnAudioDataReceived += (callId, audioData) =>
{
    // Process audio through speech-to-text
    await speechToTextService.ProcessAudioDataAsync(callId, audioData);
};
```

## Usage Examples

### 1. Basic Audio Stream Setup

```csharp
// In your call handler constructor
public LLMAgentCallHandler(Bot bot, ICall call, IAudioStreamService audioStreamService)
{
    // Set the call reference
    if (audioStreamService is TeamsAudioStreamService teamsAudioService)
    {
        teamsAudioService.SetCallReference(call.Id, call);
    }
    
    // Subscribe to audio events
    audioStreamService.OnAudioDataReceived += OnAudioDataReceived;
}

// Start audio subscription when call is established
protected override void CallOnUpdated(ICall sender, ResourceEventArgs<Call> args)
{
    if (sender.Resource.State == CallState.Established)
    {
        StartAudioStreamSubscription();
    }
}

private void StartAudioStreamSubscription()
{
    Task.Run(async () =>
    {
        await audioStreamService.SubscribeToAudioStreamAsync(Call.Id);
    });
}
```

### 2. Audio Data Processing

```csharp
private void OnAudioDataReceived(string callId, byte[] audioData)
{
    // Process audio data through speech-to-text
    Task.Run(async () =>
    {
        await speechToTextService.ProcessAudioDataAsync(callId, audioData);
    });
}
```

### 3. Testing Audio Streams

Use the provided API endpoints to test audio streaming functionality:

```bash
# Test audio stream simulation
POST /llmagent/testAudioStream
{
    "callId": "your-call-id",
    "audioData": [1, 2, 3, 4, 5]
}

# Get subscription information
GET /llmagent/audioSubscription/{callId}

# Test text-to-speech
POST /llmagent/testTTS
{
    "text": "Hello, this is a test message",
    "voice": "en-US-JennyNeural",
    "language": "en-US"
}

# Get available voices
GET /llmagent/voices?language=en-US
```

## API Reference

### TeamsAudioStreamService Methods

| Method | Description |
|--------|-------------|
| `SubscribeToAudioStreamAsync(string callId)` | Subscribe to audio stream for a call |
| `UnsubscribeFromAudioStreamAsync(string callId)` | Unsubscribe from audio stream |
| `IsAudioStreamActive(string callId)` | Check if subscription is active |
| `SetCallReference(string callId, ICall call)` | Set call reference for audio access |
| `GetAudioSubscriptionInfo(string callId)` | Get subscription information |
| `SimulateAudioData(string callId, byte[] audioData)` | Simulate audio data for testing |

### AudioSubscriptionInfo Properties

| Property | Type | Description |
|----------|------|-------------|
| `CallId` | string | The call identifier |
| `Call` | ICall | The call reference |
| `IsActive` | bool | Whether subscription is active |
| `SubscriptionStartTime` | DateTime | When subscription started |
| `SubscriptionEndTime` | DateTime? | When subscription ended |
| `Duration` | TimeSpan | Duration of subscription |

## Configuration

### Azure Speech Services

Ensure your `appsettings.json` contains the Azure Speech configuration:

```json
{
  "AzureSpeech": {
    "SubscriptionKey": "your-subscription-key",
    "Region": "your-region"
  }
}
```

### Service Registration

The services are automatically registered in `Startup.cs`:

```csharp
// Register Azure Speech Services
services.AddSingleton<ISpeechToTextService, AzureSpeechToTextService>();
services.AddSingleton<ITextToSpeechService, AzureTextToSpeechService>();

// Register Audio Stream Service
services.AddSingleton<IAudioStreamService, TeamsAudioStreamService>();

// Register LLM Conversation Manager
services.AddSingleton<IConversationManager, BasicConversationManager>();
```

## Testing

### Unit Testing

```csharp
[Test]
public async Task SubscribeToAudioStream_ValidCallId_ShouldSucceed()
{
    // Arrange
    var logger = new Mock<ILogger<TeamsAudioStreamService>>();
    var service = new TeamsAudioStreamService(logger.Object);
    var callId = "test-call-id";
    var call = new Mock<ICall>();
    
    // Act
    service.SetCallReference(callId, call.Object);
    await service.SubscribeToAudioStreamAsync(callId);
    
    // Assert
    Assert.IsTrue(service.IsAudioStreamActive(callId));
}
```

### Integration Testing

```csharp
[Test]
public async Task AudioStream_EndToEnd_ShouldProcessAudio()
{
    // Arrange
    var audioData = new byte[] { 1, 2, 3, 4, 5 };
    var callId = "test-call-id";
    var audioProcessed = false;
    
    audioStreamService.OnAudioDataReceived += (id, data) =>
    {
        if (id == callId)
        {
            audioProcessed = true;
        }
    };
    
    // Act
    service.SimulateAudioData(callId, audioData);
    
    // Assert
    Assert.IsTrue(audioProcessed);
}
```

## Troubleshooting

### Common Issues

1. **Call Reference Not Found**
   - Ensure `SetCallReference` is called before subscribing
   - Verify the call ID matches the stored reference

2. **Audio Data Not Received**
   - Check if subscription is active with `IsAudioStreamActive`
   - Verify event handlers are properly registered
   - Ensure call is in `Established` state

3. **Memory Leaks**
   - The service implements `IDisposable` for proper cleanup
   - Ensure `UnsubscribeFromAudioStreamAsync` is called when calls end
   - Check that event handlers are unsubscribed

### Debugging

Enable detailed logging by setting log level to `Debug`:

```json
{
  "Logging": {
    "LogLevel": {
      "Sample.IncidentBot.LLM.TeamsAudioStreamService": "Debug"
    }
  }
}
```

## Performance Considerations

- **Concurrent Operations** - Uses `ConcurrentDictionary` for thread-safe operations
- **Event Handler Management** - Automatic cleanup prevents memory leaks
- **Audio Data Processing** - Asynchronous processing to avoid blocking
- **Resource Management** - Proper disposal of subscriptions and handlers

## Future Enhancements

1. **Real Audio Capture** - Replace simulation with actual Teams audio capture
2. **Audio Quality Settings** - Configurable audio format and quality
3. **Multi-language Support** - Enhanced language detection and processing
4. **Advanced Analytics** - Audio quality metrics and performance monitoring
5. **Custom Audio Processing** - Plugin architecture for custom audio filters

## Related Documentation

- [Microsoft Graph Communications SDK](https://docs.microsoft.com/en-us/graph/cloud-communications-concept-overview)
- [Azure Speech Services](https://docs.microsoft.com/en-us/azure/cognitive-services/speech-service/)
- [Teams Bot Framework](https://docs.microsoft.com/en-us/microsoftteams/platform/bots/what-are-bots)
