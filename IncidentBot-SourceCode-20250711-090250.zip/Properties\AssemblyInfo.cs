// <copyright file="AssemblyInfo.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

using System.Reflection;

[assembly: AssemblyCompany("Sample.IncidentBot")]
[assembly: AssemblyProduct("Sample.LocalMediaSamples.IncidentBot")]
[assembly: AssemblyTitle("Sample.IncidentBot")]
[assembly: AssemblyVersion("0.8")]
[assembly: AssemblyInformationalVersion("0.8")]
[assembly: AssemblyFileVersion("0.8.0.0")]