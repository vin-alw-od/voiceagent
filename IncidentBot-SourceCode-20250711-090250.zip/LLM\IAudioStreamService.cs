// <copyright file="IAudioStreamService.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System;
    using System.Threading.Tasks;

    /// <summary>
    /// Interface for audio stream services to handle real-time audio from Teams meetings.
    /// </summary>
    public interface IAudioStreamService
    {
        /// <summary>
        /// Event that is raised when audio data is received from a call.
        /// </summary>
        event Action<string, byte[]> OnAudioDataReceived;

        /// <summary>
        /// Subscribe to audio stream for a specific call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <returns>The task for await.</returns>
        Task SubscribeToAudioStreamAsync(string callId);

        /// <summary>
        /// Unsubscribe from audio stream for a specific call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <returns>The task for await.</returns>
        Task UnsubscribeFromAudioStreamAsync(string callId);

        /// <summary>
        /// Check if audio stream subscription is active for a call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <returns>True if subscription is active, false otherwise.</returns>
        bool IsAudioStreamActive(string callId);
    }
}