// <copyright file="LLMMessageRequestData.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.Data
{
    /// <summary>
    /// Data structure for LLM message requests.
    /// </summary>
    public class LLMMessageRequestData
    {
        /// <summary>
        /// Gets or sets the message text.
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Gets or sets the user identifier (optional).
        /// </summary>
        public string UserId { get; set; }
    }
}