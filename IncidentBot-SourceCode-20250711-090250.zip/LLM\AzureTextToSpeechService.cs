// <copyright file="AzureTextToSpeechService.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Threading.Tasks;
    using Microsoft.CognitiveServices.Speech;
    using Microsoft.CognitiveServices.Speech.Audio;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;

    /// <summary>
    /// Azure Text-to-Speech service implementation.
    /// </summary>
    public class AzureTextToSpeechService : ITextToSpeechService
    {
        private readonly ILogger<AzureTextToSpeechService> logger;
        private readonly string subscriptionKey;
        private readonly string region;
        private readonly Dictionary<string, string> availableVoices;

        /// <summary>
        /// Initializes a new instance of the <see cref="AzureTextToSpeechService"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="logger">The logger.</param>
        public AzureTextToSpeechService(IConfiguration configuration, ILogger<AzureTextToSpeechService> logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.subscriptionKey = configuration["AzureSpeech:SubscriptionKey"] ?? throw new ArgumentException("Azure Speech Subscription Key not configured");
            this.region = configuration["AzureSpeech:Region"] ?? throw new ArgumentException("Azure Speech Region not configured");
            this.availableVoices = this.InitializeAvailableVoices();
        }

        /// <inheritdoc/>
        public async Task<byte[]> SynthesizeSpeechAsync(string text, string voice = null, string language = "en-US")
        {
            try
            {
                this.logger.LogInformation("Starting speech synthesis for text: {TextLength} characters", text?.Length ?? 0);

                if (string.IsNullOrEmpty(text))
                {
                    this.logger.LogWarning("Empty text provided for speech synthesis");
                    return new byte[0];
                }

                var config = SpeechConfig.FromSubscription(this.subscriptionKey, this.region);

                // Set the voice if specified, otherwise use default
                if (!string.IsNullOrEmpty(voice))
                {
                    config.SpeechSynthesisVoiceName = voice;
                }
                else
                {
                    // Use a default voice for the specified language
                    var defaultVoice = this.GetDefaultVoiceForLanguage(language);
                    config.SpeechSynthesisVoiceName = defaultVoice;
                }

                // Set output format to WAV
                config.SetSpeechSynthesisOutputFormat(SpeechSynthesisOutputFormat.Riff16Khz16BitMonoPcm);

                using (var synthesizer = new SpeechSynthesizer(config))
                {
                    var result = await synthesizer.SpeakTextAsync(text).ConfigureAwait(false);

                    if (result.Reason == ResultReason.SynthesizingAudioCompleted)
                    {
                        var audioData = result.AudioData;
                        this.logger.LogInformation("Speech synthesis completed successfully. Audio size: {Size} bytes", audioData.Length);
                        return audioData;
                    }
                    else if (result.Reason == ResultReason.Canceled)
                    {
                        var cancellation = SpeechSynthesisCancellationDetails.FromResult(result);
                        this.logger.LogError(
                            "Speech synthesis canceled: {Reason}, {ErrorDetails}",
                            cancellation.Reason,
                            cancellation.ErrorDetails);
                        throw new InvalidOperationException($"Speech synthesis failed: {cancellation.ErrorDetails}");
                    }
                    else
                    {
                        this.logger.LogError("Speech synthesis failed with reason: {Reason}", result.Reason);
                        throw new InvalidOperationException($"Speech synthesis failed with reason: {result.Reason}");
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error during speech synthesis");
                throw;
            }
        }

        /// <inheritdoc/>
        public async Task<string[]> GetAvailableVoicesAsync(string language = null)
        {
            try
            {
                this.logger.LogInformation("Getting available voices for language: {Language}", language ?? "all");

                var config = SpeechConfig.FromSubscription(this.subscriptionKey, this.region);

                using (var synthesizer = new SpeechSynthesizer(config))
                {
                    var result = await synthesizer.GetVoicesAsync(language).ConfigureAwait(false);

                    if (result.Reason == ResultReason.VoicesListRetrieved)
                    {
                        var voices = new List<string>();
                        foreach (var voice in result.Voices)
                        {
                            voices.Add(voice.Name);
                        }

                        this.logger.LogInformation("Retrieved {Count} voices", voices.Count);
                        return voices.ToArray();
                    }
                    else
                    {
                        this.logger.LogError("Failed to retrieve voices: {Reason}", result.Reason);
                        return new string[0];
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error getting available voices");
                return new string[0];
            }
        }

        /// <summary>
        /// Synthesize speech and save to a file.
        /// </summary>
        /// <param name="text">The text to synthesize.</param>
        /// <param name="filePath">The file path to save the audio.</param>
        /// <param name="voice">The voice to use (optional).</param>
        /// <param name="language">The language code (optional, defaults to "en-US").</param>
        /// <returns>The task for await.</returns>
        public async Task SynthesizeSpeechToFileAsync(string text, string filePath, string voice = null, string language = "en-US")
        {
            try
            {
                this.logger.LogInformation("Synthesizing speech to file: {FilePath}", filePath);

                var config = SpeechConfig.FromSubscription(this.subscriptionKey, this.region);

                if (!string.IsNullOrEmpty(voice))
                {
                    config.SpeechSynthesisVoiceName = voice;
                }
                else
                {
                    var defaultVoice = this.GetDefaultVoiceForLanguage(language);
                    config.SpeechSynthesisVoiceName = defaultVoice;
                }

                // Set output format to WAV
                config.SetSpeechSynthesisOutputFormat(SpeechSynthesisOutputFormat.Riff16Khz16BitMonoPcm);

                using (var audioConfig = AudioConfig.FromWavFileOutput(filePath))
                using (var synthesizer = new SpeechSynthesizer(config, audioConfig))
                {
                    var result = await synthesizer.SpeakTextAsync(text).ConfigureAwait(false);

                    if (result.Reason == ResultReason.SynthesizingAudioCompleted)
                    {
                        this.logger.LogInformation("Speech synthesis to file completed successfully: {FilePath}", filePath);
                    }
                    else
                    {
                        this.logger.LogError("Speech synthesis to file failed: {Reason}", result.Reason);
                        throw new InvalidOperationException($"Speech synthesis to file failed: {result.Reason}");
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error synthesizing speech to file: {FilePath}", filePath);
                throw;
            }
        }

        /// <summary>
        /// Get the default voice for a specific language.
        /// </summary>
        /// <param name="language">The language code.</param>
        /// <returns>The default voice name for the language.</returns>
        private string GetDefaultVoiceForLanguage(string language)
        {
            var defaultVoices = new Dictionary<string, string>
            {
                { "en-US", "en-US-JennyNeural" },
                { "en-GB", "en-GB-RyanNeural" },
                { "es-ES", "es-ES-ElviraNeural" },
                { "fr-FR", "fr-FR-DeniseNeural" },
                { "de-DE", "de-DE-KatjaNeural" },
                { "it-IT", "it-IT-ElsaNeural" },
                { "pt-BR", "pt-BR-FranciscaNeural" },
                { "ja-JP", "ja-JP-NanamiNeural" },
                { "ko-KR", "ko-KR-SunHiNeural" },
                { "zh-CN", "zh-CN-XiaoxiaoNeural" },
            };

            return defaultVoices.TryGetValue(language, out var voice) ? voice : "en-US-JennyNeural";
        }

        /// <summary>
        /// Initialize available voices dictionary.
        /// </summary>
        /// <returns>Dictionary of available voices.</returns>
        private Dictionary<string, string> InitializeAvailableVoices()
        {
            return new Dictionary<string, string>
            {
                { "en-US-JennyNeural", "Jenny (Neural) - English (US)" },
                { "en-US-GuyNeural", "Guy (Neural) - English (US)" },
                { "en-GB-RyanNeural", "Ryan (Neural) - English (UK)" },
                { "en-GB-SoniaNeural", "Sonia (Neural) - English (UK)" },
                { "es-ES-ElviraNeural", "Elvira (Neural) - Spanish (Spain)" },
                { "fr-FR-DeniseNeural", "Denise (Neural) - French (France)" },
                { "de-DE-KatjaNeural", "Katja (Neural) - German (Germany)" },
                { "it-IT-ElsaNeural", "Elsa (Neural) - Italian (Italy)" },
                { "pt-BR-FranciscaNeural", "Francisca (Neural) - Portuguese (Brazil)" },
                { "ja-JP-NanamiNeural", "Nanami (Neural) - Japanese (Japan)" },
                { "ko-KR-SunHiNeural", "SunHi (Neural) - Korean (Korea)" },
                { "zh-CN-XiaoxiaoNeural", "Xiaoxiao (Neural) - Chinese (Simplified)" },
            };
        }
    }
}