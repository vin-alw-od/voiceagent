// <copyright file="ISpeechToTextService.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System.Threading.Tasks;

    /// <summary>
    /// Interface for speech-to-text conversion services.
    /// </summary>
    public interface ISpeechToTextService
    {
        /// <summary>
        /// Event that is raised when transcription is received.
        /// </summary>
        event System.Action<string, string> OnTranscriptionReceived;

        /// <summary>
        /// Transcribe audio data to text.
        /// </summary>
        /// <param name="audioData">The audio data to transcribe.</param>
        /// <param name="language">The language code (optional, defaults to "en-US").</param>
        /// <returns>The transcribed text.</returns>
        Task<string> TranscribeAudioAsync(byte[] audioData, string language = "en-US");

        /// <summary>
        /// Start real-time transcription for a call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <returns>The task for await.</returns>
        Task StartRealTimeTranscriptionAsync(string callId);

        /// <summary>
        /// Stop real-time transcription for a call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <returns>The task for await.</returns>
        Task StopRealTimeTranscriptionAsync(string callId);

        /// <summary>
        /// Process audio data for real-time transcription.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="audioData">The audio data to process.</param>
        /// <returns>The task for await.</returns>
        Task ProcessAudioDataAsync(string callId, byte[] audioData);
    }
}