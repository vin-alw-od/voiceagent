// <copyright file="AzureSpeechToTextService.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System;
    using System.Collections.Concurrent;
    using System.IO;
    using System.Threading.Tasks;
    using Microsoft.CognitiveServices.Speech;
    using Microsoft.CognitiveServices.Speech.Audio;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.Logging;

    // ISpeechToTextService is in the same namespace

    /// <summary>
    /// Azure Speech-to-Text service implementation.
    /// </summary>
    public class AzureSpeechToTextService : ISpeechToTextService
    {
        private readonly ILogger<AzureSpeechToTextService> logger;
        private readonly string subscriptionKey;
        private readonly string region;
        private readonly ConcurrentDictionary<string, SpeechRecognizer> activeRecognizers;
        private readonly ConcurrentDictionary<string, PushAudioInputStream> audioStreams;

        /// <summary>
        /// Initializes a new instance of the <see cref="AzureSpeechToTextService"/> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// <param name="logger">The logger.</param>
        public AzureSpeechToTextService(IConfiguration configuration, ILogger<AzureSpeechToTextService> logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.subscriptionKey = configuration["AzureSpeech:SubscriptionKey"] ?? throw new ArgumentException("Azure Speech Subscription Key not configured");
            this.region = configuration["AzureSpeech:Region"] ?? throw new ArgumentException("Azure Speech Region not configured");
            this.activeRecognizers = new ConcurrentDictionary<string, SpeechRecognizer>();
            this.audioStreams = new ConcurrentDictionary<string, PushAudioInputStream>();
        }

        /// <summary>
        /// Event that is raised when transcription is received.
        /// </summary>
        public event Action<string, string> OnTranscriptionReceived;

        /// <summary>
        /// Explicit implementation of the OnTranscriptionReceived event from ISpeechToTextService.
        /// </summary>
        event Action<string, string> ISpeechToTextService.OnTranscriptionReceived
        {
            add { this.OnTranscriptionReceived += value; }
            remove { this.OnTranscriptionReceived -= value; }
        }

        /// <inheritdoc/>
        public async Task<string> TranscribeAudioAsync(byte[] audioData, string language = "en-US")
        {
            try
            {
                this.logger.LogInformation("Starting audio transcription for language: {Language}", language);

                var config = SpeechConfig.FromSubscription(this.subscriptionKey, this.region);
                config.SpeechRecognitionLanguage = language;

                using (var audioStream = AudioInputStream.CreatePushStream())
                using (var audioConfig = AudioConfig.FromStreamInput(audioStream))
                using (var recognizer = new SpeechRecognizer(config, audioConfig))
                {
                    var result = await recognizer.RecognizeOnceAsync().ConfigureAwait(false);

                    if (result.Reason == ResultReason.RecognizedSpeech)
                    {
                        var transcription = result.Text;
                        this.logger.LogInformation("Transcription successful: {Transcription}", transcription);
                        return transcription;
                    }
                    else if (result.Reason == ResultReason.NoMatch)
                    {
                        this.logger.LogWarning("No speech detected in audio");
                        return string.Empty;
                    }
                    else
                    {
                        this.logger.LogError("Speech recognition failed: {Reason}", result.Reason);
                        return string.Empty;
                    }
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error during audio transcription");
                throw;
            }
        }

        /// <inheritdoc/>
        public async Task StartRealTimeTranscriptionAsync(string callId)
        {
            try
            {
                this.logger.LogInformation("Starting real-time transcription for call: {CallId}", callId);

                var config = SpeechConfig.FromSubscription(this.subscriptionKey, this.region);
                config.SpeechRecognitionLanguage = "en-US";
                config.EnableDictation();

                var audioStream = AudioInputStream.CreatePushStream();
                using (var audioConfig = AudioConfig.FromStreamInput(audioStream))
                {
                    var recognizer = new SpeechRecognizer(config, audioConfig);

                    // Set up event handlers for real-time transcription
                    recognizer.Recognized += (sender, e) =>
                    {
                        if (e.Result.Reason == ResultReason.RecognizedSpeech)
                        {
                            this.logger.LogInformation("Real-time transcription for call {CallId}: {Text}", callId, e.Result.Text);

                            // TODO: Send the transcribed text to the LLM agent
                            this.OnTranscriptionReceived?.Invoke(callId, e.Result.Text);
                        }
                    };

                    recognizer.Recognizing += (sender, e) =>
                    {
                        this.logger.LogDebug("Recognizing speech for call {CallId}: {Text}", callId, e.Result.Text);
                    };

                    recognizer.Canceled += (sender, e) =>
                    {
                        this.logger.LogWarning("Speech recognition canceled for call {CallId}: {Reason}", callId, e.Reason);
                    };

                    // Start continuous recognition
                    await recognizer.StartContinuousRecognitionAsync().ConfigureAwait(false);

                    // Store the recognizer and audio stream for later use
                    this.activeRecognizers.TryAdd(callId, recognizer);
                    this.audioStreams.TryAdd(callId, audioStream);

                    this.logger.LogInformation("Real-time transcription started for call: {CallId}", callId);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error starting real-time transcription for call: {CallId}", callId);
                throw;
            }
        }

        /// <inheritdoc/>
        public async Task StopRealTimeTranscriptionAsync(string callId)
        {
            try
            {
                this.logger.LogInformation("Stopping real-time transcription for call: {CallId}", callId);

                if (this.activeRecognizers.TryRemove(callId, out var recognizer))
                {
                    await recognizer.StopContinuousRecognitionAsync().ConfigureAwait(false);
                    recognizer.Dispose();
                    this.logger.LogInformation("Real-time transcription stopped for call: {CallId}", callId);
                }
                else
                {
                    this.logger.LogWarning("No active recognizer found for call: {CallId}", callId);
                }

                // Clean up audio stream
                if (this.audioStreams.TryRemove(callId, out var audioStream))
                {
                    audioStream.Close();
                    this.logger.LogInformation("Audio stream closed for call: {CallId}", callId);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error stopping real-time transcription for call: {CallId}", callId);
                throw;
            }
        }

        /// <summary>
        /// Process audio data for real-time transcription.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="audioData">The audio data to process.</param>
        /// <returns>The task for await.</returns>
        public Task ProcessAudioDataAsync(string callId, byte[] audioData)
        {
            try
            {
                if (this.audioStreams.TryGetValue(callId, out var audioStream))
                {
                    // Send audio data to the Azure Speech service for real-time transcription
                    audioStream.Write(audioData);
                    this.logger.LogDebug("Processed audio data for call: {CallId}, Size: {Size} bytes", callId, audioData.Length);
                }
                else
                {
                    this.logger.LogWarning("No active audio stream found for call: {CallId}", callId);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error processing audio data for call: {CallId}", callId);
            }

            return Task.CompletedTask;
        }

        /// <summary>
        /// Dispose all active recognizers.
        /// </summary>
        public void Dispose()
        {
            foreach (var kvp in this.activeRecognizers)
            {
                try
                {
                    kvp.Value?.Dispose();
                }
                catch (Exception ex)
                {
                    this.logger.LogError(ex, "Error disposing recognizer for call: {CallId}", kvp.Key);
                }
            }

            foreach (var kvp in this.audioStreams)
            {
                try
                {
                    kvp.Value?.Close();
                }
                catch (Exception ex)
                {
                    this.logger.LogError(ex, "Error closing audio stream for call: {CallId}", kvp.Key);
                }
            }

            this.activeRecognizers.Clear();
            this.audioStreams.Clear();
        }
    }
}