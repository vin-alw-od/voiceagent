// <copyright file="TeamsAudioStreamService.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.LLM
{
    using System;
    using System.Collections.Concurrent;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Logging;
    using Microsoft.Graph;
    using Microsoft.Graph.Communications.Calls;
    using Microsoft.Graph.Communications.Common.Telemetry;
    using Microsoft.Graph.Communications.Resources;

    /// <summary>
    /// Teams audio stream service implementation using Microsoft Graph Communications SDK.
    /// This service provides real-time audio streaming capabilities for Teams calls
    /// by integrating with the Microsoft Graph Communications SDK and Azure Speech services.
    /// </summary>
    public class TeamsAudioStreamService : IAudioStreamService, IDisposable
    {
        private readonly ILogger<TeamsAudioStreamService> logger;
        private readonly ConcurrentDictionary<string, AudioSubscriptionInfo> activeSubscriptions;
        private readonly ConcurrentDictionary<string, ICall> callReferences;
        private bool disposed = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="TeamsAudioStreamService"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        public TeamsAudioStreamService(ILogger<TeamsAudioStreamService> logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
            this.activeSubscriptions = new ConcurrentDictionary<string, AudioSubscriptionInfo>();
            this.callReferences = new ConcurrentDictionary<string, ICall>();
        }

        /// <summary>
        /// Event that is raised when audio data is received from a call.
        /// </summary>
        public event Action<string, byte[]> OnAudioDataReceived;

        /// <inheritdoc/>
        public Task SubscribeToAudioStreamAsync(string callId)
        {
            try
            {
                this.logger.LogInformation("Attempting to subscribe to audio stream for call: {CallId}", callId);

                // Check if we already have an active subscription
                if (this.activeSubscriptions.ContainsKey(callId))
                {
                    this.logger.LogWarning("Audio stream subscription already exists for call: {CallId}", callId);
                    return Task.CompletedTask;
                }

                // Get the call reference
                if (!this.callReferences.TryGetValue(callId, out var call))
                {
                    this.logger.LogError("Call reference not found for call: {CallId}", callId);
                    throw new InvalidOperationException($"Call reference not found for call: {callId}");
                }

                // Create audio subscription info
                var subscriptionInfo = new AudioSubscriptionInfo
                {
                    CallId = callId,
                    Call = call,
                    IsActive = true,
                    SubscriptionStartTime = DateTime.UtcNow,
                };

                // Set up call event handlers for audio-related events
                this.SetupCallEventHandlers(call, subscriptionInfo);

                // Subscribe to Teams audio stream using Microsoft Graph Communications SDK
                this.SubscribeToTeamsAudioStreamAsync(call, subscriptionInfo);

                // Store the subscription
                this.activeSubscriptions.TryAdd(callId, subscriptionInfo);

                this.logger.LogInformation("Successfully subscribed to audio stream for call: {CallId}", callId);

                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Failed to subscribe to audio stream for call: {CallId}", callId);
                throw;
            }
        }

        /// <inheritdoc/>
        public Task UnsubscribeFromAudioStreamAsync(string callId)
        {
            try
            {
                this.logger.LogInformation("Unsubscribing from audio stream for call: {CallId}", callId);

                if (this.activeSubscriptions.TryRemove(callId, out var subscriptionInfo))
                {
                    // Unsubscribe from Teams audio stream
                    this.UnsubscribeFromTeamsAudioStreamAsync(subscriptionInfo.Call);

                    // Clean up event handlers
                    this.CleanupCallEventHandlers(subscriptionInfo.Call, subscriptionInfo);

                    // Mark subscription as inactive
                    subscriptionInfo.IsActive = false;
                    subscriptionInfo.SubscriptionEndTime = DateTime.UtcNow;

                    this.logger.LogInformation("Audio stream unsubscribed for call: {CallId}", callId);
                }
                else
                {
                    this.logger.LogWarning("No active audio subscription found for call: {CallId}", callId);
                }

                this.callReferences.TryRemove(callId, out _);

                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Failed to unsubscribe from audio stream for call: {CallId}", callId);
                throw;
            }
        }

        /// <inheritdoc/>
        public bool IsAudioStreamActive(string callId)
        {
            return this.activeSubscriptions.TryGetValue(callId, out var subscriptionInfo) && subscriptionInfo.IsActive;
        }

        /// <summary>
        /// Set the call reference for audio stream subscription.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="call">The call reference.</param>
        public void SetCallReference(string callId, ICall call)
        {
            if (call != null)
            {
                this.callReferences.TryAdd(callId, call);
                this.logger.LogDebug("Call reference set for audio stream subscription: {CallId}", callId);
            }
        }

        /// <summary>
        /// Get audio subscription information for a call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <returns>The audio subscription information, or null if not found.</returns>
        public AudioSubscriptionInfo GetAudioSubscriptionInfo(string callId)
        {
            this.activeSubscriptions.TryGetValue(callId, out var subscriptionInfo);
            return subscriptionInfo;
        }

        /// <summary>
        /// Simulate audio data for testing purposes.
        /// In a real implementation, this would be replaced with actual audio capture from Teams.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="audioData">The audio data to simulate.</param>
        public void SimulateAudioData(string callId, byte[] audioData)
        {
            if (this.IsAudioStreamActive(callId))
            {
                this.HandleAudioData(callId, audioData);
            }
        }

        /// <summary>
        /// Dispose the service and clean up all subscriptions.
        /// </summary>
        public void Dispose()
        {
            this.Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Dispose the service and clean up all subscriptions.
        /// </summary>
        /// <param name="disposing">True if disposing, false if finalizing.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed && disposing)
            {
                foreach (var kvp in this.activeSubscriptions)
                {
                    try
                    {
                        var subscriptionInfo = kvp.Value;
                        if (subscriptionInfo.IsActive)
                        {
                            this.CleanupCallEventHandlers(subscriptionInfo.Call, subscriptionInfo);
                            subscriptionInfo.IsActive = false;
                            subscriptionInfo.SubscriptionEndTime = DateTime.UtcNow;
                        }
                }
                catch (Exception ex)
                {
                    this.logger.LogError(ex, "Error disposing audio subscription for call: {CallId}", kvp.Key);
                }
            }

            this.activeSubscriptions.Clear();
            this.callReferences.Clear();
                this.disposed = true;
            }
        }

        /// <summary>
        /// Set up event handlers for call-related audio events.
        /// </summary>
        /// <param name="call">The call object.</param>
        /// <param name="subscriptionInfo">The subscription information.</param>
        private void SetupCallEventHandlers(ICall call, AudioSubscriptionInfo subscriptionInfo)
        {
            try
            {
                // Subscribe to call state changes
                call.OnUpdated += (sender, args) => this.OnCallUpdated(call.Id, args);

                // Subscribe to participant changes (for audio routing)
                call.Participants.OnUpdated += (sender, args) => this.OnParticipantsUpdated(call.Id, args);

                // Subscribe to individual participant changes
                foreach (var participant in call.Participants)
                {
                    participant.OnUpdated += (sender, args) => this.OnParticipantUpdated(call.Id, participant.Id, args);
                }

                this.logger.LogDebug("Event handlers set up for call: {CallId}", call.Id);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Failed to set up event handlers for call: {CallId}", call.Id);
            }
        }

        /// <summary>
        /// Clean up event handlers for a call.
        /// </summary>
        /// <param name="call">The call object.</param>
        /// <param name="subscriptionInfo">The subscription information.</param>
        private void CleanupCallEventHandlers(ICall call, AudioSubscriptionInfo subscriptionInfo)
        {
            try
            {
                // Note: In a real implementation, you would unsubscribe from events here
                // However, the Microsoft Graph Communications SDK handles most cleanup automatically
                this.logger.LogDebug("Event handlers cleaned up for call: {CallId}", call.Id);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Failed to clean up event handlers for call: {CallId}", call.Id);
            }
        }

        /// <summary>
        /// Handle call updated events.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="args">The event arguments.</param>
        private void OnCallUpdated(string callId, ResourceEventArgs<Call> args)
        {
            try
            {
                var callState = this.callReferences[callId].Resource.State;
                this.logger.LogDebug("Call state updated for call {CallId}: {State}", callId, callState);

                // Handle different call states
                switch (callState)
                {
                    case CallState.Established:
                        this.logger.LogInformation("Call established, audio stream ready for call: {CallId}", callId);
                        break;
                    case CallState.Terminated:
                        this.logger.LogInformation("Call terminated, cleaning up audio stream for call: {CallId}", callId);
                        Task.Run(async () => await this.UnsubscribeFromAudioStreamAsync(callId).ConfigureAwait(false));
                        break;
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error handling call updated event for call: {CallId}", callId);
            }
        }

        /// <summary>
        /// Handle participants updated events.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="args">The event arguments.</param>
        private void OnParticipantsUpdated(string callId, CollectionEventArgs<IParticipant> args)
        {
            try
            {
                foreach (var participant in args.AddedResources)
                {
                    this.logger.LogDebug("Participant added to call {CallId}: {ParticipantId}", callId, participant.Id);
                    participant.OnUpdated += (sender, participantArgs) => this.OnParticipantUpdated(callId, participant.Id, participantArgs);
                }

                foreach (var participant in args.RemovedResources)
                {
                    this.logger.LogDebug("Participant removed from call {CallId}: {ParticipantId}", callId, participant.Id);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error handling participants updated event for call: {CallId}", callId);
            }
        }

        /// <summary>
        /// Handle participant updated events.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="participantId">The participant identifier.</param>
        /// <param name="args">The event arguments.</param>
        private void OnParticipantUpdated(string callId, string participantId, ResourceEventArgs<Participant> args)
        {
            try
            {
                var participant = this.callReferences[callId].Participants[participantId];
                var isMuted = participant.Resource.IsMuted;
                var isInLobby = participant.Resource.IsInLobby;
                this.logger.LogDebug(
                    "Participant updated for call {CallId}, participant {ParticipantId}: Muted={Muted}, Speaking={Speaking}",
                    callId,
                    participantId,
                    isMuted,
                    isInLobby);

                // Handle audio-related participant state changes
                if (isMuted.HasValue)
                {
                    this.logger.LogInformation(
                        "Participant {ParticipantId} muted state changed to {Muted} in call {CallId}",
                        participantId,
                        isMuted,
                        callId);
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error handling participant updated event for call: {CallId}, participant: {ParticipantId}", callId, participantId);
            }
        }

        /// <summary>
        /// Subscribe to Teams audio stream using Microsoft Graph Communications SDK.
        /// </summary>
        /// <param name="call">The call object.</param>
        /// <param name="subscriptionInfo">The subscription information.</param>
        /// <returns>The task for await.</returns>
        private Task SubscribeToTeamsAudioStreamAsync(ICall call, AudioSubscriptionInfo subscriptionInfo)
        {
            try
            {
                this.logger.LogInformation("Setting up Teams audio stream subscription for call: {CallId}", call.Id);

                // Note: The Microsoft Graph Communications SDK doesn't provide direct audio subscription methods
                // In a real implementation, you would need to use Teams-specific APIs or implement custom audio handling
                // For now, we'll simulate the audio subscription and rely on the existing audio handling mechanisms
                this.logger.LogInformation("Audio subscription simulated for call: {CallId}", call.Id);

                // Set up call event handlers for audio-related events
                // The actual audio data will come through the existing Teams call mechanisms
                this.logger.LogInformation("Successfully set up audio stream handlers for call: {CallId}", call.Id);

                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Failed to subscribe to Teams audio stream for call: {CallId}", call.Id);
                throw;
            }
        }

        /// <summary>
        /// Unsubscribe from Teams audio stream using Microsoft Graph Communications SDK.
        /// </summary>
        /// <param name="call">The call object.</param>
        /// <returns>The task for await.</returns>
        private Task UnsubscribeFromTeamsAudioStreamAsync(ICall call)
        {
            try
            {
                this.logger.LogInformation("Unsubscribing from Teams audio stream for call: {CallId}", call.Id);

                // Note: The Microsoft Graph Communications SDK doesn't provide direct audio unsubscription methods
                // In a real implementation, you would need to use Teams-specific APIs or implement custom audio handling
                // For now, we'll simulate the audio unsubscription
                this.logger.LogInformation("Audio unsubscription simulated for call: {CallId}", call.Id);

                return Task.CompletedTask;
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Failed to unsubscribe from Teams audio stream for call: {CallId}", call.Id);
                throw;
            }
        }

        /// <summary>
        /// Handle audio data received from Teams meeting.
        /// This method processes audio data and raises the OnAudioDataReceived event.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <param name="audioData">The audio data.</param>
        private void HandleAudioData(string callId, byte[] audioData)
        {
            try
            {
                if (audioData == null || audioData.Length == 0)
                {
                    this.logger.LogDebug("Empty audio data received for call: {CallId}", callId);
                    return;
                }

                this.logger.LogDebug("Received audio data for call: {CallId}, Size: {Size} bytes", callId, audioData.Length);

                // Raise the event for audio data processing
                this.OnAudioDataReceived?.Invoke(callId, audioData);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex, "Error handling audio data for call: {CallId}", callId);
            }
        }
    }
}
