// <copyright file="LLMAgentController.cs" company="Microsoft Corporation">
// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT license.
// </copyright>

namespace Sample.IncidentBot.Controllers
{
    using System;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Graph.Communications.Common;
    using Microsoft.Graph.Communications.Core.Serialization;
    using Sample.IncidentBot.Bot;
    using Sample.IncidentBot.Data;
    using Sample.IncidentBot.LLM;

    /// <summary>
    /// Controller for LLM agent functionality.
    /// </summary>
    [Route("[controller]")]
    public class LLMAgentController : Controller
    {
        private readonly Bot bot;
        private readonly IConversationManager conversationManager;
        private readonly ISpeechToTextService speechToTextService;
        private readonly ITextToSpeechService textToSpeechService;
        private readonly IAudioStreamService audioStreamService;

        /// <summary>
        /// Initializes a new instance of the <see cref="LLMAgentController"/> class.
        /// </summary>
        /// <param name="bot">The bot instance.</param>
        /// <param name="conversationManager">The conversation manager.</param>
        /// <param name="speechToTextService">The speech-to-text service.</param>
        /// <param name="textToSpeechService">The text-to-speech service.</param>
        /// <param name="audioStreamService">The audio stream service.</param>
        public LLMAgentController(Bot bot, IConversationManager conversationManager, ISpeechToTextService speechToTextService, ITextToSpeechService textToSpeechService, IAudioStreamService audioStreamService)
        {
            this.bot = bot ?? throw new ArgumentNullException(nameof(bot));
            this.conversationManager = conversationManager ?? throw new ArgumentNullException(nameof(conversationManager));
            this.speechToTextService = speechToTextService ?? throw new ArgumentNullException(nameof(speechToTextService));
            this.textToSpeechService = textToSpeechService ?? throw new ArgumentNullException(nameof(textToSpeechService));
            this.audioStreamService = audioStreamService ?? throw new ArgumentNullException(nameof(audioStreamService));
        }

        /// <summary>
        /// Join a call with LLM agent capabilities.
        /// </summary>
        /// <param name="joinCallRequest">The join call request data.</param>
        /// <returns>The action result.</returns>
        [HttpPost("joinCall")]
        public async Task<IActionResult> JoinCallWithLLMAgentAsync([FromBody] JoinCallRequestData joinCallRequest)
        {
            Validator.NotNull(joinCallRequest, nameof(joinCallRequest));

            try
            {
                // Use the bot extension method to join call with LLM agent
                var call = await this.bot.JoinCallWithLLMAgentAsync(
                    joinCallRequest,
                    this.conversationManager,
                    this.speechToTextService,
                    this.textToSpeechService,
                    this.audioStreamService).ConfigureAwait(false);

                return this.Ok(new
                {
                    CallId = call.Id,
                    Status = "Joined call with LLM agent capabilities",
                    Message = "The bot has joined the call and is ready to process audio and provide intelligent responses.",
                });
            }
            catch (Exception ex)
            {
                return this.BadRequest(new
                {
                    Error = "Failed to join call with LLM agent",
                    Message = ex.Message,
                });
            }
        }

        /// <summary>
        /// Test audio streaming functionality by simulating audio data.
        /// </summary>
        /// <param name="request">The test request containing call ID and audio data.</param>
        /// <returns>The action result.</returns>
        [HttpPost("testAudioStream")]
        public IActionResult TestAudioStream([FromBody] TestAudioStreamRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.CallId))
                {
                    return this.BadRequest(new { Error = "CallId is required" });
                }

                if (this.audioStreamService is TeamsAudioStreamService teamsAudioService)
                {
                    // Simulate audio data for testing
                    var audioData = request.AudioData ?? new byte[] { 1, 2, 3, 4, 5 }; // Sample audio data
                    teamsAudioService.SimulateAudioData(request.CallId, audioData);

                    return this.Ok(new
                    {
                        CallId = request.CallId,
                        Status = "Audio data simulated successfully",
                        Message = "Audio data has been processed through the TeamsAudioStreamService",
                        AudioDataSize = audioData.Length,
                    });
                }
                else
                {
                    return this.BadRequest(new
                    {
                        Error = "TeamsAudioStreamService not available",
                        Message = "The audio stream service is not of the expected type",
                    });
                }
            }
            catch (Exception ex)
            {
                return this.BadRequest(new
                {
                    Error = "Failed to test audio stream",
                    Message = ex.Message,
                });
            }
        }

        /// <summary>
        /// Get audio subscription information for a call.
        /// </summary>
        /// <param name="callId">The call identifier.</param>
        /// <returns>The action result with subscription information.</returns>
        [HttpGet("audioSubscription/{callId}")]
        public IActionResult GetAudioSubscriptionInfo(string callId)
        {
            try
            {
                if (string.IsNullOrEmpty(callId))
                {
                    return this.BadRequest(new { Error = "CallId is required" });
                }

                if (this.audioStreamService is TeamsAudioStreamService teamsAudioService)
                {
                    var subscriptionInfo = teamsAudioService.GetAudioSubscriptionInfo(callId);

                    if (subscriptionInfo != null)
                    {
                        return this.Ok(new
                        {
                            CallId = subscriptionInfo.CallId,
                            IsActive = subscriptionInfo.IsActive,
                            SubscriptionStartTime = subscriptionInfo.SubscriptionStartTime,
                            SubscriptionEndTime = subscriptionInfo.SubscriptionEndTime,
                            Duration = subscriptionInfo.Duration,
                            Status = "Audio subscription found",
                        });
                    }
                    else
                    {
                        return this.NotFound(new
                        {
                            CallId = callId,
                            Status = "No audio subscription found",
                            Message = "No active audio subscription exists for this call",
                        });
                    }
                }
                else
                {
                    return this.BadRequest(new
                    {
                        Error = "TeamsAudioStreamService not available",
                        Message = "The audio stream service is not of the expected type",
                    });
                }
            }
            catch (Exception ex)
            {
                return this.BadRequest(new
                {
                    Error = "Failed to get audio subscription info",
                    Message = ex.Message,
                });
            }
        }

        /// <summary>
        /// Test text-to-speech functionality.
        /// </summary>
        /// <param name="request">The TTS request.</param>
        /// <returns>The action result with audio data.</returns>
        [HttpPost("testTTS")]
        public async Task<IActionResult> TestTextToSpeechAsync([FromBody] TestTTSRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Text))
                {
                    return this.BadRequest(new { Error = "Text is required" });
                }

                var audioData = await this.textToSpeechService.SynthesizeSpeechAsync(
                    request.Text,
                    request.Voice,
                    request.Language).ConfigureAwait(false);

                return this.Ok(new
                {
                    Text = request.Text,
                    Voice = request.Voice ?? "Default",
                    Language = request.Language ?? "en-US",
                    AudioDataSize = audioData.Length,
                    Status = "Text-to-speech synthesis completed successfully",
                });
            }
            catch (Exception ex)
            {
                return this.BadRequest(new
                {
                    Error = "Failed to synthesize speech",
                    Message = ex.Message,
                });
            }
        }

        /// <summary>
        /// Get available voices for text-to-speech.
        /// </summary>
        /// <param name="language">Optional language filter.</param>
        /// <returns>The action result with available voices.</returns>
        [HttpGet("voices")]
        public async Task<IActionResult> GetAvailableVoicesAsync([FromQuery] string language = null)
        {
            try
            {
                var voices = await this.textToSpeechService.GetAvailableVoicesAsync(language).ConfigureAwait(false);

                return this.Ok(new
                {
                    Language = language ?? "All languages",
                    VoiceCount = voices.Length,
                    Voices = voices,
                    Status = "Available voices retrieved successfully",
                });
            }
            catch (Exception ex)
            {
                return this.BadRequest(new
                {
                    Error = "Failed to get available voices",
                    Message = ex.Message,
                });
            }
        }
    }
}